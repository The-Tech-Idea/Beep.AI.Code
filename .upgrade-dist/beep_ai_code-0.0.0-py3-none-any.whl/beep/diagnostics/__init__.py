"""Diagnostics and performance package."""
