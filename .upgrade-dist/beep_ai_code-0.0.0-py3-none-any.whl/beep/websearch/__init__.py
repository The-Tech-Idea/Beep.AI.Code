"""Web search package."""
