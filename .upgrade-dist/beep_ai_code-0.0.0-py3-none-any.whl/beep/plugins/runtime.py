"""Runtime plugin discovery and loading helpers."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path

from beep.plugins.registry import PluginRegistry

logger = logging.getLogger(__name__)


@dataclass
class PluginRuntime:
    """Loaded plugin runtime details for visibility and integration."""

    registry: PluginRegistry
    searched_paths: list[Path]
    loaded_count: int


def _discover_plugin_paths(workspace_root: Path) -> list[Path]:
    paths: list[Path] = [
        Path.home() / ".beepai" / "plugins",
        workspace_root / ".beep" / "plugins",
    ]
    env_dir = os.environ.get("BEEP_PLUGINS_DIR")
    if env_dir:
        paths.append(Path(env_dir))
    return paths


def load_runtime_plugins(workspace_root: Path, *, enabled: bool = True) -> PluginRuntime:
    """Load plugins from configured discovery locations."""
    registry = PluginRegistry()
    searched_paths = _discover_plugin_paths(workspace_root)
    if not enabled:
        return PluginRuntime(registry=registry, searched_paths=searched_paths, loaded_count=0)
    loaded_count = 0
    for plugin_dir in searched_paths:
        try:
            loaded_count += registry.load_from_directory(plugin_dir)
        except (PermissionError, OSError) as exc:
            logger.warning("Plugin discovery skipped %s: %s", plugin_dir, exc)
    return PluginRuntime(
        registry=registry,
        searched_paths=searched_paths,
        loaded_count=loaded_count,
    )
