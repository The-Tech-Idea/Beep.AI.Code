"""Plugin system for extending Beep.AI.Code.

Supports:
- Custom tools for the agent
- Custom slash commands
- Custom context providers
- Custom output formatters
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from beep.agent.tools.base import BaseTool

logger = logging.getLogger(__name__)


def _validate_tool_schema(tool: BaseTool) -> bool:
    """Validate a plugin tool's JSON schema at load time.

    Returns True when the schema is valid, False otherwise.
    Logs an error for invalid schemas so callers can skip bad tools.
    """
    try:
        import jsonschema  # type: ignore[import-untyped]
    except ImportError:
        # jsonschema not installed — skip validation silently
        return True

    schema = tool.parameters
    if not isinstance(schema, dict):
        logger.error(
            "Plugin tool '%s' has invalid parameters: expected dict, got %s",
            tool.name,
            type(schema).__name__,
        )
        return False

    meta_schema = {
        "type": "object",
        "additionalProperties": {
            "type": "object",
            "properties": {
                "type": {"type": "string"},
                "description": {"type": "string"},
            },
            "required": ["type"],
        },
    }
    try:
        jsonschema.validate(instance=schema, schema=meta_schema)
        return True
    except jsonschema.ValidationError as exc:
        logger.error("Plugin tool '%s' schema invalid: %s", tool.name, exc.message)
        return False


class PluginNameConflictError(Exception):
    """Raised when two plugins share the same name."""


@dataclass
class PluginInfo:
    """Metadata for a plugin."""

    name: str
    version: str = "0.1.0"
    description: str = ""
    author: str = ""


class Plugin(ABC):
    """Base class for plugins."""

    info = PluginInfo(name="unnamed")

    @abstractmethod
    def activate(self) -> None:
        """Called when plugin is loaded."""

    def deactivate(self) -> None:
        """Called when plugin is unloaded."""


class ToolPlugin(Plugin):
    """Plugin that provides agent tools."""

    @abstractmethod
    def get_tools(self) -> list[BaseTool]:
        """Return tools provided by this plugin."""

    def get_tools_for_workspace(self, workspace_root: Path | None = None) -> list[BaseTool]:
        """Return tools, optionally constructed with workspace_root context.

        Default implementation calls :meth:`get_tools` (ignoring workspace_root).
        Override in plugins that build workspace-aware tools so they receive
        the correct workspace path at runtime.
        """
        return self.get_tools()


class CommandPlugin(Plugin):
    """Plugin that provides slash commands."""

    @abstractmethod
    def get_commands(self) -> dict[str, str]:
        """Return command name -> description mapping."""

    @abstractmethod
    async def handle_command(self, command: str, args: str) -> str | None:
        """Handle a slash command. Return response or None."""


class ContextPlugin(Plugin):
    """Plugin that provides additional context."""

    @abstractmethod
    def get_context(self) -> str:
        """Return context string to inject into prompts."""


class BackendProviderPlugin(Plugin):
    """Plugin that provides an autonomous-agent backend/provider."""

    def source_label(self) -> str:
        """Return the provider source label shown in CLI/provider UX."""
        return "plugin"

    def requires_api_key(self) -> bool | None:
        """Return whether the provider requires an API key."""
        return None

    def requires_model(self) -> bool | None:
        """Return whether the provider requires an explicit model selection."""
        return None

    def default_base_url(self) -> str | None:
        """Return the provider's default base URL when one exists."""
        return None

    def configuration_notes(self, config: Any) -> tuple[str, ...]:
        """Return provider-specific configuration guidance notes."""
        del config
        return ()

    def probe_configuration(self, config: Any) -> Any:
        """Return a best-effort configuration probe result, or None when unsupported."""
        del config
        return None

    @abstractmethod
    def provider_key(self) -> str:
        """Return the provider key used in config.agent_backend."""

    @abstractmethod
    def is_configured(self, config: Any) -> bool:
        """Return True when the provider has enough configuration to run."""

    @abstractmethod
    def describe(self, config: Any) -> Any:
        """Return the provider descriptor for the active configuration."""

    @abstractmethod
    def build_backend(
        self,
        config: Any,
        *,
        client: Any = None,
        coding_assistant: dict[str, Any] | None = None,
    ) -> Any:
        """Build the provider-specific autonomous-agent backend."""


class WorkspaceIntelligencePlugin(Plugin):
    """Plugin that contributes workspace-intelligence capabilities and tools."""

    @abstractmethod
    def capabilities(self, *, workspace_root: Path) -> Any:
        """Return capability descriptors for the given workspace."""

    def get_tools_for_workspace(self, workspace_root: Path) -> list[BaseTool]:
        """Return workspace-intelligence tools for the given workspace."""
        del workspace_root
        return []

    def get_semantic_search_adapter(self, workspace_root: Path) -> Any | None:
        """Return a shared semantic-search adapter for the given workspace when available."""
        del workspace_root
        return None

    def get_status_report(self, workspace_root: Path) -> Any | None:
        """Return a workspace-intelligence status report for the given workspace."""
        del workspace_root
        return None


class PluginRegistry:
    """Registry for managing plugins."""

    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}
        self._tool_plugins: list[tuple[ToolPlugin, frozenset[str]]] = []
        self._commands: dict[str, CommandPlugin] = {}
        self._context_plugins: list[ContextPlugin] = []
        self._backend_provider_plugins: dict[str, BackendProviderPlugin] = {}
        self._workspace_intelligence_plugins: list[WorkspaceIntelligencePlugin] = []
        self._load_errors: list[str] = []

    def register(self, plugin: Plugin) -> None:
        """Register a plugin."""
        name = plugin.info.name
        if name in self._plugins:
            raise PluginNameConflictError(
                f"Plugin '{name}' is already registered. "
                "Rename one of the plugins to resolve the conflict."
            )
        self._plugins[name] = plugin
        plugin.activate()

        if isinstance(plugin, ToolPlugin):
            # Validate schemas at load time; record errors, track valid names.
            valid_names: set[str] = set()
            for tool in plugin.get_tools():
                if _validate_tool_schema(tool):
                    valid_names.add(tool.name)
                else:
                    self._load_errors.append(
                        f"Tool '{tool.name}' from plugin '{name}' rejected: invalid schema"
                    )
            self._tool_plugins.append((plugin, frozenset(valid_names)))

        if isinstance(plugin, CommandPlugin):
            self._commands[name] = plugin

        if isinstance(plugin, ContextPlugin):
            self._context_plugins.append(plugin)

        if isinstance(plugin, BackendProviderPlugin):
            provider_key = plugin.provider_key()
            if provider_key in self._backend_provider_plugins:
                raise PluginNameConflictError(
                    f"Backend provider '{provider_key}' is already registered. "
                    "Rename one of the plugins to resolve the conflict."
                )
            self._backend_provider_plugins[provider_key] = plugin

        if isinstance(plugin, WorkspaceIntelligencePlugin):
            self._workspace_intelligence_plugins.append(plugin)

    def unregister(self, name: str) -> None:
        """Unregister a plugin."""
        plugin = self._plugins.pop(name, None)
        if plugin:
            plugin.deactivate()
            if isinstance(plugin, ToolPlugin):
                self._tool_plugins = [
                    (p, names) for p, names in self._tool_plugins if p is not plugin
                ]
            if isinstance(plugin, BackendProviderPlugin):
                self._backend_provider_plugins = {
                    key: provider
                    for key, provider in self._backend_provider_plugins.items()
                    if provider is not plugin
                }
            if isinstance(plugin, WorkspaceIntelligencePlugin):
                self._workspace_intelligence_plugins = [
                    current for current in self._workspace_intelligence_plugins if current is not plugin
                ]

    def load_from_file(self, path: Path) -> None:
        """Load a plugin from a Python file."""
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if not spec or not spec.loader:
            raise ImportError(f"Cannot load plugin: {path}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (
                isinstance(attr, type)
                and issubclass(attr, Plugin)
                and attr is not Plugin
                and attr is not ToolPlugin
                and attr is not CommandPlugin
                and attr is not ContextPlugin
                and attr is not BackendProviderPlugin
                and attr is not WorkspaceIntelligencePlugin
            ):
                self.register(attr())

    def load_from_directory(self, directory: Path) -> int:
        """Load all plugins from a directory. Returns count loaded."""
        count = 0
        if not directory.exists():
            return count

        for path in directory.glob("*.py"):
            if path.name.startswith("_"):
                continue
            try:
                self.load_from_file(path)
                count += 1
            except Exception as e:
                self._load_errors.append(f"{path}: {e}")

        return count

    def get_tools(self, workspace_root: Path | None = None) -> list[BaseTool]:
        """Get all tools from plugins.

        Parameters
        ----------
        workspace_root:
            When provided, passed to each plugin via
            :meth:`ToolPlugin.get_tools_for_workspace` so workspace-aware
            tools can be constructed with the correct path.
        """
        result: list[BaseTool] = []
        for plugin, valid_names in self._tool_plugins:
            for tool in plugin.get_tools_for_workspace(workspace_root):
                if tool.name in valid_names:
                    result.append(tool)
        return result

    def get_command_descriptions(self) -> dict[str, str]:
        """Get all commands from plugins."""
        commands = {}
        for plugin in self._commands.values():
            commands.update(plugin.get_commands())
        return commands

    async def handle_plugin_command(self, command: str, args: str) -> str | None:
        """Handle a command from a plugin."""
        for plugin in self._commands.values():
            cmds = plugin.get_commands()
            if command in cmds:
                return await plugin.handle_command(command, args)
        return None

    def get_context(self) -> str:
        """Get context from all context plugins."""
        parts = []
        for plugin in self._context_plugins:
            ctx = plugin.get_context()
            if ctx:
                parts.append(ctx)
        return "\n\n".join(parts)

    def get_backend_provider(self, key: str) -> BackendProviderPlugin | None:
        """Return one backend-provider plugin by provider key."""
        return self._backend_provider_plugins.get(key)

    def list_backend_providers(self) -> list[str]:
        """List backend-provider keys contributed by runtime plugins."""
        return sorted(self._backend_provider_plugins)

    def get_workspace_intelligence_capabilities(self, workspace_root: Path) -> list[Any]:
        """Return workspace-intelligence capability reports from runtime plugins."""
        capabilities: list[Any] = []
        for plugin in self._workspace_intelligence_plugins:
            capability_set = plugin.capabilities(workspace_root=workspace_root)
            if capability_set is not None:
                capabilities.append(capability_set)
        return capabilities

    def get_workspace_intelligence_tools(self, workspace_root: Path) -> list[BaseTool]:
        """Return workspace-intelligence tools contributed by runtime plugins."""
        tools: list[BaseTool] = []
        for plugin in self._workspace_intelligence_plugins:
            for tool in plugin.get_tools_for_workspace(workspace_root):
                if _validate_tool_schema(tool):
                    tools.append(tool)
                else:
                    self._load_errors.append(
                        f"Workspace intelligence tool '{tool.name}' from plugin '{plugin.info.name}' rejected: invalid schema"
                    )
        return tools

    def get_semantic_search_adapter(self, workspace_root: Path) -> Any | None:
        """Return the first shared semantic-search adapter exposed by workspace-intelligence plugins."""
        for plugin in self._workspace_intelligence_plugins:
            adapter = plugin.get_semantic_search_adapter(workspace_root)
            if adapter is not None:
                return adapter
        return None

    def get_workspace_intelligence_reports(self, workspace_root: Path) -> list[Any]:
        """Return status reports from runtime workspace-intelligence plugins."""
        reports: list[Any] = []
        for plugin in self._workspace_intelligence_plugins:
            report = plugin.get_status_report(workspace_root)
            if report is not None:
                reports.append(report)
        return reports

    def list_plugins(self) -> list[dict[str, str]]:
        """List all loaded plugins."""
        return [
            {
                "name": p.info.name,
                "version": p.info.version,
                "description": p.info.description,
                "type": type(p).__name__,
            }
            for p in self._plugins.values()
        ]

    def get_load_errors(self) -> list[str]:
        """Get plugin loading errors."""
        return list(self._load_errors)
