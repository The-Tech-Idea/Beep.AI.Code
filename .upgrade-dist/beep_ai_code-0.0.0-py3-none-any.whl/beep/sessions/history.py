"""Local conversation history storage."""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

HISTORY_DIR = Path.home() / ".beepai" / "history"

# Auto-compaction: check every N appended messages
_COMPACTION_CHECK_INTERVAL = 10
# Estimated token budget before compaction is triggered (≈ 60k tokens)
_COMPACTION_TOKEN_THRESHOLD = 60_000

# Per-session append counter tracked in-process (not persisted)
_append_counter: dict[str, int] = {}


@dataclass
class SessionSummary:
    """Metadata about a saved session."""

    session_id: str
    created_at: datetime | None
    message_count: int
    last_message_preview: str


def _get_session_file(session_id: str) -> Path:
    """Get path to a session history file."""
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    return HISTORY_DIR / f"{session_id}.jsonl"


def _relative_time(dt: datetime | None) -> str:
    """Return a human-readable relative time string (e.g. '3 hours ago')."""
    if dt is None:
        return "unknown"
    now = datetime.now(tz=timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta = now - dt
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        m = seconds // 60
        return f"{m} minute{'s' if m != 1 else ''} ago"
    if seconds < 86400:
        h = seconds // 3600
        return f"{h} hour{'s' if h != 1 else ''} ago"
    d = seconds // 86400
    return f"{d} day{'s' if d != 1 else ''} ago"


def _parse_timestamp(ts: str | None) -> datetime | None:
    """Parse an ISO timestamp string to a UTC-aware datetime, or None."""
    if not ts:
        return None
    try:
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def estimate_tokens(messages: list[dict[str, Any]]) -> int:
    """Rough token estimate: 1 token ≈ 4 characters of content."""
    total_chars = sum(len(str(m.get("content") or "")) for m in messages)
    return total_chars // 4


def save_message(session_id: str, message: dict[str, Any]) -> None:
    """Append a message to session history, flushing immediately."""
    append_message(session_id, message)


def append_message(session_id: str, message: dict[str, Any]) -> None:
    """Append a single message to session history, flushing to disk immediately."""
    path = _get_session_file(session_id)
    entry = {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        **message,
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
        f.flush()
        os.fsync(f.fileno())


def replace_session(session_id: str, messages: list[dict[str, Any]]) -> None:
    """Atomically replace all messages in a session history file."""
    path = _get_session_file(session_id)
    tmp_path = path.with_suffix(".tmp")
    now = datetime.now(tz=timezone.utc).isoformat()
    with open(tmp_path, "w", encoding="utf-8") as f:
        for message in messages:
            entry = {
                "timestamp": now,
                "role": message.get("role", "user"),
                "content": message.get("content", ""),
            }
            f.write(json.dumps(entry) + "\n")
        f.flush()
        os.fsync(f.fileno())
    tmp_path.replace(path)


def load_session(session_id: str) -> list[dict[str, Any]]:
    """Load all messages from a session."""
    path = _get_session_file(session_id)
    if not path.exists():
        return []

    messages = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entry = json.loads(line)
                    # Skip meta-only sentinels
                    if entry.get("role") == "meta":
                        continue
                    messages.append({
                        "role": entry.get("role", "user"),
                        "content": entry.get("content", ""),
                    })
                except json.JSONDecodeError:
                    continue
    return messages


def list_sessions() -> list[SessionSummary]:
    """List all saved sessions as SessionSummary objects, newest first."""
    if not HISTORY_DIR.exists():
        return []

    summaries: list[SessionSummary] = []
    for path in sorted(HISTORY_DIR.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True):
        session_id = path.stem
        message_count = 0
        first_ts: str | None = None
        last_preview = ""

        try:
            with open(path, encoding="utf-8") as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                        if entry.get("role") == "meta":
                            continue
                        message_count += 1
                        if i == 0:
                            first_ts = entry.get("timestamp")
                        content = str(entry.get("content") or "")
                        last_preview = content[:80]
                    except json.JSONDecodeError:
                        continue
        except OSError:
            continue

        summaries.append(
            SessionSummary(
                session_id=session_id,
                created_at=_parse_timestamp(first_ts),
                message_count=message_count,
                last_message_preview=last_preview,
            )
        )

    return summaries


def export_session(session_id: str, format: str = "md") -> str:
    """Export a session as Markdown or JSON string.

    Args:
        session_id: The session to export.
        format: ``"md"`` for Markdown, ``"json"`` for raw JSON array.

    Returns:
        The formatted string, or an empty string if the session does not exist.
    """
    messages = load_session(session_id)
    if not messages:
        return ""

    if format == "json":
        return json.dumps(messages, indent=2, ensure_ascii=False)

    # Markdown
    lines = [f"# Session {session_id}\n"]
    for msg in messages:
        role = msg.get("role", "user").capitalize()
        content = msg.get("content", "")
        lines.append(f"## {role}\n\n{content}\n")
    return "\n".join(lines)


def search_sessions(query: str) -> list[SessionSummary]:
    """Search all session JSONL files for messages containing *query* (case-insensitive).

    Returns a list of :class:`SessionSummary` for sessions that have at least
    one matching message, with ``last_message_preview`` set to the first
    matching snippet.
    """
    if not HISTORY_DIR.exists():
        return []

    query_lower = query.lower()
    results: list[SessionSummary] = []

    for path in sorted(HISTORY_DIR.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True):
        session_id = path.stem
        message_count = 0
        first_ts: str | None = None
        match_preview = ""

        try:
            with open(path, encoding="utf-8") as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                        if entry.get("role") == "meta":
                            continue
                        message_count += 1
                        if i == 0:
                            first_ts = entry.get("timestamp")
                        content = str(entry.get("content") or "")
                        if not match_preview and query_lower in content.lower():
                            idx = content.lower().find(query_lower)
                            start = max(0, idx - 20)
                            match_preview = content[start : start + 80]
                    except json.JSONDecodeError:
                        continue
        except OSError:
            continue

        if match_preview:
            results.append(
                SessionSummary(
                    session_id=session_id,
                    created_at=_parse_timestamp(first_ts),
                    message_count=message_count,
                    last_message_preview=match_preview,
                )
            )

    return results


def maybe_compact_session(
    session_id: str,
    messages: list[dict[str, Any]],
    *,
    threshold: int = _COMPACTION_TOKEN_THRESHOLD,
) -> list[dict[str, Any]]:
    """Check token estimate and compact in-memory messages if over threshold.

    This is a *local* compaction only: keeps the system message plus the last
    20 messages.  Call :func:`replace_session` afterwards if you want to persist
    the result.

    Returns the (possibly compacted) messages list.
    """
    count = _append_counter.get(session_id, 0) + 1
    _append_counter[session_id] = count

    if count % _COMPACTION_CHECK_INTERVAL != 0:
        return messages

    if estimate_tokens(messages) < threshold:
        return messages

    system = messages[0]
    tail = messages[1:][-20:]
    return [system] + tail


def delete_session(session_id: str) -> bool:
    """Delete a session history file."""
    path = _get_session_file(session_id)
    if path.exists():
        path.unlink()
        return True
    return False


def create_session_id() -> str:
    """Generate a new session ID based on UTC timestamp + short UUID."""
    ts = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%S")
    short = uuid.uuid4().hex[:6]
    return f"{ts}-{short}"
