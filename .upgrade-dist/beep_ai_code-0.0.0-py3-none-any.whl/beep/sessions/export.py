"""Session export functionality."""

from __future__ import annotations

from pathlib import Path

from beep.sessions.history import load_session


def export_markdown(session_id: str, output_path: Path | None = None) -> Path:
    """Export a session as markdown."""
    messages = load_session(session_id)
    if not messages:
        raise ValueError(f"No messages found for session: {session_id}")

    lines = [f"# Beep.AI.Code Session: {session_id}\n"]

    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")

        if role == "system":
            continue

        emoji = "👤" if role == "user" else "🤖"
        lines.append(f"\n## {emoji} {role.title()}\n\n{content}\n")

    output = output_path or Path(f"session-{session_id}.md")
    output.write_text("\n".join(lines), encoding="utf-8")
    return output


def export_json(session_id: str, output_path: Path | None = None) -> Path:
    """Export a session as JSON."""
    import json

    messages = load_session(session_id)
    if not messages:
        raise ValueError(f"No messages found for session: {session_id}")

    data = {
        "session_id": session_id,
        "messages": messages,
    }

    output = output_path or Path(f"session-{session_id}.json")
    output.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return output
