"""Fine-grained permissions and safety system.

Controls what the agent can do based on:
- Trust levels per directory
- Tool-specific permissions
- Auto-approve rules for safe operations
- Dangerous operation guards
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class TrustLevel(Enum):
    """Trust level for a directory."""

    FULL = "full"
    READ_ONLY = "read_only"
    ASK = "ask"
    DENIED = "denied"


class RiskLevel(Enum):
    """Risk level for an operation."""

    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    DESTRUCTIVE = "destructive"


@dataclass
class PermissionRule:
    """A permission rule for a tool or operation."""

    tool_name: str
    risk: RiskLevel
    auto_approve: bool = False
    description: str = ""


@dataclass
class TrustZone:
    """Trust configuration for a directory."""

    path: Path
    level: TrustLevel = TrustLevel.ASK
    allowed_tools: list[str] = field(default_factory=list)
    denied_tools: list[str] = field(default_factory=list)


class PermissionManager:
    """Manages permissions and safety checks."""

    DEFAULT_RULES: list[PermissionRule] = [
        PermissionRule("file_read", RiskLevel.SAFE, auto_approve=True, description="Read files"),
        PermissionRule("search", RiskLevel.SAFE, auto_approve=True, description="Search files"),
        PermissionRule("file_write", RiskLevel.MEDIUM, description="Create/overwrite files"),
        PermissionRule("file_edit", RiskLevel.MEDIUM, description="Edit files"),
        PermissionRule("shell", RiskLevel.HIGH, description="Execute shell commands"),
    ]

    DANGEROUS_COMMANDS = [
        "rm -rf", "rm -f", "del /s", "rmdir /s",
        "format", "mkfs", "dd if=",
        "shutdown", "reboot", "kill -9",
        "> /dev/", "> /etc/", "> /boot/",
        "chmod 777", "chown root",
    ]

    def __init__(self) -> None:
        self._rules = {r.tool_name: r for r in self.DEFAULT_RULES}
        self._trust_zones: list[TrustZone] = []
        self._denied_paths: list[Path] = [
            Path("/etc"),
            Path("/boot"),
            Path("/dev"),
            Path("/proc"),
            Path("/sys"),
        ]

    def add_trust_zone(self, zone: TrustZone) -> None:
        """Add a trust zone."""
        self._trust_zones.append(zone)

    def add_denied_path(self, path: Path) -> None:
        """Add a denied path."""
        if path not in self._denied_paths:
            self._denied_paths.append(path)

    def set_rule(self, tool_name: str, auto_approve: bool) -> None:
        """Set auto-approve for a tool."""
        if tool_name in self._rules:
            self._rules[tool_name].auto_approve = auto_approve

    def check_permission(
        self,
        tool_name: str,
        arguments: dict,
        workspace_root: Path,
    ) -> tuple[bool, str]:
        """Check if an operation is permitted.

        Returns:
            (allowed, reason)
        """
        rule = self._rules.get(tool_name)
        if not rule:
            return False, f"Unknown tool: {tool_name}"

        if tool_name == "shell":
            return self._check_shell_command(arguments, workspace_root)

        if tool_name in ("file_write", "file_edit"):
            return self._check_file_operation(arguments, workspace_root)

        if rule.auto_approve:
            return True, "Auto-approved"

        return False, "Requires approval"

    def _check_shell_command(
        self,
        arguments: dict,
        workspace_root: Path,
    ) -> tuple[bool, str]:
        """Check if a shell command is safe."""
        command = arguments.get("command", "")

        for dangerous in self.DANGEROUS_COMMANDS:
            if dangerous in command.lower():
                return False, f"Dangerous command detected: {dangerous}"

        return False, "Shell commands require approval"

    def _check_file_operation(
        self,
        arguments: dict,
        workspace_root: Path,
    ) -> tuple[bool, str]:
        """Check if a file operation is within allowed paths."""
        file_path = arguments.get("file_path", "")
        target = Path(file_path).resolve()

        for denied in self._denied_paths:
            try:
                target.relative_to(denied)
                return False, f"Path denied: {denied}"
            except ValueError:
                pass

        try:
            target.relative_to(workspace_root.resolve())
        except ValueError:
            return False, "File outside workspace requires approval"

        rule = self._rules.get("file_write" if "content" in arguments else "file_edit")
        if rule and rule.auto_approve:
            return True, "Auto-approved"

        return False, "Requires approval"

    def get_trust_level(self, path: Path) -> TrustLevel:
        """Get trust level for a path."""
        for zone in sorted(
            self._trust_zones,
            key=lambda z: len(str(z.path)),
            reverse=True,
        ):
            try:
                path.resolve().relative_to(zone.path.resolve())
                return zone.level
            except ValueError:
                continue

        return TrustLevel.ASK

    def to_prompt_section(self) -> str:
        """Generate a permissions info section for the system prompt."""
        lines = ["## Permissions & Safety", ""]
        lines.append("You must ask for approval before:")
        for name, rule in self._rules.items():
            if not rule.auto_approve:
                lines.append(f"- {name}: {rule.description}")

        lines.append("")
        lines.append("You cannot access system directories (/etc, /boot, /dev, etc.)")
        lines.append("Dangerous commands (rm -rf, format, etc.) are blocked.")

        return "\n".join(lines)
