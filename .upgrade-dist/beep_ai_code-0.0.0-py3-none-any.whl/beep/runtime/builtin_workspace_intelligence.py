"""Built-in workspace-intelligence plugins."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from beep.agent.tools.base import BaseTool
from beep.agent.tools.python_intelligence import PythonJediAdapter, build_python_intelligence_tools
from beep.agent.tools.semantic_search import SembleIndexAdapter, build_semble_tools
from beep.plugins.registry import PluginInfo, WorkspaceIntelligencePlugin
from beep.runtime.capabilities import CapabilityFlag
from beep.runtime.workspace_intelligence import (
    LSPCapabilities,
    SemanticSearchCapabilities,
    WorkspaceIntelligenceCapabilities,
    WorkspaceIntelligenceStatusReport,
    WorkspaceIntelligenceStatusRow,
    build_semantic_search_status_report,
    build_workspace_intelligence_capabilities,
)


def _disabled_semantic_search_capabilities(note: str) -> SemanticSearchCapabilities:
    return SemanticSearchCapabilities(
        semantic_search=CapabilityFlag(False, note),
        find_related=CapabilityFlag(False, note),
        local_indexing=CapabilityFlag(False, note),
        remote_git_indexing=CapabilityFlag(False, note),
        hybrid_mode=CapabilityFlag(False, note),
        semantic_mode=CapabilityFlag(False, note),
        bm25_mode=CapabilityFlag(False, note),
        language_filters=CapabilityFlag(False, note),
        path_filters=CapabilityFlag(False, note),
        index_stats=CapabilityFlag(False, note),
    )


def _build_python_jedi_capabilities(report: dict[str, object]) -> WorkspaceIntelligenceCapabilities:
    available = bool(report.get("available"))
    python_files = int(report.get("python_files", 0) or 0)
    if available:
        lsp_note = f"Python code intelligence available through Jedi ({python_files} Python files detected)."
    else:
        lsp_note = str(report.get("error") or "Python code intelligence is unavailable.")
    semantic_note = "This plugin does not provide semantic search; use Semble or another semantic-search plugin."
    return WorkspaceIntelligenceCapabilities(
        semantic_search=_disabled_semantic_search_capabilities(semantic_note),
        lsp=LSPCapabilities(
            diagnostics=CapabilityFlag(False, "Jedi does not provide diagnostics."),
            hover=CapabilityFlag(available, lsp_note),
            definition=CapabilityFlag(available, lsp_note),
            references=CapabilityFlag(available, lsp_note),
            rename=CapabilityFlag(available, lsp_note),
            workspace_symbols=CapabilityFlag(available, lsp_note),
            code_actions=CapabilityFlag(False, "Jedi does not provide code actions."),
            formatting=CapabilityFlag(False, "Formatting is outside the built-in Python/Jedi plugin."),
        ),
    )


def _build_python_jedi_status_report(report: dict[str, object]) -> WorkspaceIntelligenceStatusReport:
    return WorkspaceIntelligenceStatusReport(
        title="Workspace Intelligence: Python/Jedi",
        rows=(
            WorkspaceIntelligenceStatusRow("Backend", "Jedi"),
            WorkspaceIntelligenceStatusRow("Available", "Yes" if report.get("available") else "No"),
            WorkspaceIntelligenceStatusRow("Workspace", str(report.get("workspace_root") or "None")),
            WorkspaceIntelligenceStatusRow("Python Files", str(report.get("python_files", 0) or 0)),
            WorkspaceIntelligenceStatusRow("Supported Operations", "hover, definition, references, rename, workspace_symbols"),
            WorkspaceIntelligenceStatusRow("Last Error", str(report.get("error") or "None")),
        ),
    )


class SembleWorkspaceIntelligencePlugin(WorkspaceIntelligencePlugin):
    """Built-in workspace-intelligence plugin backed by Semble."""

    info = PluginInfo(
        name="builtin-semble-workspace-intelligence",
        version="1.0.0",
        description="Built-in Semble semantic search support for workspace intelligence.",
    )

    def __init__(self) -> None:
        self._adapters: dict[Path, SembleIndexAdapter] = {}

    def activate(self) -> None:
        return None

    def _get_adapter(self, workspace_root: Path) -> SembleIndexAdapter:
        resolved_root = workspace_root.resolve()
        adapter = self._adapters.get(resolved_root)
        if adapter is None:
            adapter = SembleIndexAdapter(workspace_root=resolved_root)
            self._adapters[resolved_root] = adapter
        return adapter

    def capabilities(self, *, workspace_root: Path) -> WorkspaceIntelligenceCapabilities:
        adapter = self._get_adapter(workspace_root)
        return build_workspace_intelligence_capabilities(adapter.availability_report())

    def get_tools_for_workspace(self, workspace_root: Path) -> list[BaseTool]:
        adapter = self._get_adapter(workspace_root)
        if not adapter.availability_report().get("available"):
            return []
        return list(build_semble_tools(workspace_root=workspace_root, adapter=adapter))

    def get_semantic_search_adapter(self, workspace_root: Path) -> SembleIndexAdapter | None:
        return self._get_adapter(workspace_root)

    def get_status_report(self, workspace_root: Path) -> WorkspaceIntelligenceStatusReport | None:
        return build_semantic_search_status_report(
            self._get_adapter(workspace_root).availability_report(),
            title="Workspace Intelligence: Semble",
        )


class PythonJediWorkspaceIntelligencePlugin(WorkspaceIntelligencePlugin):
    """Built-in Python code-intelligence plugin backed by Jedi."""

    info = PluginInfo(
        name="builtin-python-jedi-workspace-intelligence",
        version="1.0.0",
        description="Built-in Python hover, definition, reference, rename, and workspace-symbol support for workspace intelligence.",
    )

    def __init__(
        self,
        adapter_factory: Callable[[Path], PythonJediAdapter] | None = None,
    ) -> None:
        self._adapter_factory = adapter_factory or (lambda root: PythonJediAdapter(workspace_root=root))
        self._adapters: dict[Path, PythonJediAdapter] = {}

    def activate(self) -> None:
        return None

    def _get_adapter(self, workspace_root: Path) -> PythonJediAdapter:
        resolved_root = workspace_root.resolve()
        adapter = self._adapters.get(resolved_root)
        if adapter is None:
            adapter = self._adapter_factory(resolved_root)
            self._adapters[resolved_root] = adapter
        return adapter

    def capabilities(self, *, workspace_root: Path) -> WorkspaceIntelligenceCapabilities:
        return _build_python_jedi_capabilities(self._get_adapter(workspace_root).availability_report())

    def get_tools_for_workspace(self, workspace_root: Path) -> list[BaseTool]:
        adapter = self._get_adapter(workspace_root)
        if not adapter.availability_report().get("available"):
            return []
        return list(build_python_intelligence_tools(workspace_root=workspace_root, adapter=adapter))

    def get_status_report(self, workspace_root: Path) -> WorkspaceIntelligenceStatusReport | None:
        return _build_python_jedi_status_report(self._get_adapter(workspace_root).availability_report())