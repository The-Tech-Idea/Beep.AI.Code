"""Codebase analysis package."""
