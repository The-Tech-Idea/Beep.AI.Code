"""Project memory package."""
