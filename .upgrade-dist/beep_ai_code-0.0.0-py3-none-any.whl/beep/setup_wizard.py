"""Interactive setup wizard for Beep.AI.Code."""

from __future__ import annotations

import asyncio

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from beep.agent.provider_plugins import (
    describe_agent_provider_guidance,
    is_agent_backend_configured,
    list_available_agent_provider_guidance,
    probe_agent_backend_configuration,
)
from beep.api.client import BeepAPIClient
from beep.config import CONFIG_FILE, BeepConfig, load_config, save_config
from beep.plugins.runtime import load_runtime_plugins
from beep.workspace.detector import find_workspace_root

console = Console()


def _normalize_optional_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _mask_secret(value: str | None) -> str:
    if value is None:
        return "Not set"
    return "****" + value[-4:] if len(value) >= 4 else "****"


def _supports_interactive_provider_setup(guidance: object) -> bool:
    return bool(
        getattr(guidance, "key", None) == "beep"
        or getattr(guidance, "requires_api_key", None) is not None
        or getattr(guidance, "requires_model", None) is not None
        or getattr(guidance, "default_base_url", None) is not None
    )


def _prompt_required_text(
    label: str,
    *,
    current_value: str | None,
    required_message: str,
    normalize_url: bool = False,
) -> str:
    while True:
        response = Prompt.ask(
            label,
            default=current_value or "",
            show_default=bool(current_value),
        )
        normalized = _normalize_optional_text(response)
        if normalized is not None:
            return normalized.rstrip("/") if normalize_url else normalized
        console.print(f"[yellow]{required_message}[/yellow]")


def _prompt_secret_value(
    label: str,
    *,
    current_value: str | None,
    required: bool,
    required_message: str,
) -> str | None:
    if current_value:
        console.print(f"[dim]Current {label.strip().lower()}: {_mask_secret(current_value)}[/dim]")
        if Prompt.ask(f"  Change {label.strip().lower()}?", choices=["y", "n"], default="n") == "n":
            return current_value
    while True:
        value = _normalize_optional_text(Prompt.ask(label, password=True))
        if value is not None:
            return value
        if not required:
            return None
        console.print(f"[yellow]{required_message}[/yellow]")


async def _test_connection(config: BeepConfig) -> tuple[bool, str]:
    """Test server connection and return (success, status_message)."""
    try:
        client = BeepAPIClient(config)
        health = await client.health_check()
        await client.close()
        status = health.get("status", "unknown")
        return True, f"Status: {status}"
    except Exception as e:
        return False, str(e)


async def _test_token(config: BeepConfig) -> tuple[bool, str]:
    """Test API token validity and return (success, message)."""
    try:
        client = BeepAPIClient(config)
        result = await client.check_token()
        await client.close()
        if result.get("valid"):
            app = result.get("application", {})
            name = app.get("name", "unknown")
            scopes = result.get("scopes", [])
            scope_str = ", ".join(scopes) if scopes else "none"
            return True, f"App: {name} | Scopes: {scope_str}"
        return False, result.get("error", "Token invalid")
    except Exception as e:
        return False, str(e)


def run_setup_wizard() -> BeepConfig:
    """Run interactive setup wizard."""
    console.print()
    console.print(
        Panel.fit(
            "[bold blue]Beep.AI.Code Setup[/bold blue]\n\nConnect to your Beep.AI.Server instance",
            style="blue",
        )
    )
    console.print()

    existing = load_config()

    # Step 1: Server URL
    console.print("[bold cyan]Step 1/3: Server URL[/bold cyan]")
    console.print("[dim]The URL where Beep.AI.Server is running[/dim]")
    console.print()

    server_url = Prompt.ask(
        "  Server URL",
        default=existing.server_url,
        show_default=True,
    )

    server_url = server_url.rstrip("/")
    if not server_url.startswith(("http://", "https://")):
        server_url = "http://" + server_url

    # Step 2: API Token
    console.print()
    console.print("[bold cyan]Step 2/3: API Token[/bold cyan]")
    console.print("[dim]Application token from Beep.AI.Server IAM settings[/dim]")
    console.print("[dim]Create one: Server Dashboard → IAM → Applications → Create Token[/dim]")
    console.print()

    if existing.api_token:
        masked = "****" + existing.api_token[-4:]
        console.print(f"[dim]Current token: {masked}[/dim]")
        if Prompt.ask("  Change token?", choices=["y", "n"], default="n") == "n":
            api_token = existing.api_token
        else:
            api_token = Prompt.ask("  API Token", password=True)
    else:
        api_token = Prompt.ask("  API Token", password=True)

    if not api_token.strip():
        api_token = None

    # Step 3: Default model (optional)
    console.print()
    console.print("[bold cyan]Step 3/3: Default Model (optional)[/bold cyan]")
    console.print("[dim]Leave empty to use the server's default model[/dim]")
    console.print()

    default_model = Prompt.ask(
        "  Default model",
        default=existing.default_model or "",
        show_default=False,
    )
    if not default_model.strip():
        default_model = None

    # Build config
    config = BeepConfig(
        server_url=server_url,
        api_token=api_token,
        default_model=default_model,
        agent_backend=existing.agent_backend,
        agent_base_url=existing.agent_base_url,
        agent_api_key=existing.agent_api_key,
        agent_model=existing.agent_model,
        max_tokens=existing.max_tokens,
        temperature=existing.temperature,
        project_id=existing.project_id,
        mcp_enabled=existing.mcp_enabled,
        mcp_servers=existing.mcp_servers,
        request_timeout=existing.request_timeout,
        retry_on_429=existing.retry_on_429,
        max_retries=existing.max_retries,
    )

    # Test connection
    console.print()
    with console.status("[bold]Testing server connection..."):
        success, message = asyncio.run(_test_connection(config))

    if success:
        console.print(f"  [green]✓ Server reachable — {message}[/green]")
    else:
        console.print(f"  [red]✗ Server unreachable — {message}[/red]")
        console.print()
        if Prompt.ask("  Continue anyway?", choices=["y", "n"], default="n") == "n":
            console.print("[yellow]Setup cancelled[/yellow]")
            raise SystemExit(1)

    # Test token if provided
    if api_token:
        with console.status("[bold]Validating API token..."):
            token_ok, token_msg = asyncio.run(_test_token(config))

        if token_ok:
            console.print(f"  [green]✓ Token valid — {token_msg}[/green]")
        else:
            console.print(f"  [yellow]⚠ Token check failed — {token_msg}[/yellow]")
            console.print("[dim](Server may not have token check endpoint)[/dim]")

    # Save
    save_config(config)
    console.print()
    console.print(
        Panel.fit(
            f"[green]Configuration saved[/green]\n\n[dim]{CONFIG_FILE}[/dim]",
            style="green",
        )
    )
    console.print()

    return config


def run_agent_provider_setup_wizard(provider_key: str | None = None) -> BeepConfig:
    """Run an interactive setup flow for the selected autonomous-agent provider."""
    existing = load_config()
    plugin_registry = load_runtime_plugins(find_workspace_root()).registry
    selected_key = _normalize_optional_text(provider_key) or existing.agent_backend

    try:
        guidance = describe_agent_provider_guidance(
            existing,
            provider_key=selected_key,
            plugin_registry=plugin_registry,
        )
    except ValueError:
        providers = list_available_agent_provider_guidance(existing, plugin_registry=plugin_registry)
        console.print(f"[red]Unsupported agent backend: {selected_key}[/red]")
        console.print(
            "[dim]Available providers: "
            + ", ".join(provider.key for provider in providers)
            + "[/dim]"
        )
        raise SystemExit(1)

    if not _supports_interactive_provider_setup(guidance):
        raise RuntimeError(
            f"Agent backend '{guidance.key}' does not expose enough setup metadata for the interactive wizard. Configure the provider's required settings via `beep config-set` or the provider plugin's documented setup."
        )

    if guidance.key == "beep":
        config = run_setup_wizard()
        if config.agent_backend != "beep":
            config.agent_backend = "beep"
            save_config(config)
        return config

    console.print()
    console.print(
        Panel.fit(
            f"[bold blue]Agent Provider Setup[/bold blue]\n\nConfigure {guidance.display_name} ({guidance.key})",
            style="blue",
        )
    )
    console.print(f"[dim]Source: {guidance.source}[/dim]")
    for note in guidance.notes:
        console.print(f"[dim]- {note}[/dim]")

    config = existing.model_copy(deep=True)
    config.agent_backend = guidance.key

    console.print()
    console.print("[bold cyan]Connection[/bold cyan]")
    if guidance.default_base_url is not None:
        if config.agent_base_url:
            console.print(f"[dim]Current agent base URL override: {config.agent_base_url.rstrip('/')}[/dim]")
        console.print(f"[dim]Default base URL: {guidance.default_base_url}[/dim]")
        base_url_override = Prompt.ask(
            "  Agent base URL override (leave empty to use the provider default)",
            default=config.agent_base_url or "",
            show_default=bool(config.agent_base_url),
        )
        config.agent_base_url = _normalize_optional_text(base_url_override)
        if config.agent_base_url is not None:
            config.agent_base_url = config.agent_base_url.rstrip("/")
    else:
        config.agent_base_url = _prompt_required_text(
            "  Agent base URL",
            current_value=config.agent_base_url,
            required_message="Agent base URL is required for this provider.",
            normalize_url=True,
        )

    if guidance.requires_api_key:
        console.print()
        console.print("[bold cyan]Authentication[/bold cyan]")
        config.agent_api_key = _prompt_secret_value(
            "  Agent API key",
            current_value=config.agent_api_key,
            required=True,
            required_message="Agent API key is required for this provider.",
        )

    if guidance.requires_model:
        console.print()
        console.print("[bold cyan]Model[/bold cyan]")
        config.agent_model = _prompt_required_text(
            "  Agent model",
            current_value=config.agent_model or config.default_model,
            required_message="Agent model is required for this provider.",
        )

    if not is_agent_backend_configured(config, plugin_registry=plugin_registry):
        raise RuntimeError(
            f"Agent backend '{guidance.key}' is still not configured after setup. Configure the remaining settings via `beep config-set` or the provider plugin's documented setup."
        )

    with console.status("[bold]Validating agent provider...[/bold]"):
        probe_result = asyncio.run(
            probe_agent_backend_configuration(config, plugin_registry=plugin_registry)
        )

    if probe_result.supported:
        if probe_result.success:
            console.print(f"  [green]✓ Provider reachable — {probe_result.message}[/green]")
        else:
            console.print(f"  [yellow]⚠ Provider probe failed — {probe_result.message}[/yellow]")
            console.print()
            if Prompt.ask("  Continue anyway?", choices=["y", "n"], default="n") == "n":
                console.print("[yellow]Setup cancelled[/yellow]")
                raise SystemExit(1)
    else:
        console.print(f"[dim]Skipping provider validation — {probe_result.message}[/dim]")

    save_config(config)
    console.print()
    console.print(
        Panel.fit(
            f"[green]Agent provider configuration saved[/green]\n\n[dim]{guidance.display_name} ({guidance.key})[/dim]",
            style="green",
        )
    )
    console.print()
    return config


def ensure_configured() -> BeepConfig:
    """Ensure configuration exists, running wizard if needed.

    Returns the loaded (or newly created) config.
    Exits if user cancels setup.
    """
    config = load_config()

    # Check env vars first
    import os

    has_env_token = bool(os.environ.get("BEEP_API_TOKEN"))
    has_env_url = bool(os.environ.get("BEEP_SERVER_URL"))

    if has_env_token and has_env_url:
        return config

    if config.is_configured:
        return config

    # Not configured — run wizard
    console.print()
    console.print("[yellow]Beep.AI.Code is not configured.[/yellow]")
    console.print("[dim]Run 'beep setup' to configure manually.[/dim]")
    console.print()

    try:
        answer = Prompt.ask(
            "Run setup wizard now?",
            choices=["y", "n"],
            default="y",
        )
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Setup cancelled[/yellow]")
        raise SystemExit(1)

    if answer.lower() != "y":
        console.print("[yellow]Run 'beep setup' when ready[/yellow]")
        raise SystemExit(1)

    try:
        return run_setup_wizard()
    except SystemExit:
        raise
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Setup cancelled[/yellow]")
        raise SystemExit(1)


def ensure_agent_configured() -> BeepConfig:
    """Ensure the autonomous agent backend has enough configuration to run."""
    config = load_config()
    plugin_registry = load_runtime_plugins(find_workspace_root()).registry
    if is_agent_backend_configured(config, plugin_registry=plugin_registry):
        return config
    guidance = describe_agent_provider_guidance(config, plugin_registry=plugin_registry)
    if _supports_interactive_provider_setup(guidance):
        return run_agent_provider_setup_wizard(config.agent_backend)
    raise RuntimeError(
        f"Agent backend '{config.agent_backend}' is not configured. Configure the provider's required settings via `beep config-set` or the provider plugin's documented setup."
    )
