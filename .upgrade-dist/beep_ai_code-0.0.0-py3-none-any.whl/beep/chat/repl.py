"""Interactive chat REPL — Claude Code style.

Uses command registry for all slash commands.
Supports @file mentions, pinned files, multi-line input.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from beep.api.client import BeepAPIClient
from beep.chat.coding_bridge import bootstrap_coding_workspace
from beep.chat.command_registry import build_custom_command_registry
from beep.chat.commands.llm_turns import stream_assistant_turn
from beep.chat.context import ChatContext
from beep.chat.input import read_multiline
from beep.coding.metadata import build_coding_metadata
from beep.coding.prompt_context import build_workspace_system_prompt
from beep.coding.response_metadata import count_pending_approvals, find_coding_identity
from beep.plugins.runtime import PluginRuntime
from beep.rules.resolver import build_rules_context
from beep.runtime.workspace import get_workspace_runtime
from beep.sessions.history import create_session_id, save_message
from beep.skills.resolver import SkillResolver
from beep.utils.json_logging import log_event
from beep.workspace.detector import find_workspace_root
from beep.workspace.git import get_git_status, is_git_repo

console = Console()


class ChatSession:
    """Manages a chat conversation session."""

    def __init__(
        self,
        client: BeepAPIClient,
        *,
        model: str | None = None,
        mode: str = "assistant",
        show_tokens: bool = False,
        plugins_enabled: bool = True,
        session_id: str | None = None,
        config: Any = None,
    ) -> None:
        self._client = client
        self._model = model
        self._mode = mode
        self._show_tokens = show_tokens
        self._session_id = session_id or create_session_id()
        self._config = config
        self._messages: list[dict[str, str]] = []
        self._edit_target: Path | None = None
        self._token_count: int = 0
        self._request_count: int = 0
        self._last_edit: dict[str, Any] | None = None
        self._last_output: str = ""
        self._sandbox: bool = False
        self._max_token_budget: int | None = None
        runtime = get_workspace_runtime(find_workspace_root(), plugins_enabled=plugins_enabled)
        self._workspace = runtime.workspace
        self._memory = runtime.memory
        self._context = ChatContext(self._workspace)
        # Merge built-in commands with project-defined custom commands
        custom_commands = build_custom_command_registry(runtime.memory.commands)
        self._commands = {**runtime.commands, **custom_commands}
        self._plugins_enabled = plugins_enabled
        self._plugin_runtime: PluginRuntime = runtime.plugin_runtime
        self._plugin_commands = runtime.plugin_commands
        self._rules, self._rule_errors = runtime.rules, runtime.rule_errors
        self._skills = runtime.skills
        self._skill_errors, self._skill_roots = runtime.skill_errors, runtime.skill_roots
        self._skill_resolver = SkillResolver(self._skills)
        self._skills_enabled = True
        self._coding_project_id: int | None = None
        self._coding_session_id: str | None = None
        self._coding_enabled: bool = True
        self._messages = [{"role": "system", "content": self._build_system_prompt_content(mode)}]

    def _build_system_prompt_content(self, mode: str) -> str:
        """Build system prompt with project memory and plugin context."""
        extra_sections = []
        plugin_context = self._plugin_runtime.registry.get_context().strip()
        if plugin_context:
            extra_sections.append("## Plugin Context\n\n" + plugin_context)
        return build_workspace_system_prompt(
            mode,
            self._workspace,
            extra_sections=extra_sections,
        )

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def coding_project_id(self) -> int | None:
        return self._coding_project_id

    @property
    def coding_session_id(self) -> str | None:
        return self._coding_session_id

    @property
    def coding_enabled(self) -> bool:
        return self._coding_enabled

    @property
    def plugins_enabled(self) -> bool:
        return self._plugins_enabled

    def set_coding_enabled(self, enabled: bool) -> None:
        self._coding_enabled = enabled

    def _get_coding_metadata(self) -> dict[str, Any] | None:
        """Get coding_assistant metadata for chat requests."""
        if not self._coding_enabled:
            return None
        if self._coding_project_id:
            return build_coding_metadata(
                workspace_root=self._workspace,
                interaction_mode="inline",
                project_id=self._coding_project_id,
                session_id=self._coding_session_id,
            )
        configured_project_id = getattr(self._config, "project_id", None)
        return build_coding_metadata(
            workspace_root=self._workspace,
            interaction_mode="inline",
            project_id=configured_project_id,
        )

    async def _bootstrap_workspace(self) -> None:
        """Resolve workspace with server and get project/session IDs."""
        if not self._coding_enabled:
            return
        try:
            self._coding_project_id, self._coding_session_id = await bootstrap_coding_workspace(
                self._client,
                workspace=self._workspace,
                config=self._config,
                model=self._model,
                console=console,
            )
        except Exception as e:
            console.print(f"[dim]Workspace bootstrap skipped: {e}[/dim]")
            log_event("coding.bootstrap.error", error=str(e))

    @property
    def messages(self) -> list[dict[str, str]]:
        return self._messages

    def clear_history(self) -> None:
        self._messages = [self._messages[0]]

    def set_model(self, model: str | None) -> None:
        self._model = model

    def set_mode(self, mode: str) -> None:
        self._mode = mode
        self._messages[0] = {"role": "system", "content": self._build_system_prompt_content(mode)}

    def _save(self, role: str, content: str) -> None:
        save_message(self._session_id, {"role": role, "content": content})

    def resume_session(self, session_id: str) -> bool:
        from beep.sessions.history import load_session

        messages = load_session(session_id)
        if not messages:
            console.print(f"[yellow]No history found: {session_id}[/yellow]")
            return False
        self._session_id = session_id
        self._messages = [
            {"role": "system", "content": self._build_system_prompt_content(self._mode)}
        ] + messages
        self._coding_project_id = None
        self._coding_session_id = None
        self._last_output = ""
        self._token_count = 0
        self._request_count = sum(1 for msg in messages if msg.get("role") == "user")
        console.print(f"[green]Resumed: {session_id} ({len(messages)} messages)[/green]")
        return True

    async def send(self, user_input: str) -> None:
        budget = self._max_token_budget
        if budget is not None and self._token_count >= budget:
            console.print(
                "[yellow]Token budget reached. Increase with /max_tokens "
                "or start a new session.[/yellow]"
            )
            log_event(
                "chat.request.blocked_budget",
                session_id=self._session_id,
                token_count=self._token_count,
                token_budget=budget,
            )
            return

        cleaned, included = self._context.resolve_mentions(user_input)

        pinned_context = self._context.build_context()
        skill_context = self._build_skill_context(cleaned)
        rules_context = build_rules_context(self._rules)
        segments = []
        if pinned_context:
            segments.append(pinned_context)
        if rules_context:
            segments.append(rules_context)
        if skill_context:
            segments.append(skill_context)
        segments.append(cleaned)
        full_input = "\n\n".join(segments)

        if included:
            console.print(f"[dim]Included: {', '.join(included)}[/dim]")

        self._messages.append({"role": "user", "content": full_input})
        self._save("user", user_input)
        await stream_assistant_turn(
            session=self,
            client=self._client,
            event="request",
            empty_message="[yellow]Model returned an empty response[/yellow]",
            empty_error="empty_response",
        )

    def _update_coding_ids(self, response: str) -> None:
        """Update project/session IDs from first coding response."""
        project_id, session_id = find_coding_identity(response)
        if project_id is None and session_id is None:
            return

        if project_id is not None:
            self._coding_project_id = project_id
        if session_id:
            self._coding_session_id = session_id

        log_event(
            "coding.ids.updated",
            project_id=self._coding_project_id,
            session_id=self._coding_session_id,
        )

    def _handle_coding_approvals(self, response_text: str) -> None:
        """Display pending code changes from server response."""
        pending_count = count_pending_approvals(response_text)
        if pending_count <= 0:
            return

        console.print(
            f"[yellow]Pending coding approvals detected: {pending_count}. "
            "Review server-side changes before continuing.[/yellow]"
        )
        log_event("coding.approvals.pending", count=pending_count, session_id=self._session_id)

    def _show_welcome(self) -> None:
        memory_info = ""
        if self._memory.global_instructions:
            memory_info = " | [yellow]project memory[/yellow]"

        git_info = ""
        if is_git_repo(self._workspace):
            status = get_git_status(self._workspace)
            if status:
                n = len(status.splitlines())
                git_info = f" | [dim]{n} changed[/dim]"

        pinned = self._context.pinned_files
        pin_info = ""
        if pinned:
            names = ", ".join(p.name for p in pinned)
            pin_info = f" | [dim]pinned: {names}[/dim]"

        coding_info = ""
        if self._coding_project_id:
            coding_info = f" | [green]coding: project {self._coding_project_id}[/green]"
        elif self._coding_enabled:
            coding_info = " | [yellow]coding: bootstrap pending[/yellow]"
        else:
            coding_info = " | [dim]coding: off[/dim]"

        plugin_count = len(self._plugin_runtime.registry.list_plugins())
        plugin_info = f" | [dim]plugins: {plugin_count}[/dim]"
        skill_info = f" | [dim]skills: {len(self._skills)}[/dim]"
        rule_info = f" | [dim]rules: {len(self._rules)}[/dim]"

        model_display = self._model or "[dim]default[/dim]"

        console.print(
            Panel.fit(
                f"[bold blue]Beep.AI.Code[/bold blue]\n"
                f"Workspace: [cyan]{self._workspace.name}[/cyan]"
                f"{memory_info}{git_info}{pin_info}{coding_info}{plugin_info}{skill_info}{rule_info}\n"
                f"Model: {model_display} | Mode: [cyan]{self._mode}[/cyan] | "
                f"Session: [dim]{self._session_id}[/dim]",
                border_style="blue",
            )
        )
        console.print("Type [cyan]/help[/cyan] for commands, [cyan]/quit[/cyan] to exit\n")

    async def run(self) -> None:
        await self._bootstrap_workspace()
        self._show_welcome()

        while True:
            if self._edit_target:
                console.print(
                    f"[yellow]Enter content for {self._edit_target} "
                    f"(empty line to finish):[/yellow]"
                )
                lines = []
                while True:
                    try:
                        line = Prompt.ask("  ...")
                    except (KeyboardInterrupt, EOFError):
                        break
                    if not line:
                        break
                    lines.append(line)
                if lines:
                    from beep.workspace.file_ops import apply_edit

                    content = "\n".join(lines)
                    old = self._edit_target.read_text(encoding="utf-8")
                    self._last_edit = {
                        "path": self._edit_target,
                        "old": old,
                        "new": content,
                    }
                    apply_edit(self._edit_target, old, content, require_confirm=True)
                self._edit_target = None
                continue

            user_input = read_multiline(
                commands={name: cmd.description for name, cmd in self._commands.items()},
                workspace_root=self._workspace,
            )
            if user_input is None:
                console.print()
                break

            if user_input.startswith("/"):
                await self._handle_command(user_input)
                continue

            await self.send(user_input)

    async def _handle_command(self, command: str) -> None:
        parts = command.split(maxsplit=1)
        cmd_name = parts[0].lower().lstrip("/")
        args = parts[1].strip() if len(parts) > 1 else ""

        cmd = self._commands.get(cmd_name)
        if not cmd:
            try:
                response = await self._plugin_runtime.registry.handle_plugin_command(cmd_name, args)
            except Exception as e:
                console.print(f"[red]Plugin command error: {e}[/red]")
                log_event(
                    "chat.command.plugin.error",
                    session_id=self._session_id,
                    command=cmd_name,
                    error=str(e),
                )
                return
            if response is not None:
                log_event(
                    "chat.command.plugin.success",
                    session_id=self._session_id,
                    command=cmd_name,
                )
                console.print(response)
                return
            log_event(
                "chat.command.unknown",
                session_id=self._session_id,
                command=cmd_name,
            )
            console.print(f"[yellow]Unknown command: /{cmd_name}[/yellow]")
            return

        ctx: dict[str, Any] = {
            "client": self._client,
            "session": self,
            "session_id": self._session_id,
            "chat_context": self._context,
            "command_registry": self._commands,
            "config": self._config,
            "plugin_runtime": self._plugin_runtime,
            "plugin_commands": self._plugin_commands,
        }

        log_event(
            "chat.command.start",
            session_id=self._session_id,
            command=cmd_name,
        )
        try:
            await cmd.execute(args, ctx)
            log_event(
                "chat.command.success",
                session_id=self._session_id,
                command=cmd_name,
            )
        except KeyboardInterrupt:
            raise
        except Exception as e:
            console.print(f"[red]Command error: {e}[/red]")
            log_event(
                "chat.command.error",
                session_id=self._session_id,
                command=cmd_name,
                error=str(e),
            )

    def _build_skill_context(self, user_input: str) -> str:
        if not self._skills_enabled:
            return ""
        matches = self._skill_resolver.resolve(user_input, max_skills=3, budget_chars=3000)
        if not matches:
            return ""
        lines = ["## Active Skills"]
        for match in matches:
            lines.append(f"\n### {match.skill.name}\n{match.skill.body}")
        return "\n".join(lines).strip()
