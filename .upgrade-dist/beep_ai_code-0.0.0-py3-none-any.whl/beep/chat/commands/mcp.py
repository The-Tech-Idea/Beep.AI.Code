"""MCP slash command — inspect MCP bridge tools and servers."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.table import Table

from beep.chat.commands.base import Command

console = Console()


class McpCommand(Command):
    """Inspect the MCP bridge: list servers and available tools."""

    @property
    def name(self) -> str:
        return "mcp"

    @property
    def description(self) -> str:
        return "Inspect MCP bridge: /mcp tools | /mcp servers"

    @property
    def category(self) -> str:
        return "Integration"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        sub = args.strip().split()[0].lower() if args.strip() else "tools"

        mcp_client = ctx.get("mcp_client")

        if sub == "servers":
            self._show_servers(mcp_client)
        else:
            self._show_tools(mcp_client)

    def _show_servers(self, mcp_client: Any) -> None:
        if mcp_client is None:
            console.print("[yellow]MCP bridge not active in this session.[/yellow]")
            return
        servers = mcp_client.list_servers()
        if not servers:
            console.print("[yellow]No MCP servers registered.[/yellow]")
            return
        t = Table(title="MCP Servers", show_lines=True)
        t.add_column("Server", style="cyan")
        for name in servers:
            t.add_row(name)
        console.print(t)

    def _show_tools(self, mcp_client: Any) -> None:
        if mcp_client is None:
            console.print("[yellow]MCP bridge not active in this session.[/yellow]")
            return
        tools = mcp_client.list_tools()
        if not tools:
            console.print("[yellow]No MCP tools available.[/yellow]")
            return
        t = Table(title="MCP Tools", show_lines=True)
        t.add_column("Tool", style="cyan")
        t.add_column("Server", style="dim")
        t.add_column("Description")
        for tool in tools:
            t.add_row(tool.name, tool.server_name, tool.description)
        console.print(t)
