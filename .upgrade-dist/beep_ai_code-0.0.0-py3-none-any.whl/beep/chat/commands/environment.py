"""Environment and local session control slash commands."""

from __future__ import annotations

from typing import Any

from rich.console import Console

from beep.chat.commands.base import Command

console = Console()


class HooksCommand(Command):
    @property
    def name(self) -> str:
        return "hooks"

    @property
    def description(self) -> str:
        return "Manage pre/post hooks"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, args: str, _ctx: dict[str, Any]) -> None:
        from beep.hooks.manager import load_hooks, save_hooks

        config = load_hooks()

        if not args:
            if not config.hooks:
                console.print("[yellow]No hooks configured[/yellow]")
                return
            console.print("[bold]Hooks:[/bold]")
            for i, h in enumerate(config.hooks):
                status = "[green]on[/green]" if h.enabled else "[red]off[/red]"
                console.print(f"  {i}. [{h.event}] {h.command} {status}")
            return

        parts = args.split(maxsplit=2)
        action = parts[0].lower()

        if action == "add" and len(parts) >= 3:
            config.add(parts[1], parts[2])
            save_hooks(config)
            console.print(f"[green]Hook added: {parts[1]} -> {parts[2]}[/green]")
        elif action == "remove" and len(parts) >= 2:
            if config.remove(int(parts[1])):
                save_hooks(config)
                console.print("[green]Hook removed[/green]")
        elif action == "toggle" and len(parts) >= 2:
            if config.toggle(int(parts[1])):
                save_hooks(config)
                console.print("[green]Hook toggled[/green]")
        else:
            console.print(
                "[yellow]Usage: /hooks | /hooks add <event> <cmd> | "
                "/hooks remove <n> | /hooks toggle <n>[/yellow]"
            )


class InstallCommand(Command):
    @property
    def name(self) -> str:
        return "install"

    @property
    def description(self) -> str:
        return "Auto-detect and install dependencies"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, args: str, _ctx: dict[str, Any]) -> None:
        import asyncio

        from beep.workspace.detector import find_workspace_root

        root = find_workspace_root()
        packages = args.split() if args else []

        if (root / "requirements.txt").exists():
            console.print("[dim]Installing from requirements.txt...[/dim]")
            proc = await asyncio.create_subprocess_exec(
                "pip",
                "install",
                "-r",
                "requirements.txt",
                cwd=root,
            )
            await proc.wait()
        elif (root / "package.json").exists():
            console.print("[dim]Installing from package.json...[/dim]")
            proc = await asyncio.create_subprocess_exec(
                "npm",
                "install",
                cwd=root,
            )
            await proc.wait()
        elif packages:
            console.print(f"[dim]Installing: {', '.join(packages)}[/dim]")
            proc = await asyncio.create_subprocess_exec(
                "pip",
                "install",
                *packages,
            )
            await proc.wait()
        else:
            console.print("[yellow]No dependency file found. Usage: /install <packages>[/yellow]")


class SandboxCommand(Command):
    @property
    def name(self) -> str:
        return "sandbox"

    @property
    def description(self) -> str:
        return "Toggle sandbox mode"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        session._sandbox = not getattr(session, "_sandbox", False)
        status = "[green]ON[/green]" if session._sandbox else "[red]OFF[/red]"
        console.print(f"Sandbox mode: {status}")


class MaxTokensCommand(Command):
    @property
    def name(self) -> str:
        return "max_tokens"

    @property
    def description(self) -> str:
        return "Set session token budget"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        if not args:
            session = ctx["session"]
            budget = getattr(session, "_max_token_budget", "unlimited")
            console.print(f"Token budget: [cyan]{budget}[/cyan]")
            return

        try:
            limit = int(args)
            ctx["session"]._max_token_budget = limit
            console.print(f"[green]Token budget: {limit:,}[/green]")
        except ValueError:
            console.print("[yellow]Usage: /max_tokens <number>[/yellow]")
