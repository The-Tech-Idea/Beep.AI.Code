"""Session commands: /clear, /resume, /sessions, /session, /compact."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.table import Table

from beep.chat.commands.base import Command
from beep.sessions.history import (
    SessionSummary,
    _relative_time,
    create_session_id,
    export_session,
    list_sessions,
    replace_session,
)

console = Console()


class ClearCommand(Command):
    @property
    def name(self) -> str:
        return "clear"

    @property
    def description(self) -> str:
        return "Start new session"

    @property
    def category(self) -> str:
        return "Chat"

    @property
    def aliases(self) -> list[str]:
        return ["c"]

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        session._session_id = create_session_id()
        session.clear_history()
        session._token_count = 0
        session._request_count = 0
        session._last_output = ""
        session._coding_project_id = None
        session._coding_session_id = None
        session._edit_target = None
        session._last_edit = None
        console.print(f"[green]New session: {session._session_id}[/green]")


class CompactCommand(Command):
    @property
    def name(self) -> str:
        return "compact"

    @property
    def description(self) -> str:
        return "Compress conversation context"

    @property
    def category(self) -> str:
        return "Chat"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        if len(session._messages) <= 2:
            console.print("[yellow]Nothing to compact[/yellow]")
            return

        client = ctx["client"]
        try:
            result = await client.compact_conversation(
                session_id=session._session_id,
                messages=session._messages,
            )
            compacted = result.get("messages")
            if isinstance(compacted, list) and compacted:
                session._messages = compacted
                replace_session(session._session_id, session._messages)
                console.print(
                    f"[green]Compacted on server to {len(session._messages)} messages[/green]"
                )
                return
        except Exception:
            # Endpoint may not exist on all server versions; local fallback below.
            pass

        system = session._messages[0]
        # Keep system + last 5 non-system messages (≤ 6 total, ~2 full turns)
        last_msgs = session._messages[1:][-5:]
        session._messages = [system] + last_msgs
        replace_session(session._session_id, session._messages)
        console.print(
            f"[green]Compacted locally to {len(session._messages)} messages[/green]"
        )


class UndoCommand(Command):
    @property
    def name(self) -> str:
        return "undo"

    @property
    def description(self) -> str:
        return "Remove last user/assistant exchange"

    @property
    def category(self) -> str:
        return "Chat"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        msgs = session._messages
        # Need at least system + user to have something to undo
        if len(msgs) < 2:
            console.print("[yellow]Nothing to undo[/yellow]")
            return
        # Remove the last assistant then the last user message
        if msgs[-1].get("role") == "assistant" and msgs[-2].get("role") == "user":
            session._messages = msgs[:-2]
            console.print("[green]Last exchange removed[/green]")
        elif msgs[-1].get("role") == "user":
            session._messages = msgs[:-1]
            console.print("[green]Last message removed[/green]")
        else:
            console.print("[yellow]Nothing to undo[/yellow]")


class ResumeCommand(Command):
    @property
    def name(self) -> str:
        return "resume"

    @property
    def description(self) -> str:
        return "Resume a previous session"

    @property
    def category(self) -> str:
        return "Chat"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        if not args:
            console.print("[yellow]Usage: /resume <session_id>[/yellow]")
            return
        session = ctx["session"]
        session.resume_session(args)


class SessionCommand(Command):
    @property
    def name(self) -> str:
        return "session"

    @property
    def description(self) -> str:
        return "Show current session ID"

    @property
    def category(self) -> str:
        return "Chat"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        console.print(f"Session: [cyan]{session._session_id}[/cyan]")


class SessionsCommand(Command):
    @property
    def name(self) -> str:
        return "sessions"

    @property
    def description(self) -> str:
        return "List, export, or search sessions"

    @property
    def category(self) -> str:
        return "Chat"

    async def execute(self, args: str, _ctx: dict[str, Any]) -> None:
        parts = args.strip().split(None, 1)
        sub = parts[0].lower() if parts else "list"
        sub_args = parts[1] if len(parts) > 1 else ""

        if sub in ("list", ""):
            await self._list()
        elif sub == "export":
            await self._export(sub_args.strip())
        else:
            # Treat bare /sessions as /sessions list
            await self._list()

    async def _list(self) -> None:
        summaries: list[SessionSummary] = list_sessions()
        if not summaries:
            console.print("[yellow]No sessions[/yellow]")
            return

        table = Table(title="Sessions")
        table.add_column("ID", style="cyan")
        table.add_column("Messages", justify="right")
        table.add_column("Created", style="dim")
        table.add_column("Preview", style="dim", no_wrap=False, max_width=40)
        for s in summaries[:20]:
            table.add_row(
                s.session_id,
                str(s.message_count),
                _relative_time(s.created_at),
                s.last_message_preview[:60] if s.last_message_preview else "",
            )
        console.print(table)

    async def _export(self, args: str) -> None:
        parts = args.split(None, 1)
        if not parts:
            console.print("[yellow]Usage: /sessions export <session_id> [md|json][/yellow]")
            return
        sid = parts[0]
        fmt = parts[1].strip() if len(parts) > 1 else "md"
        if fmt not in ("md", "json"):
            console.print("[yellow]Format must be 'md' or 'json'[/yellow]")
            return
        output = export_session(sid, format=fmt)
        if not output:
            console.print(f"[yellow]No session found: {sid}[/yellow]")
            return
        console.print(output)
