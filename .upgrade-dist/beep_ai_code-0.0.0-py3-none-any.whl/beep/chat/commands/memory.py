"""Memory-related slash commands."""

from __future__ import annotations

from typing import Any

from rich.console import Console

from beep.chat.commands.base import Command

console = Console()


class MemoryReloadCommand(Command):
    """Reload project memory and workspace rules from disk."""

    @property
    def name(self) -> str:
        return "memory"

    @property
    def description(self) -> str:
        return "Manage project memory. /memory reload — reload .beep.md and rules from disk"

    @property
    def category(self) -> str:
        return "System"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        sub = args.strip().lower()
        if sub not in ("", "reload"):
            console.print("[yellow]Usage: /memory reload[/yellow]")
            return

        from beep.chat.command_registry import build_custom_command_registry
        from beep.runtime.workspace import clear_workspace_runtime_cache, get_workspace_runtime
        from beep.skills.resolver import SkillResolver

        clear_workspace_runtime_cache()
        session = ctx.get("session")
        if session is None:
            console.print("[green]Cache cleared. Memory will reload on next action.[/green]")
            return

        workspace = getattr(session, "_workspace", None)
        plugins_enabled = getattr(session, "_plugins_enabled", True)
        if workspace is None:
            console.print("[green]Cache cleared. Memory will reload on next action.[/green]")
            return

        runtime = get_workspace_runtime(workspace, plugins_enabled=plugins_enabled)
        session._memory = runtime.memory
        session._rules = runtime.rules
        session._rule_errors = runtime.rule_errors
        session._skills = runtime.skills
        session._skill_errors = runtime.skill_errors
        session._skill_roots = runtime.skill_roots
        session._skill_resolver = SkillResolver(runtime.skills)

        # Rebuild command registry with updated custom commands
        base_commands = dict(runtime.commands)
        custom = build_custom_command_registry(runtime.memory.commands)
        base_commands.update(custom)
        session._commands = base_commands

        console.print("[green]Memory reloaded.[/green]")
        if runtime.memory.global_instructions:
            console.print(
                f"[dim]Project instructions: "
                f"{len(runtime.memory.global_instructions)} chars[/dim]"
            )
        if runtime.memory.commands:
            console.print(f"[dim]Custom commands: {list(runtime.memory.commands.keys())}[/dim]")
        if runtime.rules:
            console.print(f"[dim]Rules: {len(runtime.rules)} loaded[/dim]")
