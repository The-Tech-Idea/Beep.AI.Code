"""Plugin, skill, and rule inspection slash commands."""

from __future__ import annotations

from typing import Any

from rich.console import Console

from beep.chat.commands.base import Command

console = Console()


class PluginsCommand(Command):
    @property
    def name(self) -> str:
        return "plugins"

    @property
    def description(self) -> str:
        return "List loaded plugins and load issues"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        runtime = ctx.get("plugin_runtime")
        if runtime is None:
            console.print("[yellow]Plugin runtime unavailable[/yellow]")
            return

        searched = runtime.searched_paths
        if searched:
            console.print("[bold]Plugin search paths:[/bold]")
            for path in searched:
                console.print(f"  - {path}")

        plugins = runtime.registry.list_plugins()
        if plugins:
            console.print("\n[bold]Loaded plugins:[/bold]")
            for plugin in plugins:
                console.print(
                    f"  - {plugin['name']} v{plugin['version']} "
                    f"({plugin['type']}) - {plugin['description']}"
                )
        else:
            console.print("\n[yellow]No plugins loaded[/yellow]")

        errors = runtime.registry.get_load_errors()
        if errors:
            console.print("\n[bold red]Load errors:[/bold red]")
            for error in errors:
                console.print(f"  - {error}")


class SkillsCommand(Command):
    @property
    def name(self) -> str:
        return "skills"

    @property
    def description(self) -> str:
        return "List loaded skills and status"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        enabled = getattr(session, "_skills_enabled", True)
        status = "[green]enabled[/green]" if enabled else "[yellow]disabled[/yellow]"
        console.print(f"Skills: {status}")

        roots = getattr(session, "_skill_roots", [])
        if roots:
            console.print("[bold]Skill search paths:[/bold]")
            for root in roots:
                console.print(f"  - {root}")

        skills = getattr(session, "_skills", [])
        if skills:
            console.print("\n[bold]Loaded skills:[/bold]")
            for skill in skills:
                triggers = ", ".join(skill.triggers) if skill.triggers else "none"
                console.print(
                    f"  - {skill.name} (priority={skill.priority}, inject={skill.inject}, "
                    f"triggers={triggers})"
                )
        else:
            console.print("\n[yellow]No skills loaded[/yellow]")

        errors = getattr(session, "_skill_errors", [])
        if errors:
            console.print("\n[bold red]Load errors:[/bold red]")
            for error in errors:
                console.print(f"  - {error}")


class SkillCommand(Command):
    @property
    def name(self) -> str:
        return "skill"

    @property
    def description(self) -> str:
        return "Control skills: /skill on|off"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        action = args.strip().lower()
        if action == "off":
            session._skills_enabled = False
            console.print("[yellow]Skills disabled for this session[/yellow]")
            return
        if action == "on":
            session._skills_enabled = True
            console.print("[green]Skills enabled for this session[/green]")
            return
        console.print("[yellow]Usage: /skill on | /skill off[/yellow]")


class RulesCommand(Command):
    @property
    def name(self) -> str:
        return "rules"

    @property
    def description(self) -> str:
        return "Show active rule sources"

    @property
    def category(self) -> str:
        return "General"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        session = ctx["session"]
        rules = getattr(session, "_rules", [])
        if not rules:
            console.print("[yellow]No rules loaded[/yellow]")
            return
        console.print("[bold]Active rules (load order):[/bold]")
        for idx, rule in enumerate(rules, start=1):
            applies = f" applies_to={rule.applies_to}" if rule.applies_to else ""
            console.print(f"  {idx}. {rule.source}{applies}")

        errors = getattr(session, "_rule_errors", [])
        if errors:
            console.print("\n[bold red]Rule load errors:[/bold red]")
            for error in errors:
                console.print(f"  - {error}")
