"""Code commands: /cat, /tree, /grep, /edit, /add, /remove."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from rich.console import Console

from beep.chat.commands.base import Command
from beep.workspace.detector import find_workspace_root
from beep.workspace.file_ops import read_file
from beep.workspace.file_tree import display_tree

console = Console()


class CatCommand(Command):
    @property
    def name(self) -> str:
        return "cat"

    @property
    def description(self) -> str:
        return "View file with syntax highlighting"

    @property
    def category(self) -> str:
        return "Code"

    async def execute(self, args: str, _ctx: dict[str, Any]) -> None:
        if not args:
            console.print("[yellow]Usage: /cat <path>[/yellow]")
            return
        p = Path(args)
        if not p.exists():
            console.print(f"[red]Not found: {args}[/red]")
            return
        console.print(read_file(p, show_numbers=True, highlight=True))


class TreeCommand(Command):
    @property
    def name(self) -> str:
        return "tree"

    @property
    def description(self) -> str:
        return "Show file tree"

    @property
    def category(self) -> str:
        return "Code"

    async def execute(self, args: str, _ctx: dict[str, Any]) -> None:
        root = Path(args) if args else find_workspace_root()
        display_tree(root)


class GrepCommand(Command):
    @property
    def name(self) -> str:
        return "grep"

    @property
    def description(self) -> str:
        return "Search files with regex"

    @property
    def category(self) -> str:
        return "Code"

    async def execute(self, args: str, _ctx: dict[str, Any]) -> None:
        if not args:
            console.print("[yellow]Usage: /grep <pattern>[/yellow]")
            return
        import re

        from beep.workspace.ignore import IgnoreMatcher

        root = find_workspace_root()
        matcher = IgnoreMatcher(root)
        found = 0
        try:
            regex = re.compile(args)
        except re.error as e:
            console.print(f"[red]Invalid regex: {e}[/red]")
            return

        for fp in root.rglob("*"):
            if not fp.is_file() or matcher.is_ignored(fp):
                continue
            try:
                content = fp.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            for i, line in enumerate(content.splitlines(), 1):
                if regex.search(line):
                    rel = fp.relative_to(root)
                    console.print(f"[cyan]{rel}[/cyan]:[green]{i}[/green]: {line}")
                    found += 1
        if not found:
            console.print("[yellow]No matches[/yellow]")


class EditCommand(Command):
    @property
    def name(self) -> str:
        return "edit"

    @property
    def description(self) -> str:
        return "Edit file (next lines = content)"

    @property
    def category(self) -> str:
        return "Code"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        if not args:
            console.print("[yellow]Usage: /edit <path>[/yellow]")
            return
        ctx["session"]._edit_target = Path(args)


class AddCommand(Command):
    @property
    def name(self) -> str:
        return "add"

    @property
    def description(self) -> str:
        return "Pin file to context"

    @property
    def category(self) -> str:
        return "Code"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        if not args:
            console.print("[yellow]Usage: /add <path>[/yellow]")
            return
        result = ctx["chat_context"].pin_file(Path(args))
        console.print(result)


class RemoveCommand(Command):
    @property
    def name(self) -> str:
        return "remove"

    @property
    def description(self) -> str:
        return "Unpin file from context"

    @property
    def category(self) -> str:
        return "Code"

    async def execute(self, args: str, ctx: dict[str, Any]) -> None:
        if not args:
            console.print("[yellow]Usage: /remove <path>[/yellow]")
            return
        result = ctx["chat_context"].unpin_file(Path(args))
        console.print(result)
