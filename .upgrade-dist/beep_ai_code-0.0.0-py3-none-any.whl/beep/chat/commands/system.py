"""System commands: /status, /config, /diagnostics, /templates."""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.table import Table

from beep.chat.commands.base import Command
from beep.config import CONFIG_FILE, load_config
from beep.workspace.detector import find_workspace_root
from beep.workspace.git import is_git_repo

console = Console()


class StatusCommand(Command):
    @property
    def name(self) -> str:
        return "status"

    @property
    def description(self) -> str:
        return "Server health"

    @property
    def category(self) -> str:
        return "System"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        client = ctx["client"]
        health = await client.health_check()
        table = Table(title="Server Status")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        if isinstance(health, dict):
            for k, v in health.items():
                if k == "coding_model_tiers":
                    continue
                if isinstance(v, (str, int, float, bool)):
                    table.add_row(str(k), str(v))
        console.print(table)
        tiers = health.get("coding_model_tiers") if isinstance(health, dict) else None
        if isinstance(tiers, dict) and tiers:
            tier_table = Table(title="Model Tiers")
            tier_table.add_column("Tier", style="cyan")
            tier_table.add_column("Model", style="green")
            for tier, model in tiers.items():
                tier_table.add_row(str(tier), str(model))
            console.print(tier_table)


class ConfigCommand(Command):
    @property
    def name(self) -> str:
        return "config"

    @property
    def description(self) -> str:
        return "Show configuration"

    @property
    def category(self) -> str:
        return "System"

    async def execute(self, _args: str, _ctx: dict[str, Any]) -> None:
        config = load_config()
        table = Table(title="Configuration")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Server", config.server_url)
        token = "***" + config.api_token[-4:] if config.api_token else "Not set"
        table.add_row("Token", token)
        table.add_row("Model", config.default_model or "(default)")
        table.add_row("File", str(CONFIG_FILE))
        console.print(table)


class DiagnosticsCommand(Command):
    @property
    def name(self) -> str:
        return "diagnostics"

    @property
    def description(self) -> str:
        return "System info"

    @property
    def category(self) -> str:
        return "System"

    async def execute(self, _args: str, ctx: dict[str, Any]) -> None:
        from beep import __version__
        session = ctx["session"]
        root = find_workspace_root()

        console.print(f"[bold]Beep.AI.Code v{__version__}[/bold]")
        console.print(f"Workspace: {root}")
        console.print(f"Git: {'Yes' if is_git_repo(root) else 'No'}")
        console.print(f"Session: {session._session_id}")
        console.print(f"Messages: {len(session._messages)}")
        console.print(f"Requests: {session._request_count}")
        console.print(f"Est. tokens: {session._token_count:,}")


class TemplatesCommand(Command):
    @property
    def name(self) -> str:
        return "templates"

    @property
    def description(self) -> str:
        return "List code templates"

    @property
    def category(self) -> str:
        return "System"

    async def execute(self, _args: str, _ctx: dict[str, Any]) -> None:
        from beep.templates.generator import display_templates, list_templates
        display_templates(list_templates())
