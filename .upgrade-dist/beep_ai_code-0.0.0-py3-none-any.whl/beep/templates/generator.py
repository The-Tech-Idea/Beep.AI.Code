"""Code generation templates.

Provides:
- File scaffolding (create files from templates)
- Component templates (React, FastAPI, etc.)
- Module templates
- Custom template support
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console
from rich.prompt import Prompt

console = Console()


@dataclass
class Template:
    """A code generation template."""

    name: str
    description: str
    category: str
    content: str
    variables: list[str] = field(default_factory=list)
    file_extension: str = ""
    source: str = "builtin"


BUILTIN_TEMPLATES: list[Template] = [
    Template(
        name="fastapi-route",
        description="FastAPI route with error handling",
        category="python",
        file_extension=".py",
        variables=["route_name", "path"],
        content='''from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()


class {route_name}Request(BaseModel):
    pass


class {route_name}Response(BaseModel):
    pass


@router.get("/{path}", response_model={route_name}Response)
async def {route_name}():
    """{route_name} endpoint."""
    return {route_name}Response()
''',
    ),
    Template(
        name="react-component",
        description="React functional component with TypeScript",
        category="typescript",
        file_extension=".tsx",
        variables=["component_name"],
        content='''import React from "react";

interface {component_name}Props {{
  // Add props here
}}

export const {component_name}: React.FC<{component_name}Props> = (props) => {{
  return (
    <div>
      <h1>{component_name}</h1>
    </div>
  );
}};

export default {component_name};
''',
    ),
    Template(
        name="python-class",
        description="Python class with type hints and docstrings",
        category="python",
        file_extension=".py",
        variables=["class_name"],
        content='''"""{class_name} module."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class {class_name}:
    """{class_name} description."""

    def __init__(self) -> None:
        """Initialize {class_name}."""
        pass

    def __str__(self) -> str:
        """Return string representation."""
        return f"{class_name}()"
''',
    ),
    Template(
        name="pytest-test",
        description="Pytest test file with fixtures",
        category="python",
        file_extension=".py",
        variables=["module_name"],
        content='''"""Tests for {module_name}."""

import pytest


@pytest.fixture
def setup_{module_name}():
    """Setup test fixtures."""
    yield


def test_{module_name}_creation(setup_{module_name}):
    """Test {module_name} creation."""
    assert True


def test_{module_name}_behavior(setup_{module_name}):
    """Test {module_name} behavior."""
    assert True
''',
    ),
    Template(
        name="go-handler",
        description="Go HTTP handler with error handling",
        category="go",
        file_extension=".go",
        variables=["handler_name"],
        content='''package main

import (
	"encoding/json"
	"net/http"
)

type {handler_name}Request struct {{
}}

type {handler_name}Response struct {{
}}

func {handler_name}Handler(w http.ResponseWriter, r *http.Request) {{
	if r.Method != http.MethodGet {{
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode({handler_name}Response{{}})
}}
''',
    ),
]


def list_templates(
    category: str | None = None,
    *,
    workspace_root: Path | None = None,
) -> list[Template]:
    """List available templates."""
    templates = _collect_templates(workspace_root)
    if category:
        return [t for t in templates if t.category == category]
    return templates


def _parse_frontmatter(content: str) -> tuple[dict[str, str], str]:
    if not content.startswith("---\n"):
        return {}, content.strip()
    end = content.find("\n---\n", 4)
    if end == -1:
        return {}, content.strip()
    header = content[4:end]
    body = content[end + 5 :].strip()
    meta: dict[str, str] = {}
    for raw in header.splitlines():
        line = raw.strip()
        if not line or ":" not in line:
            continue
        key, value = line.split(":", 1)
        meta[key.strip()] = value.strip().strip("\"'")
    return meta, body


def _discover_template_roots(workspace_root: Path | None = None) -> list[Path]:
    roots = [Path.home() / ".beepai" / "templates"]
    if workspace_root:
        roots.append(workspace_root / ".beep" / "templates")
    env_dir = os.environ.get("BEEP_TEMPLATES_DIR")
    if env_dir:
        roots.append(Path(env_dir))
    return roots


def _load_external_templates(workspace_root: Path | None = None) -> list[Template]:
    templates: list[Template] = []
    roots = _discover_template_roots(workspace_root)
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*.md"):
            try:
                raw = path.read_text(encoding="utf-8")
                meta, body = _parse_frontmatter(raw)
                name = meta.get("name", path.stem)
                category = meta.get("category", "custom")
                description = meta.get("description", f"Custom template from {path.name}")
                ext = meta.get("extension", "")
                vars_raw = meta.get("variables", "")
                variables = []
                if vars_raw:
                    variables = [v.strip() for v in vars_raw.split(",") if v.strip()]
                templates.append(
                    Template(
                        name=name,
                        description=description,
                        category=category,
                        content=body,
                        variables=variables,
                        file_extension=ext,
                        source=str(path),
                    )
                )
            except Exception:
                continue
    return templates


def _collect_templates(workspace_root: Path | None = None) -> list[Template]:
    # Later sources override earlier ones by name.
    merged: dict[str, Template] = {template.name: template for template in BUILTIN_TEMPLATES}
    for template in _load_external_templates(workspace_root):
        merged[template.name] = template
    return sorted(merged.values(), key=lambda template: template.name)


def get_template_by_name(name: str, workspace_root: Path | None = None) -> Template | None:
    """Return template by name from built-in or external sources."""
    for template in _collect_templates(workspace_root):
        if template.name == name:
            return template
    return None


def generate_from_template(
    template: Template,
    output_path: Path,
    variables: dict[str, str] | None = None,
) -> Path:
    """Generate a file from a template.

    Args:
        template: Template to use
        output_path: Where to write the file
        variables: Variable values (prompts if missing)

    Returns:
        Path to generated file
    """
    resolved_vars = {}

    for var in template.variables:
        if variables and var in variables:
            resolved_vars[var] = variables[var]
        else:
            resolved_vars[var] = Prompt.ask(f"  {var}")

    content = template.content.format(**resolved_vars)

    if template.file_extension and not output_path.suffix:
        output_path = output_path.with_suffix(template.file_extension)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")

    return output_path


def display_templates(templates: list[Template]) -> None:
    """Display available templates."""
    from rich.table import Table

    table = Table(title="Available Templates")
    table.add_column("Name", style="cyan")
    table.add_column("Category", style="green")
    table.add_column("Description")
    table.add_column("Variables")
    table.add_column("Source")

    for t in templates:
        vars_str = ", ".join(f"{{{v}}}" for v in t.variables) if t.variables else "none"
        source = t.source if t.source == "builtin" else Path(t.source).name
        table.add_row(t.name, t.category, t.description, vars_str, source)

    console.print(table)
