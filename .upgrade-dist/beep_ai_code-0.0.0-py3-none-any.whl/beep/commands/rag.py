"""RAG commands for semantic search and collection management."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from beep.api.client import BeepAPIClient
from beep.rag.client import RAGClient
from beep.rag.collections import list_collections
from beep.rag.search import display_search_results, semantic_search

console = Console()


def rag_query_cmd(
    query: str = typer.Argument(..., help="Search query"),
    collection: str | None = typer.Option(None, "--collection", "-c", help="Collection ID"),
    max_results: int = typer.Option(5, "--max-results", "-n", help="Maximum results"),
) -> None:
    """Search codebase using semantic search."""
    from beep.setup_wizard import ensure_configured

    config = ensure_configured()

    async def _run() -> None:
        client = BeepAPIClient(config)
        try:
            rag = RAGClient(client)
            results = await semantic_search(rag, query, collection, max_results)
            display_search_results(results)
        finally:
            await client.close()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[yellow]RAG query cancelled[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")


def rag_collections_cmd() -> None:
    """List RAG collections."""
    from beep.setup_wizard import ensure_configured

    config = ensure_configured()

    async def _run() -> None:
        client = BeepAPIClient(config)
        try:
            rag = RAGClient(client)
            await list_collections(rag)
        finally:
            await client.close()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[yellow]RAG collections cancelled[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
