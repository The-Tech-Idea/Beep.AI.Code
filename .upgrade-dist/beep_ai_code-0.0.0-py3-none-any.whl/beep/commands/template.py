"""Template commands."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from beep.templates.generator import (
    display_templates,
    generate_from_template,
    get_template_by_name,
    list_templates,
)
from beep.workspace.detector import find_workspace_root

console = Console()


def template_cmd(
    name: str = typer.Argument(..., help="Template name"),
    output: str = typer.Argument(..., help="Output file path"),
    var: list[str] | None = typer.Option(
        None, "--var", "-v", help="Variable as key=value",
    ),
) -> None:
    """Generate a file from a template."""
    workspace_root = find_workspace_root()
    template = get_template_by_name(name, workspace_root=workspace_root)

    if not template:
        available = [t.name for t in list_templates(workspace_root=workspace_root)]
        console.print(f"[red]Unknown template: {name}[/red]")
        console.print(f"Available: {', '.join(available)}")
        raise typer.Exit(1)

    variables = {}
    if var:
        for v in var:
            if "=" in v:
                key, value = v.split("=", 1)
                variables[key] = value

    try:
        output_path = Path(output)
        result = generate_from_template(template, output_path, variables)
        console.print(f"[green]Generated {result}[/green]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1)


def template_list_cmd(
    category: str | None = typer.Option(None, "--category", "-c", help="Filter by category"),
) -> None:
    """List available templates."""
    workspace_root = find_workspace_root()
    try:
        templates = list_templates(category, workspace_root=workspace_root)
        display_templates(templates)
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1)
