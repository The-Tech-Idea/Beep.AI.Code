"""Edit command with diff preview."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from beep.workspace.file_ops import apply_edit

console = Console()


def edit_cmd(
    path: str = typer.Argument(..., help="File to edit"),
    content: str = typer.Option(None, "--content", "-c", help="New content (or use stdin)"),
    no_confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Edit a file with diff preview.

    Usage:
        beep edit file.py -c "new content"
        echo "new content" | beep edit file.py
    """
    import sys

    file_path = Path(path)

    if not file_path.exists():
        if typer.confirm(f"File {path} does not exist. Create it?"):
            file_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            raise typer.Exit(1)

    if content is None:
        if not sys.stdin.isatty():
            content = sys.stdin.read()
        else:
            console.print("[red]Provide content via --content or pipe[/red]")
            raise typer.Exit(1)

    old_content = ""
    if file_path.exists():
        try:
            old_content = file_path.read_text(encoding="utf-8")
        except Exception as exc:
            console.print(f"[red]Error: {exc}[/red]")
            raise typer.Exit(1)

    try:
        apply_edit(file_path, old_content, content, require_confirm=not no_confirm)
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1)
