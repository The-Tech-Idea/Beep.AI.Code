"""Agent command for autonomous code tasks."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable

import typer
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table

from beep.agent.environment import AgentEnvironmentManager
from beep.agent.environment_catalog import AGENT_PACKAGES
from beep.agent.loop import resume_agent, run_agent
from beep.agent.provider_plugins import (
    describe_agent_provider_guidance,
    is_agent_backend_configured,
    list_available_agent_provider_guidance,
)
from beep.agent.provider_capabilities import build_provider_descriptor
from beep.api.client import BeepAPIClient
from beep.coding.metadata import build_coding_metadata
from beep.config import BeepConfig, load_config
from beep.plugins.runtime import load_runtime_plugins
from beep.runtime.workspace import get_workspace_runtime
from beep.runtime.workspace_intelligence import (
    WorkspaceIntelligenceStatusReport,
    build_semantic_search_status_report,
    build_workspace_intelligence_capabilities,
)
from beep.setup_wizard import ensure_agent_configured
from beep.workspace.detector import find_workspace_root

console = Console()


def _format_size(size_bytes: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    value = float(size_bytes)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} {unit}"
        value /= 1024
    return f"{size_bytes} B"


def _render_agent_env_status(status: dict[str, object]) -> None:
    table = Table(title="Agent Runtime Environment")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Status", str(status.get("status", "unknown")))
    table.add_row("Compatibility", str(status.get("compatibility_status", "unknown")))
    table.add_row("Repair Command", str(status.get("repair_command") or "None"))
    table.add_row("Environment", str(status.get("env_path", "")))
    table.add_row("Python", str(status.get("python_exe", "")))
    table.add_row("Size", _format_size(int(status.get("size_bytes", 0) or 0)))
    missing = status.get("missing", []) or []
    table.add_row("Missing Required", ", ".join(str(item) for item in missing) if missing else "None")
    compatibility_reason = status.get("compatibility_reason")
    table.add_row("Compatibility Note", str(compatibility_reason or "None"))
    repair_reason = status.get("repair_reason")
    table.add_row("Repair Note", str(repair_reason or "None"))
    last_error = status.get("last_error")
    table.add_row("Last Error", str(last_error or "None"))
    console.print(table)

    package_table = Table(title="Managed Packages")
    package_table.add_column("Package", style="cyan")
    package_table.add_column("Required")
    package_table.add_column("Installed")
    package_table.add_column("Pip Name", overflow="fold")
    packages = status.get("packages", {})
    if isinstance(packages, dict):
        for key in sorted(packages):
            package = packages[key]
            if not isinstance(package, dict):
                continue
            package_table.add_row(
                str(package.get("name", key)),
                "Yes" if package.get("required") else "No",
                "Yes" if package.get("installed") else "No",
                str(package.get("pip_name", "")),
            )
    console.print(package_table)
def _coerce_workspace_intelligence_status_report(
    report: object,
) -> WorkspaceIntelligenceStatusReport | None:
    if isinstance(report, WorkspaceIntelligenceStatusReport):
        return report
    if isinstance(report, dict):
        return build_semantic_search_status_report(report)
    return None


def _render_workspace_intelligence_reports(reports: list[object] | None) -> None:
    if not reports:
        return

    for raw_report in reports:
        report = _coerce_workspace_intelligence_status_report(raw_report)
        if report is None:
            continue
        table = Table(title=report.title)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        for row in report.rows:
            table.add_row(str(row.label), str(row.value))
        console.print(table)


def _render_provider_status(config: BeepConfig, *, plugin_registry: object | None = None) -> None:
    descriptor = build_provider_descriptor(config, plugin_registry=plugin_registry)
    guidance = describe_agent_provider_guidance(config, plugin_registry=plugin_registry)
    table = Table(title="Agent Provider")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Backend", descriptor.display_name)
    table.add_row("Provider Key", descriptor.key)
    table.add_row("Source", guidance.source)
    table.add_row(
        "Configured",
        "Yes" if is_agent_backend_configured(config, plugin_registry=plugin_registry) else "No",
    )
    table.add_row("Base URL", config.effective_agent_base_url or "None")
    table.add_row("Model", str(config.effective_agent_model or "None"))
    console.print(table)


def _render_provider_guidance(config: BeepConfig, *, plugin_registry: object | None = None) -> None:
    guidance = describe_agent_provider_guidance(config, plugin_registry=plugin_registry)
    table = Table(title="Provider Guidance")
    table.add_column("Property", style="cyan")
    table.add_column("Value", overflow="fold")
    table.add_row("Selected Provider", guidance.display_name)
    table.add_row("Source", guidance.source)
    table.add_row(
        "Requires API Key",
        "Yes" if guidance.requires_api_key else "No" if guidance.requires_api_key is not None else "Unknown",
    )
    table.add_row(
        "Requires Model",
        "Yes" if guidance.requires_model else "No" if guidance.requires_model is not None else "Unknown",
    )
    table.add_row("Default Base URL", guidance.default_base_url or "None")
    table.add_row(
        "Local Runtime",
        "Yes" if guidance.local_runtime else "No",
    )
    if guidance.notes:
        table.add_row("Notes", "\n".join(f"- {note}" for note in guidance.notes))
    console.print(table)


def agent_providers_cmd() -> None:
    """List available autonomous-agent providers and their configuration guidance."""
    config = load_config()
    provider_plugin_runtime = load_runtime_plugins(find_workspace_root())
    providers = list_available_agent_provider_guidance(
        config,
        plugin_registry=provider_plugin_runtime.registry,
    )

    table = Table(title="Agent Providers")
    table.add_column("Key", style="cyan")
    table.add_column("Provider", style="green")
    table.add_column("Source")
    table.add_column("Configured")
    table.add_column("Local")
    table.add_column("Requires")
    table.add_column("Default Base URL", overflow="fold")
    table.add_column("Selected")

    for provider in providers:
        requirements: list[str] = []
        if provider.requires_api_key:
            requirements.append("api_key")
        if provider.requires_model:
            requirements.append("model")
        requirement_text = ", ".join(requirements) if requirements else "None"
        table.add_row(
            provider.key,
            provider.display_name,
            provider.source,
            "Yes" if provider.configured else "No",
            "Yes" if provider.local_runtime else "No",
            requirement_text,
            provider.default_base_url or "None",
            "Yes" if provider.selected else "No",
        )
    console.print(table)
    console.print("Provider keys: " + ", ".join(provider.key for provider in providers))
    console.print(
        "Provider names: "
        + ", ".join(f"{provider.key} = {provider.display_name}" for provider in providers)
    )
    console.print(
        "Default base URLs: "
        + ", ".join(
            f"{provider.key} = {provider.default_base_url or 'None'}"
            for provider in providers
        )
    )


def _render_provider_capabilities(config: BeepConfig, *, plugin_registry: object | None = None) -> None:
    capabilities = build_provider_descriptor(config, plugin_registry=plugin_registry).capabilities
    table = Table(title="Provider Capabilities")
    table.add_column("Capability", style="cyan")
    table.add_column("Exists")
    table.add_column("Notes", overflow="fold")
    for label, flag in [
        ("Chat Completion", capabilities.chat_completion),
        ("Tool Calling", capabilities.tool_calling),
        ("Streaming", capabilities.streaming),
        ("Structured Output", capabilities.structured_output),
        ("Vision", capabilities.vision),
        ("Embeddings", capabilities.embeddings),
        ("Local Runtime", capabilities.local_model_runtime),
    ]:
        table.add_row(label, "Yes" if flag.exists else "No", str(flag.notes or "None"))
    console.print(table)


def _render_workspace_intelligence_capabilities(capabilities: object | None) -> None:
    if capabilities is None:
        return

    semantic = getattr(capabilities, "semantic_search", None)
    lsp = getattr(capabilities, "lsp", None)
    table = Table(title="Workspace Intelligence Capabilities")
    table.add_column("Capability", style="cyan")
    table.add_column("Exists")
    table.add_column("Notes", overflow="fold")

    rows = []
    if semantic is not None:
        rows.extend(
            [
                ("Semantic Search", semantic.semantic_search),
                ("Find Related", semantic.find_related),
                ("Local Indexing", semantic.local_indexing),
                ("Remote Git Indexing", semantic.remote_git_indexing),
                ("Hybrid Mode", semantic.hybrid_mode),
                ("Semantic Mode", semantic.semantic_mode),
                ("BM25 Mode", semantic.bm25_mode),
                ("Language Filters", semantic.language_filters),
                ("Path Filters", semantic.path_filters),
                ("Index Stats", semantic.index_stats),
            ]
        )
    if lsp is not None:
        rows.extend(
            [
                ("LSP Diagnostics", lsp.diagnostics),
                ("LSP Hover", lsp.hover),
                ("LSP Definition", lsp.definition),
                ("LSP References", lsp.references),
                ("LSP Rename", lsp.rename),
                ("LSP Workspace Symbols", lsp.workspace_symbols),
                ("LSP Code Actions", lsp.code_actions),
                ("LSP Formatting", lsp.formatting),
            ]
        )

    for label, flag in rows:
        table.add_row(
            label,
            "Yes" if getattr(flag, "exists", False) else "No",
            str(getattr(flag, "notes", "") or "None"),
        )
    console.print(table)


def _get_workspace_intelligence_status(
    manager: AgentEnvironmentManager,
    status: dict[str, object],
) -> tuple[list[object], object]:
    report: dict[str, object] = {
        "available": False,
        "workspace_root": None,
        "cached": False,
        "cached_root": None,
        "stats": None,
        "error": None,
    }
    if status.get("status") != "ready":
        report["error"] = 'Agent environment not ready. Run "beep agent setup" to enable managed workspace intelligence support.'
        return [build_semantic_search_status_report(report)], build_workspace_intelligence_capabilities(report)

    try:
        manager.inject_into_sys_path()
        workspace_root = find_workspace_root()
        runtime = get_workspace_runtime(workspace_root)
        plugin_runtime = getattr(runtime, "plugin_runtime", None)
        registry = getattr(plugin_runtime, "registry", None)
        get_reports = getattr(registry, "get_workspace_intelligence_reports", None)
        if callable(get_reports):
            reports = get_reports(workspace_root)
            if isinstance(reports, list):
                normalized_reports = [
                    report
                    for report in (_coerce_workspace_intelligence_status_report(item) for item in reports)
                    if report is not None
                ]
                if normalized_reports:
                    return normalized_reports, runtime.workspace_intelligence_capabilities
        adapter = runtime.semantic_search_adapter
        if adapter is None or not hasattr(adapter, "availability_report"):
            report["error"] = "No semantic-search adapter is registered for the current workspace runtime."
            return [build_semantic_search_status_report(report)], runtime.workspace_intelligence_capabilities
        return [build_semantic_search_status_report(adapter.availability_report())], runtime.workspace_intelligence_capabilities
    except Exception as exc:
        report["error"] = str(exc)
        return [build_semantic_search_status_report(report)], build_workspace_intelligence_capabilities(report)


def _run_with_progress(
    operation: Callable[[Callable[[str, int, str], None]], dict[str, object]],
) -> dict[str, object]:
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.percentage:>3.0f}%"),
        console=console,
    ) as progress:
        task = progress.add_task("Preparing agent environment", total=100)

        def callback(_stage: str, percent: int, message: str) -> None:
            progress.update(task, description=message, completed=max(0, min(percent, 100)))

        return operation(callback)


def agent_setup_cmd() -> None:
    """Create or update the managed LangGraph runtime environment."""
    manager = AgentEnvironmentManager()
    try:
        status = _run_with_progress(lambda callback: manager.install_required_packages(callback))
    except Exception as exc:
        console.print(f"[red]Agent environment setup failed: {exc}[/red]")
        raise typer.Exit(1)
    console.print("[green]Agent environment ready.[/green]")
    _render_agent_env_status(status)


def agent_status_cmd() -> None:
    """Show managed LangGraph runtime environment status."""
    config = load_config()
    provider_plugin_runtime = load_runtime_plugins(find_workspace_root())
    manager = AgentEnvironmentManager()
    status = manager.status()
    _render_agent_env_status(status)
    _render_provider_status(config, plugin_registry=provider_plugin_runtime.registry)
    _render_provider_guidance(config, plugin_registry=provider_plugin_runtime.registry)
    _render_provider_capabilities(config, plugin_registry=provider_plugin_runtime.registry)
    workspace_intelligence_reports, capabilities = _get_workspace_intelligence_status(manager, status)
    _render_workspace_intelligence_reports(workspace_intelligence_reports)
    _render_workspace_intelligence_capabilities(capabilities)


def agent_reinstall_cmd(package: str = typer.Argument(..., help=f"Package key or runtime ({', '.join(sorted(AGENT_PACKAGES))}, runtime)")) -> None:
    """Reinstall one managed runtime package or rebuild the whole runtime."""
    manager = AgentEnvironmentManager()
    normalized = package.strip().lower()
    runtime_aliases = {"runtime", "environment", "env", "all"}
    try:
        if normalized in runtime_aliases:
            status = _run_with_progress(lambda callback: manager.reinstall_environment(callback))
        else:
            status = _run_with_progress(
                lambda callback: manager.reinstall_package(package, progress_callback=callback)
            )
    except Exception as exc:
        console.print(f"[red]Package reinstall failed: {exc}[/red]")
        raise typer.Exit(1)
    if normalized in runtime_aliases:
        console.print("[green]Reinstalled managed agent runtime.[/green]")
    else:
        console.print(f"[green]Reinstalled {package}.[/green]")
    _render_agent_env_status(status)


def agent_uninstall_cmd(
    yes: bool = typer.Option(False, "--yes", "-y", help="Remove the managed environment without prompting"),
) -> None:
    """Remove the managed LangGraph runtime environment."""
    if not yes and not typer.confirm("Remove the managed agent environment?"):
        console.print("[yellow]Uninstall cancelled.[/yellow]")
        raise typer.Exit(0)
    manager = AgentEnvironmentManager()
    try:
        manager.uninstall_environment()
    except Exception as exc:
        console.print(f"[red]Agent environment uninstall failed: {exc}[/red]")
        raise typer.Exit(1)
    console.print("[green]Agent environment removed.[/green]")


def agent_cmd(
    goal: str = typer.Argument(..., help="Goal for the agent"),
    max_steps: int = typer.Option(20, "--max-steps", "-n", help="Maximum steps"),
    step_timeout: float = typer.Option(120.0, "--timeout", "-t", help="Seconds to wait for each API call before aborting"),
    auto_approve: bool = typer.Option(False, "--yes", "-y", help="Auto-approve all actions"),
    model: str | None = typer.Option(None, "--model", "-m", help="Model to use"),
    no_plugins: bool = typer.Option(False, "--no-plugins", help="Disable plugin loading"),
) -> None:
    """Run autonomous agent to achieve a goal.

    The agent can read files, edit code, search the codebase, and run commands.
    Use --yes to auto-approve destructive operations.
    """
    _run_agent_operation(
        model=model,
        operation=lambda client, config: run_agent(
            client,
            goal,
            config=config,
            max_steps=max_steps,
            step_timeout=step_timeout,
            auto_approve=auto_approve,
            plugins_enabled=not no_plugins,
            coding_assistant=build_coding_metadata(
                workspace_root=find_workspace_root(),
                interaction_mode="agent",
                project_id=config.project_id,
            ),
            mcp_enabled=config.mcp_enabled,
            mcp_servers=config.mcp_servers,
        ),
    )


def agent_resume_cmd(
    session_id: str = typer.Argument(..., help="Checkpoint thread ID to resume"),
    max_steps: int = typer.Option(20, "--max-steps", "-n", help="Maximum steps"),
    step_timeout: float = typer.Option(120.0, "--timeout", "-t", help="Seconds to wait for each API call before aborting"),
    auto_approve: bool = typer.Option(False, "--yes", "-y", help="Auto-approve all actions"),
    model: str | None = typer.Option(None, "--model", "-m", help="Model to use"),
    no_plugins: bool = typer.Option(False, "--no-plugins", help="Disable plugin loading"),
) -> None:
    """Resume an autonomous agent thread from the latest SQLite checkpoint."""
    _run_agent_operation(
        model=model,
        operation=lambda client, config: resume_agent(
            client,
            session_id,
            config=config,
            max_steps=max_steps,
            step_timeout=step_timeout,
            auto_approve=auto_approve,
            plugins_enabled=not no_plugins,
            coding_assistant=build_coding_metadata(
                workspace_root=find_workspace_root(),
                interaction_mode="agent",
                project_id=config.project_id,
            ),
            mcp_enabled=config.mcp_enabled,
            mcp_servers=config.mcp_servers,
        ),
    )


def _run_agent_operation(
    *,
    model: str | None,
    operation: Callable[[BeepAPIClient | None, object], Awaitable[object]],
) -> None:
    config = ensure_agent_configured()

    if model:
        config.agent_model = model

    async def _run() -> None:
        await operation(None, config)

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Agent stopped[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
