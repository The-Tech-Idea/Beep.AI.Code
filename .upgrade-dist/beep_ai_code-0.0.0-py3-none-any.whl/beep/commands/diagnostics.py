"""Diagnostics commands."""

from __future__ import annotations

import typer
from rich.console import Console

console = Console()


def diagnostics_cmd() -> None:
    """Show diagnostics and system info."""
    try:
        from beep import __version__
        from beep.config import CONFIG_FILE, load_config
        from beep.plugins.runtime import load_runtime_plugins
        from beep.utils.json_logging import is_json_logging_enabled
        from beep.workspace.detector import find_workspace_root
        from beep.workspace.git import is_git_repo

        config = load_config()
        workspace = find_workspace_root()

        console.print("[bold]Beep.AI.Code Diagnostics[/bold]\n")

        console.print(f"Version: {__version__}")
        console.print(f"Python: {__import__('sys').version}")
        console.print(f"Config: {CONFIG_FILE}")
        console.print(f"Configured: {'Yes' if config.is_configured else 'No'}")
        console.print(f"Server: {config.server_url}")
        console.print(f"Workspace: {workspace}")
        console.print(f"Git repo: {'Yes' if is_git_repo(workspace) else 'No'}")
        console.print(f"Default model: {config.default_model or '(server default)'}")
        console.print(f"Max tokens: {config.max_tokens}")
        console.print(f"Temperature: {config.temperature}")
        console.print(f"MCP bridge enabled: {'Yes' if config.mcp_enabled else 'No'}")
        console.print(f"MCP servers configured: {len(config.mcp_servers)}")
        console.print(f"JSON logging: {'Yes' if is_json_logging_enabled() else 'No'}")

        plugin_runtime = load_runtime_plugins(workspace, enabled=True)
        console.print(f"Plugins loaded: {plugin_runtime.loaded_count}")
        console.print("Plugin search paths:")
        for path in plugin_runtime.searched_paths:
            console.print(f"  - {path}")
        load_errors = plugin_runtime.registry.get_load_errors()
        if load_errors:
            console.print("Plugin load errors:")
            for err in load_errors:
                console.print(f"  - {err}")
        else:
            console.print("Plugin load errors: none")

        deps = {
            "typer": "typer",
            "rich": "rich",
            "httpx": "httpx",
            "textual": "textual",
            "pygments": "pygments",
        }

        console.print("\n[bold]Dependencies:[/bold]")
        for name, module in deps.items():
            try:
                mod = __import__(module)
                version = getattr(mod, "__version__", "unknown")
                console.print(f"  {name}: {version}")
            except ImportError:
                console.print(f"  {name}: [red]not installed[/red]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1)
