"""Chat commands for Beep.AI.Code CLI."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console

from beep.api.client import BeepAPIClient
from beep.chat.runner import run_chat

console = Console()


def chat_cmd(
    model: str | None = typer.Option(None, "--model", "-m", help="Model to use"),
    mode: str = typer.Option("assistant", "--mode", help="Chat mode: assistant, review, explain"),
    show_tokens: bool = typer.Option(False, "--tokens", help="Show token usage"),
    resume: str | None = typer.Option(None, "--resume", "-r", help="Resume a session"),
    no_plugins: bool = typer.Option(False, "--no-plugins", help="Disable plugin loading"),
) -> None:
    """Start interactive chat session."""
    from beep.setup_wizard import ensure_configured

    config = ensure_configured()

    async def _run() -> None:
        client = BeepAPIClient(config)
        try:
            await run_chat(
                client,
                model=model,
                mode=mode,
                show_tokens=show_tokens,
                resume_session=resume,
                plugins_enabled=not no_plugins,
                config=config,
            )
        finally:
            await client.close()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[yellow]Chat ended[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
