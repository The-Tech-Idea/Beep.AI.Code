"""Workspace commands: tree, cat, grep."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from beep.workspace.file_ops import read_file
from beep.workspace.file_tree import display_tree

console = Console()


def tree_cmd(
    path: str = typer.Argument(".", help="Directory to show"),
    depth: int = typer.Option(3, "--depth", "-d", help="Maximum depth"),
    all_files: bool = typer.Option(False, "--all", "-a", help="Show ignored files"),
) -> None:
    """Display workspace file tree."""
    root = Path(path).resolve()
    if not root.is_dir():
        console.print(f"[red]Not a directory: {path}[/red]")
        raise typer.Exit(1)

    try:
        display_tree(root, max_depth=depth, show_all=all_files)
    except Exception as exc:
        console.print(f"[red]Failed to display tree: {exc}[/red]")
        raise typer.Exit(1)


def cat_cmd(
    path: str = typer.Argument(..., help="File to display"),
    start: int = typer.Option(None, "--start", "-s", help="Start line"),
    end: int = typer.Option(None, "--end", "-e", help="End line"),
    no_numbers: bool = typer.Option(False, "--no-numbers", help="Hide line numbers"),
    no_highlight: bool = typer.Option(False, "--raw", help="Disable syntax highlighting"),
) -> None:
    """Display file content with syntax highlighting."""
    file_path = Path(path)
    if not file_path.exists():
        console.print(f"[red]File not found: {path}[/red]")
        raise typer.Exit(1)

    if not file_path.is_file():
        console.print(f"[red]Not a file: {path}[/red]")
        raise typer.Exit(1)

    try:
        content = read_file(
            file_path,
            start_line=start,
            end_line=end,
            show_numbers=not no_numbers,
            highlight=not no_highlight,
        )
    except Exception as exc:
        console.print(f"[red]Failed to read file: {exc}[/red]")
        raise typer.Exit(1)
    console.print(content)


def grep_cmd(
    pattern: str = typer.Argument(..., help="Search pattern"),
    path: str = typer.Argument(".", help="Directory to search"),
    case_sensitive: bool = typer.Option(
        False, "-C", "--case-sensitive", help="Case sensitive search",
    ),
    file_pattern: str = typer.Option(None, "--name", "-n", help="File glob pattern"),
) -> None:
    """Search files for a pattern."""
    import re

    root = Path(path).resolve()
    if not root.is_dir():
        console.print(f"[red]Not a directory: {path}[/red]")
        raise typer.Exit(1)

    flags = 0 if case_sensitive else re.IGNORECASE
    try:
        regex = re.compile(pattern, flags)
    except re.error as e:
        console.print(f"[red]Invalid regex: {e}[/red]")
        raise typer.Exit(1)

    from beep.workspace.ignore import IgnoreMatcher

    matcher = IgnoreMatcher(root)
    found = 0

    for file_path in root.rglob("*"):
        if not file_path.is_file() or matcher.is_ignored(file_path):
            continue

        if file_pattern and not file_path.match(file_pattern):
            continue

        try:
            content = file_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        for line_num, line in enumerate(content.splitlines(), 1):
            if regex.search(line):
                rel_path = file_path.relative_to(root)
                console.print(f"[cyan]{rel_path}[/cyan]:[green]{line_num}[/green]: {line}")
                found += 1

    if found == 0:
        console.print("[yellow]No matches found[/yellow]")
