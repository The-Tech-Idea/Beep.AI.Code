"""Built-in provider contract and registry for autonomous-agent backends."""

from __future__ import annotations

import inspect
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

import httpx

from beep.agent.backends import AgentModelBackend, BeepAgentBackend, OpenAICompatibleAgentBackend
from beep.agent.provider_capabilities import ProviderCapabilities, ProviderDescriptor
from beep.api.client import BeepAPIClient
from beep.config import BeepConfig
from beep.plugins.registry import PluginRegistry
from beep.runtime.capabilities import CapabilityFlag


@dataclass(frozen=True)
class ProviderGuidance:
    """Configuration and discovery details for one agent provider."""

    key: str
    display_name: str
    source: str
    configured: bool
    local_runtime: bool
    requires_api_key: bool | None
    requires_model: bool | None
    default_base_url: str | None
    selected: bool
    notes: tuple[str, ...]


@dataclass(frozen=True)
class ProviderProbeResult:
    """Connectivity probe result for one agent provider configuration."""

    supported: bool
    success: bool
    message: str


class AgentBackendProvider(ABC):
    """Contract for one autonomous-agent backend provider."""

    key: str
    display_name: str

    def source_label(self) -> str:
        """Return the provider source label used in UX surfaces."""
        return "built-in"

    def requires_api_key(self) -> bool | None:
        """Return whether the provider requires an API key."""
        return None

    def requires_model(self) -> bool | None:
        """Return whether the provider requires an explicit model selection."""
        return None

    def default_base_url(self) -> str | None:
        """Return the provider's default base URL when one exists."""
        return None

    def configuration_notes(self, config: BeepConfig) -> tuple[str, ...]:
        """Return provider-specific configuration guidance notes."""
        return ()

    async def probe_configuration(self, config: BeepConfig) -> ProviderProbeResult:
        """Return a best-effort connectivity probe for this provider."""
        del config
        return ProviderProbeResult(
            supported=False,
            success=False,
            message="This provider does not expose a validation probe.",
        )

    @abstractmethod
    def is_configured(self, config: BeepConfig) -> bool:
        """Return True when the provider has enough configuration to run."""

    @abstractmethod
    def describe(self, config: BeepConfig) -> ProviderDescriptor:
        """Return the provider descriptor for the active configuration."""

    @abstractmethod
    def build_backend(
        self,
        config: BeepConfig,
        *,
        client: Any = None,
        coding_assistant: dict[str, Any] | None = None,
    ) -> AgentModelBackend:
        """Build the runtime backend for this provider."""


class BeepBackendProvider(AgentBackendProvider):
    """Built-in provider for the canonical Beep.AI.Server surface."""

    key = "beep"
    display_name = "Beep.AI.Server"

    def requires_api_key(self) -> bool | None:
        return True

    def requires_model(self) -> bool | None:
        return False

    def configuration_notes(self, config: BeepConfig) -> tuple[str, ...]:
        del config
        return (
            "Uses server_url by default and falls back to api_token when agent_api_key is unset.",
            "Use this when the autonomous agent should target the canonical Beep.AI.Server surface.",
        )

    async def probe_configuration(self, config: BeepConfig) -> ProviderProbeResult:
        client = BeepAPIClient(config)
        try:
            models = await client.list_models()
            return _build_model_probe_result(models, selected_model=config.effective_agent_model)
        except Exception as exc:
            return ProviderProbeResult(
                supported=True,
                success=False,
                message=str(exc),
            )
        finally:
            await client.close()

    def is_configured(self, config: BeepConfig) -> bool:
        return bool(config.effective_agent_base_url) and config.effective_agent_api_key is not None

    def describe(self, config: BeepConfig) -> ProviderDescriptor:
        return ProviderDescriptor(
            key=self.key,
            display_name=self.display_name,
            capabilities=ProviderCapabilities(
                chat_completion=CapabilityFlag(
                    True,
                    "Uses the canonical Beep.AI.Server OpenAI-compatible chat surface.",
                ),
                tool_calling=CapabilityFlag(
                    True,
                    "Agent tools are passed through the Beep chat completion surface.",
                ),
                streaming=CapabilityFlag(
                    False,
                    "The autonomous agent backend currently uses one-shot completions, not streaming.",
                ),
                structured_output=CapabilityFlag(
                    False,
                    "Structured response_format is not exposed by the current agent backend adapter.",
                ),
                vision=CapabilityFlag(
                    False,
                    "Vision inputs are not exposed by the current agent backend adapter.",
                ),
                embeddings=CapabilityFlag(
                    False,
                    "Embeddings are outside the autonomous agent backend contract.",
                ),
                local_model_runtime=CapabilityFlag(
                    False,
                    "Beep.AI.Server is a remote server/backend surface, not an in-process local runtime.",
                ),
            ),
        )

    def build_backend(
        self,
        config: BeepConfig,
        *,
        client: Any = None,
        coding_assistant: dict[str, Any] | None = None,
    ) -> AgentModelBackend:
        effective_client = client if client is not None else BeepAPIClient(config)
        return BeepAgentBackend(
            effective_client,
            model=config.effective_agent_model,
            coding_assistant=coding_assistant,
            owns_client=client is None,
        )


class OpenAICompatibleBackendProvider(AgentBackendProvider):
    """Built-in provider for generic OpenAI-compatible transports."""

    key = "openai-compatible"
    display_name = "OpenAI-Compatible"

    def _resolve_base_url(self, config: BeepConfig) -> str:
        return config.effective_agent_base_url

    def _resolve_api_key(self, config: BeepConfig) -> str | None:
        return config.effective_agent_api_key

    def _requires_api_key(self) -> bool:
        return True

    def _requires_model(self) -> bool:
        return False

    def requires_api_key(self) -> bool | None:
        return self._requires_api_key()

    def requires_model(self) -> bool | None:
        return self._requires_model()

    def default_base_url(self) -> str | None:
        return None

    def configuration_notes(self, config: BeepConfig) -> tuple[str, ...]:
        del config
        return (
            "Requires an OpenAI-compatible base URL and API key.",
            "Use this for generic remote providers that expose /v1/chat/completions.",
        )

    async def probe_configuration(self, config: BeepConfig) -> ProviderProbeResult:
        headers: dict[str, str] = {}
        api_key = self._resolve_api_key(config)
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        try:
            async with httpx.AsyncClient(
                base_url=self._resolve_base_url(config),
                headers=headers,
                timeout=httpx.Timeout(config.request_timeout, connect=10.0),
            ) as client:
                response = await client.get("/v1/models")
                response.raise_for_status()
                data = response.json()
        except httpx.HTTPStatusError as exc:
            try:
                detail = exc.response.text
            except Exception:
                detail = str(exc)
            return ProviderProbeResult(
                supported=True,
                success=False,
                message=detail or str(exc),
            )
        except Exception as exc:
            return ProviderProbeResult(
                supported=True,
                success=False,
                message=str(exc),
            )

        models = data.get("data", []) if isinstance(data, dict) else []
        return _build_model_probe_result(models, selected_model=config.effective_agent_model)

    def _build_capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            chat_completion=CapabilityFlag(
                True,
                "Uses a standard /v1/chat/completions endpoint.",
            ),
            tool_calling=CapabilityFlag(
                True,
                "Agent tools are sent through the standard tools payload.",
            ),
            streaming=CapabilityFlag(
                False,
                "The current adapter performs non-streaming requests only.",
            ),
            structured_output=CapabilityFlag(
                False,
                "response_format is not exposed by the current adapter.",
            ),
            vision=CapabilityFlag(
                False,
                "Vision or multimodal message shaping is not exposed by the current adapter.",
            ),
            embeddings=CapabilityFlag(
                False,
                "Embeddings are outside the autonomous agent backend contract.",
            ),
            local_model_runtime=CapabilityFlag(
                False,
                "Generic OpenAI-compatible transport does not imply an in-process local runtime.",
            ),
        )

    def is_configured(self, config: BeepConfig) -> bool:
        has_base_url = bool(self._resolve_base_url(config))
        has_api_key = self._resolve_api_key(config) is not None
        has_model = config.effective_agent_model is not None
        if self._requires_api_key() and not has_api_key:
            return False
        if self._requires_model() and not has_model:
            return False
        return has_base_url

    def describe(self, config: BeepConfig) -> ProviderDescriptor:
        return ProviderDescriptor(
            key=self.key,
            display_name=self.display_name,
            capabilities=self._build_capabilities(),
        )

    def build_backend(
        self,
        config: BeepConfig,
        *,
        client: Any = None,
        coding_assistant: dict[str, Any] | None = None,
    ) -> AgentModelBackend:
        del client
        del coding_assistant
        return OpenAICompatibleAgentBackend(
            base_url=self._resolve_base_url(config),
            api_key=self._resolve_api_key(config),
            model=config.effective_agent_model,
            request_timeout=config.request_timeout,
        )


class LMStudioBackendProvider(OpenAICompatibleBackendProvider):
    """Built-in provider for LM Studio's local OpenAI-compatible runtime."""

    key = "lm-studio"
    display_name = "LM Studio"
    _default_base_url = "http://localhost:1234"

    def default_base_url(self) -> str | None:
        return self._default_base_url

    def _resolve_base_url(self, config: BeepConfig) -> str:
        if config.agent_base_url and config.agent_base_url.strip():
            return config.agent_base_url.rstrip("/")
        return self._default_base_url

    def _resolve_api_key(self, config: BeepConfig) -> str | None:
        token = config.agent_api_key
        if token is None:
            return None
        return token.strip() or None

    def _requires_api_key(self) -> bool:
        return False

    def _requires_model(self) -> bool:
        return True

    def configuration_notes(self, config: BeepConfig) -> tuple[str, ...]:
        del config
        return (
            "Uses LM Studio's local OpenAI-compatible server by default.",
            "Set agent_model to a loaded local model such as qwen-coder or deepseek-coder.",
            "agent_api_key is optional for the default local LM Studio runtime.",
        )

    def _build_capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            chat_completion=CapabilityFlag(
                True,
                "Wraps LM Studio's local OpenAI-compatible chat endpoint.",
            ),
            tool_calling=CapabilityFlag(
                True,
                "Tool payloads are forwarded through the OpenAI-compatible transport; actual support depends on the loaded model.",
            ),
            streaming=CapabilityFlag(
                False,
                "The current agent adapter performs non-streaming requests only.",
            ),
            structured_output=CapabilityFlag(
                False,
                "response_format is not exposed by the current adapter.",
            ),
            vision=CapabilityFlag(
                False,
                "Vision inputs are not exposed by the current adapter.",
            ),
            embeddings=CapabilityFlag(
                False,
                "Embeddings are outside the autonomous agent backend contract.",
            ),
            local_model_runtime=CapabilityFlag(
                True,
                "Targets LM Studio's local desktop model runtime by default.",
            ),
        )


class OllamaBackendProvider(OpenAICompatibleBackendProvider):
    """Built-in provider for Ollama's local OpenAI-compatible runtime."""

    key = "ollama"
    display_name = "Ollama"
    _default_base_url = "http://localhost:11434"

    def default_base_url(self) -> str | None:
        return self._default_base_url

    def _resolve_base_url(self, config: BeepConfig) -> str:
        if config.agent_base_url and config.agent_base_url.strip():
            return config.agent_base_url.rstrip("/")
        return self._default_base_url

    def _resolve_api_key(self, config: BeepConfig) -> str | None:
        token = config.agent_api_key
        if token is None:
            return None
        return token.strip() or None

    def _requires_api_key(self) -> bool:
        return False

    def _requires_model(self) -> bool:
        return True

    def configuration_notes(self, config: BeepConfig) -> tuple[str, ...]:
        del config
        return (
            "Uses Ollama's local OpenAI-compatible server by default.",
            "Set agent_model to an installed Ollama model such as qwen2.5-coder or codellama.",
            "agent_api_key is optional for the default local Ollama runtime.",
        )

    def _build_capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            chat_completion=CapabilityFlag(
                True,
                "Wraps Ollama's local OpenAI-compatible chat endpoint.",
            ),
            tool_calling=CapabilityFlag(
                True,
                "Tool payloads are forwarded through the OpenAI-compatible transport; actual support depends on the selected Ollama model.",
            ),
            streaming=CapabilityFlag(
                False,
                "The current agent adapter performs non-streaming requests only.",
            ),
            structured_output=CapabilityFlag(
                False,
                "response_format is not exposed by the current adapter.",
            ),
            vision=CapabilityFlag(
                False,
                "Vision inputs are not exposed by the current adapter.",
            ),
            embeddings=CapabilityFlag(
                False,
                "Embeddings are outside the autonomous agent backend contract.",
            ),
            local_model_runtime=CapabilityFlag(
                True,
                "Targets Ollama's local model runtime by default.",
            ),
        )


_BUILTIN_AGENT_BACKEND_PROVIDERS: dict[str, AgentBackendProvider] = {
    provider.key: provider
    for provider in (
        BeepBackendProvider(),
        OpenAICompatibleBackendProvider(),
        LMStudioBackendProvider(),
        OllamaBackendProvider(),
    )
}


def _extract_model_ids(models: list[dict[str, Any]] | Any) -> list[str]:
    resolved: list[str] = []
    if not isinstance(models, list):
        return resolved
    for model in models:
        if not isinstance(model, dict):
            continue
        model_id = model.get("id")
        if model_id is None:
            continue
        normalized = str(model_id).strip()
        if normalized and normalized not in resolved:
            resolved.append(normalized)
    return resolved


def _build_model_probe_result(
    models: list[dict[str, Any]] | Any,
    *,
    selected_model: str | None,
) -> ProviderProbeResult:
    model_ids = _extract_model_ids(models)
    if selected_model and model_ids:
        if selected_model in model_ids:
            return ProviderProbeResult(
                supported=True,
                success=True,
                message=f"Connected to /v1/models. Found {len(model_ids)} models including '{selected_model}'.",
            )
        preview = ", ".join(model_ids[:5])
        suffix = f" Available models: {preview}" if preview else ""
        return ProviderProbeResult(
            supported=True,
            success=False,
            message=f"Connected to /v1/models, but model '{selected_model}' was not returned.{suffix}",
        )
    if model_ids:
        return ProviderProbeResult(
            supported=True,
            success=True,
            message=f"Connected to /v1/models. Found {len(model_ids)} models.",
        )
    if selected_model:
        return ProviderProbeResult(
            supported=True,
            success=True,
            message=f"Connected to /v1/models, but the provider returned no models so '{selected_model}' could not be verified.",
        )
    return ProviderProbeResult(
        supported=True,
        success=True,
        message="Connected to /v1/models, but the provider returned no models.",
    )


def list_agent_backend_providers() -> list[AgentBackendProvider]:
    """Return the built-in autonomous-agent backend providers."""
    return list(_BUILTIN_AGENT_BACKEND_PROVIDERS.values())


def _get_runtime_provider(
    key: str,
    *,
    plugin_registry: PluginRegistry | Any | None = None,
) -> Any | None:
    if plugin_registry is None:
        return None
    getter = getattr(plugin_registry, "get_backend_provider", None)
    if getter is None or not callable(getter):
        return None
    return getter(key)


def _provider_source_label(provider: Any) -> str:
    source_label = getattr(provider, "source_label", None)
    if callable(source_label):
        return str(source_label())
    return "plugin"


def _provider_requires_api_key(provider: Any) -> bool | None:
    requires_api_key = getattr(provider, "requires_api_key", None)
    if callable(requires_api_key):
        return requires_api_key()
    return None


def _provider_requires_model(provider: Any) -> bool | None:
    requires_model = getattr(provider, "requires_model", None)
    if callable(requires_model):
        return requires_model()
    return None


def _provider_default_base_url(provider: Any) -> str | None:
    default_base_url = getattr(provider, "default_base_url", None)
    if callable(default_base_url):
        return default_base_url()
    return None


def _provider_configuration_notes(provider: Any, config: BeepConfig) -> tuple[str, ...]:
    notes = getattr(provider, "configuration_notes", None)
    if callable(notes):
        result = notes(config)
        if isinstance(result, tuple):
            return tuple(str(item) for item in result if str(item).strip())
        if isinstance(result, list):
            return tuple(str(item) for item in result if str(item).strip())
    return ("See the provider plugin documentation for configuration details.",)


def get_agent_backend_provider(
    key: str,
    *,
    plugin_registry: PluginRegistry | Any | None = None,
) -> Any:
    """Return one provider by key."""
    runtime_provider = _get_runtime_provider(key, plugin_registry=plugin_registry)
    if runtime_provider is not None:
        return runtime_provider
    try:
        return _BUILTIN_AGENT_BACKEND_PROVIDERS[key]
    except KeyError as exc:
        raise ValueError(f"Unsupported agent backend: {key}") from exc


def describe_agent_provider_guidance(
    config: BeepConfig,
    *,
    provider_key: str | None = None,
    plugin_registry: PluginRegistry | Any | None = None,
) -> ProviderGuidance:
    """Return CLI-friendly guidance for one provider."""
    key = provider_key or config.agent_backend
    provider = get_agent_backend_provider(key, plugin_registry=plugin_registry)
    descriptor = provider.describe(config)
    return ProviderGuidance(
        key=descriptor.key,
        display_name=descriptor.display_name,
        source=_provider_source_label(provider),
        configured=bool(provider.is_configured(config)),
        local_runtime=bool(descriptor.capabilities.local_model_runtime.exists),
        requires_api_key=_provider_requires_api_key(provider),
        requires_model=_provider_requires_model(provider),
        default_base_url=_provider_default_base_url(provider),
        selected=descriptor.key == config.agent_backend,
        notes=_provider_configuration_notes(provider, config),
    )


async def probe_agent_backend_configuration(
    config: BeepConfig,
    *,
    plugin_registry: PluginRegistry | Any | None = None,
) -> ProviderProbeResult:
    """Run the selected provider's best-effort connectivity probe."""
    provider = get_agent_backend_provider(config.agent_backend, plugin_registry=plugin_registry)
    probe = getattr(provider, "probe_configuration", None)
    if probe is None or not callable(probe):
        return ProviderProbeResult(
            supported=False,
            success=False,
            message="This provider does not expose a validation probe.",
        )
    result = probe(config)
    if inspect.isawaitable(result):
        result = await result
    if result is None:
        return ProviderProbeResult(
            supported=False,
            success=False,
            message="This provider does not expose a validation probe.",
        )
    if isinstance(result, ProviderProbeResult):
        return result
    return ProviderProbeResult(
        supported=False,
        success=False,
        message="This provider returned an invalid validation result.",
    )


def list_available_agent_provider_guidance(
    config: BeepConfig,
    *,
    plugin_registry: PluginRegistry | Any | None = None,
) -> list[ProviderGuidance]:
    """Return discovery/configuration guidance for built-in and runtime providers."""
    keys = {provider.key for provider in _BUILTIN_AGENT_BACKEND_PROVIDERS.values()}
    if plugin_registry is not None:
        list_backend_providers = getattr(plugin_registry, "list_backend_providers", None)
        if callable(list_backend_providers):
            keys.update(str(item) for item in list_backend_providers())
    return [
        describe_agent_provider_guidance(
            config,
            provider_key=key,
            plugin_registry=plugin_registry,
        )
        for key in sorted(keys)
    ]


def is_agent_backend_configured(
    config: BeepConfig,
    *,
    plugin_registry: PluginRegistry | Any | None = None,
) -> bool:
    """Return True when the selected provider has enough configuration to run."""
    provider = get_agent_backend_provider(
        config.agent_backend,
        plugin_registry=plugin_registry,
    )
    return bool(provider.is_configured(config))