"""Semble-backed semantic code search tools for the autonomous agent."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from beep.agent.tools.base import BaseTool, ToolResult

_DEFAULT_TOP_K = 5
_MAX_TOP_K = 20
_VALID_MODES = frozenset({"hybrid", "semantic", "bm25"})


def _load_semble_index() -> type:
    try:
        from semble import SembleIndex
    except ImportError as exc:
        raise RuntimeError(
            'Semble is not installed in the agent environment. Run "beep agent setup" to install semantic search support.'
        ) from exc
    return SembleIndex


def _format_results(header: str, results: list[Any]) -> str:
    sections = [header]
    for index, result in enumerate(results, start=1):
        chunk = getattr(result, "chunk", None)
        if chunk is None:
            continue
        score = getattr(result, "score", None)
        source = getattr(result, "source", None)
        source_value = getattr(source, "value", source)
        meta: list[str] = []
        if isinstance(score, int | float):
            meta.append(f"score={score:.3f}")
        if source_value:
            meta.append(f"source={source_value}")
        location = f"{chunk.file_path}:{chunk.start_line}-{chunk.end_line}"
        if meta:
            location = f"{location} ({', '.join(meta)})"
        sections.append(f"{index}. {location}")
        sections.append("```")
        sections.append(str(getattr(chunk, "content", "")).rstrip())
        sections.append("```")
    return "\n".join(sections)


def _coerce_top_k(value: Any) -> int:
    try:
        top_k = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid top_k value: {value!r}") from exc
    return min(max(top_k, 1), _MAX_TOP_K)


def _coerce_mode(value: Any) -> str:
    mode = str(value or "hybrid").strip().lower()
    if mode not in _VALID_MODES:
        raise ValueError(f"Invalid search mode: {mode!r}. Expected one of: {', '.join(sorted(_VALID_MODES))}.")
    return mode


def _coerce_string_list(value: Any) -> list[str] | None:
    if value is None:
        return None
    if isinstance(value, str):
        values = [value]
    elif isinstance(value, list | tuple | set):
        values = list(value)
    else:
        raise ValueError(f"Expected a string list, got {type(value).__name__}.")

    normalized = [str(item).strip() for item in values if str(item).strip()]
    return normalized or None


class SembleIndexAdapter:
    """Lazy Semble index loader with per-run caching."""

    def __init__(
        self,
        *,
        workspace_root: Path | None = None,
        index_loader: Callable[[Path], Any] | None = None,
    ) -> None:
        self._workspace_root = workspace_root.resolve() if workspace_root else None
        self._index_loader = index_loader or self._build_index
        self._cached_root: Path | None = None
        self._cached_index: Any = None

    def _is_outside_workspace(self, path: Path) -> bool:
        return bool(
            self._workspace_root
            and self._workspace_root not in path.parents
            and path != self._workspace_root
        )

    def _resolve_root(self, raw_path: str | None) -> Path:
        root_str = raw_path or (str(self._workspace_root) if self._workspace_root else ".")
        root = Path(root_str).resolve()
        if self._is_outside_workspace(root):
            raise ValueError(f"Path outside workspace: {raw_path}")
        if not root.exists():
            raise FileNotFoundError(f"Path does not exist: {root_str}")
        if not root.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {root_str}")
        return root

    def _build_index(self, root: Path) -> Any:
        return _load_semble_index().from_path(root)

    def _get_index(self, root: Path) -> Any:
        if self._cached_root == root and self._cached_index is not None:
            return self._cached_index
        self._cached_root = root
        self._cached_index = self._index_loader(root)
        return self._cached_index

    def availability_report(self) -> dict[str, Any]:
        """Return runtime availability and cache details for Semble search."""
        report: dict[str, Any] = {
            "available": False,
            "workspace_root": str(self._workspace_root) if self._workspace_root else None,
            "cached": self._cached_root is not None and self._cached_index is not None,
            "cached_root": str(self._cached_root) if self._cached_root else None,
            "stats": None,
            "error": None,
        }
        try:
            _load_semble_index()
        except RuntimeError as exc:
            report["error"] = str(exc)
            return report

        report["available"] = True
        if self._cached_index is None:
            return report

        try:
            stats = getattr(self._cached_index, "stats", None)
            if stats is None:
                return report
            languages = getattr(stats, "languages", {}) or {}
            report["stats"] = {
                "indexed_files": int(getattr(stats, "indexed_files", 0) or 0),
                "total_chunks": int(getattr(stats, "total_chunks", 0) or 0),
                "languages": dict(languages),
            }
        except Exception as exc:
            report["error"] = str(exc)
        return report

    def _normalize_index_path(self, raw_path: str, *, root: Path) -> str:
        path = Path(raw_path)
        if path.is_absolute():
            resolved = path.resolve()
            if self._is_outside_workspace(resolved) or root not in resolved.parents and resolved != root:
                raise ValueError(f"Path outside workspace: {raw_path}")
            return resolved.relative_to(root).as_posix()
        return str(path).replace("\\", "/")

    def _resolve_chunk(self, chunks: list[Any], *, file_path: str, line: int) -> Any | None:
        fallback = None
        for chunk in chunks:
            if chunk.file_path != file_path:
                continue
            if chunk.start_line <= line <= chunk.end_line:
                if line < chunk.end_line:
                    return chunk
                if fallback is None:
                    fallback = chunk
        return fallback

    def search(
        self,
        *,
        query: str,
        path: str | None,
        top_k: int,
        mode: str,
        filter_languages: list[str] | None,
        filter_paths: list[str] | None,
    ) -> list[Any]:
        root = self._resolve_root(path)
        index = self._get_index(root)
        normalized_paths = None
        if filter_paths:
            normalized_paths = [self._normalize_index_path(item, root=root) for item in filter_paths]
        return index.search(
            query,
            top_k=top_k,
            mode=mode,
            filter_languages=filter_languages,
            filter_paths=normalized_paths,
        )

    def find_related(
        self,
        *,
        file_path: str,
        line: int,
        path: str | None,
        top_k: int,
    ) -> list[Any]:
        root = self._resolve_root(path)
        index = self._get_index(root)
        normalized_file_path = self._normalize_index_path(file_path, root=root)
        chunk = self._resolve_chunk(index.chunks, file_path=normalized_file_path, line=line)
        if chunk is None:
            raise ValueError(
                f"No chunk found at {normalized_file_path}:{line}. Make sure the file is indexed and the line number is within a known chunk."
            )
        return index.find_related(chunk, top_k=top_k)


class SemanticSearchTool(BaseTool):
    """Search the workspace with Semble's semantic and hybrid retrieval."""

    def __init__(self, adapter: SembleIndexAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "semantic_search"

    @property
    def description(self) -> str:
        return (
            "Search the workspace with Semble using hybrid, semantic, or BM25 retrieval. "
            "Use this before broad file reads for exploratory code discovery."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "query": {
                "type": "string",
                "description": "Natural-language or code query to search for.",
            },
            "path": {
                "type": "string",
                "description": "Directory to index (defaults to workspace root).",
            },
            "top_k": {
                "type": "integer",
                "description": "Maximum number of results to return (1-20, default 5).",
            },
            "mode": {
                "type": "string",
                "description": "Search mode: hybrid (default), semantic, or bm25.",
            },
            "filter_languages": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional language filters such as ['python', 'typescript'].",
            },
            "filter_paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional workspace-relative file paths to restrict retrieval to.",
            },
        }

    @property
    def optional_params(self) -> list[str]:
        return ["path", "top_k", "mode", "filter_languages", "filter_paths"]

    @property
    def category(self) -> str:
        return "search"

    @property
    def read_only_safe(self) -> bool:
        return True

    async def execute(self, **kwargs: Any) -> ToolResult:
        query = str(kwargs.get("query", "")).strip()
        if not query:
            return ToolResult(success=False, output="", error="Query cannot be empty.")
        try:
            top_k = _coerce_top_k(kwargs.get("top_k", _DEFAULT_TOP_K))
            mode = _coerce_mode(kwargs.get("mode", "hybrid"))
            filter_languages = _coerce_string_list(kwargs.get("filter_languages"))
            filter_paths = _coerce_string_list(kwargs.get("filter_paths"))
            results = self._adapter.search(
                query=query,
                path=kwargs.get("path"),
                top_k=top_k,
                mode=mode,
                filter_languages=filter_languages,
                filter_paths=filter_paths,
            )
        except (FileNotFoundError, NotADirectoryError, RuntimeError, ValueError) as exc:
            return ToolResult(success=False, output="", error=str(exc))

        if not results:
            return ToolResult(success=True, output="No results found.")

        return ToolResult(
            success=True,
            output=_format_results(f"Search results for: {query!r} (mode={mode})", results),
        )


class FindRelatedCodeTool(BaseTool):
    """Find Semble-related code chunks from a known file and line."""

    def __init__(self, adapter: SembleIndexAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "find_related_code"

    @property
    def description(self) -> str:
        return (
            "Find code chunks semantically similar to a known file and line using Semble. "
            "Use this after semantic_search to explore related implementations."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "file_path": {
                "type": "string",
                "description": "Workspace-relative or absolute path to a file returned by semantic_search.",
            },
            "line": {
                "type": "integer",
                "description": "1-based line number inside the target file.",
            },
            "path": {
                "type": "string",
                "description": "Directory to index (defaults to workspace root).",
            },
            "top_k": {
                "type": "integer",
                "description": "Maximum number of related chunks to return (1-20, default 5).",
            },
        }

    @property
    def optional_params(self) -> list[str]:
        return ["path", "top_k"]

    @property
    def category(self) -> str:
        return "search"

    @property
    def read_only_safe(self) -> bool:
        return True

    async def execute(self, **kwargs: Any) -> ToolResult:
        file_path = str(kwargs.get("file_path", "")).strip()
        if not file_path:
            return ToolResult(success=False, output="", error="file_path cannot be empty.")
        try:
            line = int(kwargs.get("line", 0))
        except (TypeError, ValueError) as exc:
            return ToolResult(success=False, output="", error=f"Invalid line value: {kwargs.get('line')!r}")
        if line < 1:
            return ToolResult(success=False, output="", error="line must be >= 1.")

        try:
            top_k = _coerce_top_k(kwargs.get("top_k", _DEFAULT_TOP_K))
            results = self._adapter.find_related(
                file_path=file_path,
                line=line,
                path=kwargs.get("path"),
                top_k=top_k,
            )
        except (FileNotFoundError, NotADirectoryError, RuntimeError, ValueError) as exc:
            return ToolResult(success=False, output="", error=str(exc))

        if not results:
            return ToolResult(success=True, output=f"No related chunks found for {file_path}:{line}.")

        return ToolResult(
            success=True,
            output=_format_results(f"Chunks related to {file_path}:{line}", results),
        )


def build_semble_tools(
    *,
    workspace_root: Path | None = None,
    adapter: SembleIndexAdapter | None = None,
) -> tuple[BaseTool, BaseTool]:
    """Build Semble-backed tools that share one cached workspace index."""
    shared_adapter = adapter or SembleIndexAdapter(workspace_root=workspace_root)
    return SemanticSearchTool(shared_adapter), FindRelatedCodeTool(shared_adapter)