"""Python code-intelligence tools backed by Jedi."""

from __future__ import annotations

import keyword
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from beep.agent.tools.base import BaseTool, ToolResult

_IGNORED_DIR_NAMES = frozenset(
    {
        ".git",
        ".hg",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".tox",
        ".venv",
        "__pycache__",
        "build",
        "dist",
        "node_modules",
        "venv",
    }
)
_MAX_DOCSTRING_CHARS = 1600


def _load_jedi_api() -> tuple[type[Any], type[Any]]:
    try:
        from jedi import Project, Script
    except ImportError as exc:
        raise RuntimeError(
            'Jedi is not installed in the agent environment. Run "beep agent setup" to install Python code intelligence support.'
        ) from exc
    return Project, Script


def _count_python_files(root: Path) -> int:
    count = 0
    for current_root, dir_names, file_names in os.walk(root):
        dir_names[:] = [
            name
            for name in dir_names
            if name not in _IGNORED_DIR_NAMES and not name.startswith(".")
        ]
        if Path(current_root).name in _IGNORED_DIR_NAMES:
            continue
        count += sum(1 for file_name in file_names if file_name.endswith(".py"))
    return count


def _coerce_line(value: Any) -> int:
    try:
        line = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid line value: {value!r}") from exc
    if line < 1:
        raise ValueError("line must be >= 1")
    return line


def _coerce_column(value: Any) -> int:
    if value is None:
        return 0
    try:
        column = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid column value: {value!r}") from exc
    if column < 1:
        raise ValueError("column must be >= 1")
    return column - 1


def _coerce_new_name(value: Any) -> str:
    candidate = str(value or "").strip()
    if not candidate:
        raise ValueError("new_name is required")
    if not candidate.isidentifier() or keyword.iskeyword(candidate):
        raise ValueError(f"Invalid Python identifier for new_name: {candidate!r}")
    return candidate


def _trim_docstring(value: Any) -> str | None:
    docstring = str(value or "").strip()
    if not docstring:
        return None
    if len(docstring) <= _MAX_DOCSTRING_CHARS:
        return docstring
    return docstring[: _MAX_DOCSTRING_CHARS - 3].rstrip() + "..."


def _relative_path(workspace_root: Path, path_value: object | None) -> str:
    if path_value is None:
        return "<builtin>"
    try:
        path = Path(str(path_value)).resolve()
    except OSError:
        return str(path_value)
    try:
        return path.relative_to(workspace_root).as_posix()
    except ValueError:
        return str(path)


@dataclass(frozen=True)
class PythonSymbolRecord:
    name: str
    kind: str
    location: str
    description: str
    docstring: str | None = None


@dataclass(frozen=True)
class PythonRenameResult:
    new_name: str
    touched_files: tuple[str, ...]
    file_renames: tuple[tuple[str, str], ...] = ()


def _serialize_symbol(name: object, workspace_root: Path) -> PythonSymbolRecord:
    symbol_name = str(
        getattr(name, "name", None)
        or getattr(name, "full_name", None)
        or getattr(name, "description", None)
        or "unknown"
    )
    kind = str(getattr(name, "type", None) or "symbol")
    description = str(getattr(name, "description", None) or symbol_name)
    path_text = _relative_path(workspace_root, getattr(name, "module_path", None))
    line = getattr(name, "line", None)
    column = getattr(name, "column", None)
    if isinstance(line, int) and line >= 1:
        location = f"{path_text}:{line}"
        if isinstance(column, int) and column >= 0:
            location = f"{location}:{column + 1}"
    else:
        location = path_text
    docstring_method = getattr(name, "docstring", None)
    docstring = _trim_docstring(docstring_method() if callable(docstring_method) else None)
    return PythonSymbolRecord(
        name=symbol_name,
        kind=kind,
        location=location,
        description=description,
        docstring=docstring,
    )


def _format_symbol_records(header: str, records: list[PythonSymbolRecord]) -> str:
    sections = [header]
    for index, record in enumerate(records, start=1):
        sections.append(f"{index}. {record.name} [{record.kind}] - {record.location}")
        if record.description and record.description != record.name:
            sections.append(record.description)
        if record.docstring:
            sections.append("```text")
            sections.append(record.docstring.rstrip())
            sections.append("```")
    return "\n".join(sections)


def _format_rename_result(header: str, result: PythonRenameResult) -> str:
    sections = [header, f"New name: {result.new_name}"]
    if result.touched_files:
        sections.append("Affected files:")
        for index, path in enumerate(result.touched_files, start=1):
            sections.append(f"{index}. {path}")
    if result.file_renames:
        sections.append("File renames:")
        for index, (old_path, new_path) in enumerate(result.file_renames, start=1):
            sections.append(f"{index}. {old_path} -> {new_path}")
    return "\n".join(sections)


def _coerce_top_k(value: Any) -> int:
    if value is None:
        return 10
    try:
        top_k = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid top_k value: {value!r}") from exc
    if top_k < 1:
        raise ValueError("top_k must be >= 1")
    return min(top_k, 50)


class PythonJediAdapter:
    """Lazy Python code-intelligence adapter backed by Jedi."""

    def __init__(
        self,
        *,
        workspace_root: Path,
        api_loader: Callable[[], tuple[type[Any], type[Any]]] | None = None,
        python_file_counter: Callable[[Path], int] | None = None,
    ) -> None:
        self._workspace_root = workspace_root.resolve()
        self._api_loader = api_loader or _load_jedi_api
        self._python_file_counter = python_file_counter or _count_python_files
        self._project: object | None = None

    def availability_report(self) -> dict[str, Any]:
        report = {
            "available": False,
            "backend": "jedi",
            "workspace_root": str(self._workspace_root),
            "python_files": 0,
            "error": None,
        }
        python_files = self._python_file_counter(self._workspace_root)
        report["python_files"] = python_files
        if python_files <= 0:
            report["error"] = "No Python files detected in the current workspace."
            return report
        try:
            self._load_api()
        except RuntimeError as exc:
            report["error"] = str(exc)
            return report
        report["available"] = True
        return report

    def _load_api(self) -> tuple[type[Any], type[Any]]:
        return self._api_loader()

    def _get_project(self) -> object:
        if self._project is None:
            project_type, _ = self._load_api()
            self._project = project_type(path=str(self._workspace_root))
        return self._project

    def _resolve_file(self, raw_path: str) -> Path:
        candidate = Path(str(raw_path or "").strip())
        if not candidate:
            raise ValueError("file_path is required")
        resolved = candidate if candidate.is_absolute() else (self._workspace_root / candidate)
        resolved = resolved.resolve()
        if self._workspace_root not in resolved.parents and resolved != self._workspace_root:
            raise ValueError(f"Path outside workspace: {raw_path}")
        if not resolved.exists():
            raise FileNotFoundError(f"Path does not exist: {resolved}")
        if not resolved.is_file():
            raise ValueError(f"Path is not a file: {resolved}")
        if resolved.suffix.lower() != ".py":
            raise ValueError(f"Python code intelligence only supports .py files: {resolved}")
        return resolved

    def _build_script(self, file_path: Path) -> object:
        _, script_type = self._load_api()
        return script_type(path=str(file_path), project=self._get_project())

    def hover(self, *, file_path: str, line: Any, column: Any = None) -> PythonSymbolRecord:
        resolved = self._resolve_file(file_path)
        script = self._build_script(resolved)
        line_number = _coerce_line(line)
        column_number = _coerce_column(column)
        names = list(script.infer(line=line_number, column=column_number))
        if not names:
            names = list(
                script.goto(
                    line=line_number,
                    column=column_number,
                    follow_imports=True,
                    follow_builtin_imports=False,
                )
            )
        if not names:
            raise ValueError(
                f"No Python symbol found at {_relative_path(self._workspace_root, resolved)}:{line_number}:{column_number + 1}."
            )
        return _serialize_symbol(names[0], self._workspace_root)

    def definitions(self, *, file_path: str, line: Any, column: Any = None) -> list[PythonSymbolRecord]:
        resolved = self._resolve_file(file_path)
        script = self._build_script(resolved)
        line_number = _coerce_line(line)
        column_number = _coerce_column(column)
        definitions = list(
            script.goto(
                line=line_number,
                column=column_number,
                follow_imports=True,
                follow_builtin_imports=False,
            )
        )
        if not definitions:
            raise ValueError(
                f"No Python definition found at {_relative_path(self._workspace_root, resolved)}:{line_number}:{column_number + 1}."
            )
        return [_serialize_symbol(item, self._workspace_root) for item in definitions]

    def references(self, *, file_path: str, line: Any, column: Any = None) -> list[PythonSymbolRecord]:
        resolved = self._resolve_file(file_path)
        script = self._build_script(resolved)
        line_number = _coerce_line(line)
        column_number = _coerce_column(column)
        references = list(
            script.get_references(
                line=line_number,
                column=column_number,
                include_builtins=False,
            )
        )
        if not references:
            raise ValueError(
                f"No Python references found at {_relative_path(self._workspace_root, resolved)}:{line_number}:{column_number + 1}."
            )
        unique_records: list[PythonSymbolRecord] = []
        seen: set[tuple[str, str, str]] = set()
        for reference in references:
            record = _serialize_symbol(reference, self._workspace_root)
            key = (record.name, record.kind, record.location)
            if key in seen:
                continue
            seen.add(key)
            unique_records.append(record)
        return unique_records

    def rename(self, *, file_path: str, line: Any, column: Any = None, new_name: Any) -> PythonRenameResult:
        resolved = self._resolve_file(file_path)
        script = self._build_script(resolved)
        line_number = _coerce_line(line)
        column_number = _coerce_column(column)
        target_name = _coerce_new_name(new_name)

        references = list(
            script.get_references(
                line=line_number,
                column=column_number,
                include_builtins=False,
            )
        )
        touched_files = tuple(
            sorted(
                {
                    _relative_path(self._workspace_root, getattr(reference, "module_path", None))
                    for reference in references
                }
            )
        )

        rename = getattr(script, "rename", None)
        if not callable(rename):
            raise RuntimeError("The active Jedi script does not expose rename refactoring.")
        refactoring = rename(line=line_number, column=column_number, new_name=target_name)

        apply = getattr(refactoring, "apply", None)
        if not callable(apply):
            raise RuntimeError("The active Jedi refactoring does not expose apply().")
        apply()

        file_renames: list[tuple[str, str]] = []
        get_renames = getattr(refactoring, "get_renames", None)
        if callable(get_renames):
            for old_path, new_path in get_renames():
                file_renames.append(
                    (
                        _relative_path(self._workspace_root, old_path),
                        _relative_path(self._workspace_root, new_path),
                    )
                )

        if not touched_files:
            touched_files = (_relative_path(self._workspace_root, resolved),)
        return PythonRenameResult(
            new_name=target_name,
            touched_files=touched_files,
            file_renames=tuple(file_renames),
        )

    def workspace_symbols(self, *, query: str, top_k: Any = None) -> list[PythonSymbolRecord]:
        search_query = str(query or "").strip()
        if not search_query:
            raise ValueError("query is required")
        limit = _coerce_top_k(top_k)
        project = self._get_project()
        search = getattr(project, "search", None)
        if not callable(search):
            raise RuntimeError("The active Jedi project does not expose workspace symbol search.")
        names = list(search(search_query, all_scopes=True))
        if not names:
            raise ValueError(f"No Python workspace symbols found for query: {search_query!r}.")
        unique_records: list[PythonSymbolRecord] = []
        seen: set[tuple[str, str, str]] = set()
        for name in names:
            record = _serialize_symbol(name, self._workspace_root)
            key = (record.name, record.kind, record.location)
            if key in seen:
                continue
            seen.add(key)
            unique_records.append(record)
            if len(unique_records) >= limit:
                break
        if not unique_records:
            raise ValueError(f"No Python workspace symbols found for query: {search_query!r}.")
        return unique_records


class PythonHoverTool(BaseTool):
    def __init__(self, adapter: PythonJediAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "python_hover"

    @property
    def description(self) -> str:
        return "Inspect a Python symbol at a file location using Jedi hover-style inference."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "file_path": {"type": "string", "description": "Python file path inside the workspace."},
            "line": {"type": "integer", "description": "1-based line number for the symbol."},
            "column": {"type": "integer", "description": "1-based column number for the symbol (default 1)."},
        }

    @property
    def optional_params(self) -> list[str]:
        return ["column"]

    @property
    def category(self) -> str:
        return "search"

    @property
    def read_only_safe(self) -> bool:
        return True

    async def execute(self, **kwargs: Any) -> ToolResult:
        try:
            record = self._adapter.hover(
                file_path=str(kwargs.get("file_path") or ""),
                line=kwargs.get("line"),
                column=kwargs.get("column"),
            )
        except Exception as exc:
            return ToolResult(success=False, output="", error=str(exc), is_error=True)
        output = _format_symbol_records(
            f"Hover for {kwargs.get('file_path')}:{kwargs.get('line')}:{kwargs.get('column') or 1}",
            [record],
        )
        return ToolResult(success=True, output=output)


class PythonDefinitionTool(BaseTool):
    def __init__(self, adapter: PythonJediAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "python_definition"

    @property
    def description(self) -> str:
        return "Resolve Python symbol definitions at a file location using Jedi."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "file_path": {"type": "string", "description": "Python file path inside the workspace."},
            "line": {"type": "integer", "description": "1-based line number for the symbol."},
            "column": {"type": "integer", "description": "1-based column number for the symbol (default 1)."},
        }

    @property
    def optional_params(self) -> list[str]:
        return ["column"]

    @property
    def category(self) -> str:
        return "search"

    @property
    def read_only_safe(self) -> bool:
        return True

    async def execute(self, **kwargs: Any) -> ToolResult:
        try:
            records = self._adapter.definitions(
                file_path=str(kwargs.get("file_path") or ""),
                line=kwargs.get("line"),
                column=kwargs.get("column"),
            )
        except Exception as exc:
            return ToolResult(success=False, output="", error=str(exc), is_error=True)
        output = _format_symbol_records(
            f"Definitions for {kwargs.get('file_path')}:{kwargs.get('line')}:{kwargs.get('column') or 1}",
            records,
        )
        return ToolResult(success=True, output=output)


class PythonReferencesTool(BaseTool):
    def __init__(self, adapter: PythonJediAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "python_references"

    @property
    def description(self) -> str:
        return "Find Python symbol references at a file location using Jedi."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "file_path": {"type": "string", "description": "Python file path inside the workspace."},
            "line": {"type": "integer", "description": "1-based line number for the symbol."},
            "column": {"type": "integer", "description": "1-based column number for the symbol (default 1)."},
        }

    @property
    def optional_params(self) -> list[str]:
        return ["column"]

    @property
    def category(self) -> str:
        return "search"

    @property
    def read_only_safe(self) -> bool:
        return True

    async def execute(self, **kwargs: Any) -> ToolResult:
        try:
            records = self._adapter.references(
                file_path=str(kwargs.get("file_path") or ""),
                line=kwargs.get("line"),
                column=kwargs.get("column"),
            )
        except Exception as exc:
            return ToolResult(success=False, output="", error=str(exc), is_error=True)
        output = _format_symbol_records(
            f"References for {kwargs.get('file_path')}:{kwargs.get('line')}:{kwargs.get('column') or 1}",
            records,
        )
        return ToolResult(success=True, output=output)


class PythonWorkspaceSymbolsTool(BaseTool):
    def __init__(self, adapter: PythonJediAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "python_workspace_symbols"

    @property
    def description(self) -> str:
        return "Search Python workspace symbols by name using Jedi project search."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "query": {"type": "string", "description": "Symbol name or partial name to search for."},
            "top_k": {"type": "integer", "description": "Maximum number of symbol matches to return (default 10)."},
        }

    @property
    def optional_params(self) -> list[str]:
        return ["top_k"]

    @property
    def category(self) -> str:
        return "search"

    @property
    def read_only_safe(self) -> bool:
        return True

    async def execute(self, **kwargs: Any) -> ToolResult:
        try:
            records = self._adapter.workspace_symbols(
                query=str(kwargs.get("query") or ""),
                top_k=kwargs.get("top_k"),
            )
        except Exception as exc:
            return ToolResult(success=False, output="", error=str(exc), is_error=True)
        output = _format_symbol_records(
            f"Python workspace symbols for query: {kwargs.get('query')!r}",
            records,
        )
        return ToolResult(success=True, output=output)


class PythonRenameTool(BaseTool):
    def __init__(self, adapter: PythonJediAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "python_rename"

    @property
    def description(self) -> str:
        return "Rename a Python symbol across the workspace using Jedi refactoring support."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "file_path": {"type": "string", "description": "Python file path inside the workspace."},
            "line": {"type": "integer", "description": "1-based line number for the target symbol."},
            "column": {"type": "integer", "description": "1-based column number for the target symbol (default 1)."},
            "new_name": {"type": "string", "description": "New Python identifier to apply to the symbol."},
        }

    @property
    def optional_params(self) -> list[str]:
        return ["column"]

    @property
    def category(self) -> str:
        return "file"

    @property
    def read_only_safe(self) -> bool:
        return False

    async def execute(self, **kwargs: Any) -> ToolResult:
        try:
            result = self._adapter.rename(
                file_path=str(kwargs.get("file_path") or ""),
                line=kwargs.get("line"),
                column=kwargs.get("column"),
                new_name=kwargs.get("new_name"),
            )
        except Exception as exc:
            return ToolResult(success=False, output="", error=str(exc), is_error=True)
        output = _format_rename_result(
            f"Renamed Python symbol at {kwargs.get('file_path')}:{kwargs.get('line')}:{kwargs.get('column') or 1}",
            result,
        )
        return ToolResult(success=True, output=output)


def build_python_intelligence_tools(
    *,
    workspace_root: Path,
    adapter: PythonJediAdapter | None = None,
) -> tuple[BaseTool, ...]:
    shared_adapter = adapter or PythonJediAdapter(workspace_root=workspace_root)
    return (
        PythonHoverTool(shared_adapter),
        PythonDefinitionTool(shared_adapter),
        PythonReferencesTool(shared_adapter),
        PythonRenameTool(shared_adapter),
        PythonWorkspaceSymbolsTool(shared_adapter),
    )