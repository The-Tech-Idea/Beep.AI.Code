"""Managed Python environment for the LangGraph-based agent runtime."""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, ClassVar

from beep import __version__
from beep.agent.environment_catalog import AGENT_PACKAGES, AgentPackage
from beep.config import CONFIG_DIR

ProgressCallback = Callable[[str, int, str], None]


class AgentEnvironmentManager:
    """Manage the dedicated on-demand virtual environment for agent orchestration."""

    _COMPATIBILITY_METADATA_VERSION: ClassVar[int] = 1
    _instances: ClassVar[dict[str, "AgentEnvironmentManager"]] = {}

    def __new__(cls, base_dir: Path | None = None) -> "AgentEnvironmentManager":
        resolved = (base_dir or CONFIG_DIR).expanduser().resolve()
        key = str(resolved)
        instance = cls._instances.get(key)
        if instance is None:
            instance = super().__new__(cls)
            cls._instances[key] = instance
            instance._initialized = False
        return instance

    def __init__(self, base_dir: Path | None = None) -> None:
        if getattr(self, "_initialized", False):
            return
        self._initialized = True
        self._base_dir = (base_dir or CONFIG_DIR).expanduser().resolve()
        self._env_path = self._base_dir / "agents_env"
        self._config_file = self._base_dir / "agents_env_config.json"

    def python_exe(self) -> Path:
        """Return the Python executable inside the managed environment."""
        if os.name == "nt":
            return self._env_path / "Scripts" / "python.exe"
        return self._env_path / "bin" / "python"

    def site_packages(self) -> Path:
        """Resolve the site-packages folder inside the managed environment."""
        candidates = [
            self._env_path / "Lib" / "site-packages",
            self._env_path / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate

        python_exe = self.python_exe()
        if not python_exe.exists():
            raise RuntimeError(
                f"Agent environment not created at {self._env_path}. Run `beep agent setup`."
            )

        result = self._run_subprocess(
            [
                str(python_exe),
                "-c",
                "import sysconfig; print(sysconfig.get_paths()['purelib'])",
            ],
            timeout=30,
        )
        site_packages = Path(result.stdout.strip())
        if not site_packages.exists():
            raise RuntimeError(f"Unable to locate site-packages in {self._env_path}.")
        return site_packages

    def inject_into_sys_path(self) -> Path:
        """Make the managed environment importable from the current process."""
        site_packages = self.site_packages()
        site_packages_str = str(site_packages)
        if site_packages_str not in sys.path:
            sys.path.insert(0, site_packages_str)
            importlib.invalidate_caches()
        return site_packages

    def is_ready(self) -> bool:
        """Return True when the environment and all required packages are present."""
        return self.status()["status"] == "ready"

    def status(self) -> dict[str, Any]:
        """Return computed status for the managed environment."""
        config = self._load_config()
        env_exists = self.python_exe().exists()
        packages: dict[str, dict[str, Any]] = {}
        missing: list[str] = []

        if env_exists:
            for key, package in AGENT_PACKAGES.items():
                installed = self._probe_import_available(package.import_name)
                packages[key] = {
                    "name": package.name,
                    "pip_name": package.pip_name,
                    "import_name": package.import_name,
                    "description": package.description,
                    "required": package.required,
                    "installed": installed,
                }
                if package.required and not installed:
                    missing.append(key)
        else:
            for key, package in AGENT_PACKAGES.items():
                packages[key] = {
                    "name": package.name,
                    "pip_name": package.pip_name,
                    "import_name": package.import_name,
                    "description": package.description,
                    "required": package.required,
                    "installed": False,
                }
                if package.required:
                    missing.append(key)

        if not env_exists:
            status = "not_created"
        elif missing:
            status = "error"
        else:
            status = "ready"

        compatibility = self._resolve_compatibility(config, env_exists=env_exists, missing=missing)
        repair = self._resolve_repair_guidance(
            status=status,
            compatibility=compatibility,
            missing=missing,
        )

        return {
            "status": status,
            "env_path": str(self._env_path),
            "python_exe": str(self.python_exe()),
            "config_file": str(self._config_file),
            "missing": missing,
            "packages": packages,
            "size_bytes": self._directory_size(self._env_path) if env_exists else 0,
            "last_error": config.get("last_error"),
            "compatibility_status": compatibility["status"],
            "compatibility_reason": compatibility["reason"],
            "recorded_compatibility": compatibility["recorded"],
            "expected_compatibility": compatibility["expected"],
            "repair_action": repair["action"],
            "repair_command": repair["command"],
            "repair_reason": repair["reason"],
        }

    def create_environment(self, progress_callback: ProgressCallback | None = None) -> Path:
        """Create the managed virtual environment if needed."""
        self._base_dir.mkdir(parents=True, exist_ok=True)
        if self.python_exe().exists():
            if progress_callback:
                progress_callback("creating", 30, "Using existing agent environment")
            return self._env_path

        self._write_config(status="creating", last_error=None)
        if progress_callback:
            progress_callback("creating", 5, "Creating managed agent environment")
        try:
            self._run_subprocess([sys.executable, "-m", "venv", str(self._env_path)], timeout=300)
        except Exception as exc:
            self._write_config(status="error", last_error=str(exc))
            raise

        if progress_callback:
            progress_callback("creating", 30, f"Created environment at {self._env_path}")
        self._write_config(status="creating", last_error=None)
        return self._env_path

    def install_required_packages(
        self,
        progress_callback: ProgressCallback | None = None,
    ) -> dict[str, Any]:
        """Install all required LangGraph runtime packages into the managed environment."""
        current_status = self.status()
        if (
            current_status.get("status") == "ready"
            and current_status.get("compatibility_status") == "current"
        ):
            if progress_callback:
                progress_callback("ready", 100, "Managed agent environment already current")
            self._write_config(
                status="ready",
                last_error=None,
                compatibility=self._build_compatibility_stamp(),
            )
            return current_status

        self.create_environment(progress_callback=progress_callback)
        python_exe = self.python_exe()

        if progress_callback:
            progress_callback("pip", 35, "Upgrading pip")
        self._write_config(status="creating", last_error=None)
        try:
            self._run_subprocess(
                [
                    str(python_exe),
                    "-m",
                    "pip",
                    "install",
                    "--upgrade",
                    "pip",
                ],
                timeout=240,
            )

            required_packages = [package for package in AGENT_PACKAGES.values() if package.required]
            for index, package in enumerate(required_packages, start=1):
                if progress_callback:
                    pct = 35 + int((index - 1) * 60 / max(len(required_packages), 1))
                    progress_callback(
                        "installing",
                        pct,
                        f"Installing {package.pip_name} ({index}/{len(required_packages)})",
                    )
                self._install_package(package, upgrade=True)
        except Exception as exc:
            self._write_config(status="error", last_error=str(exc))
            raise

        status = self.status()
        if status["missing"]:
            error_message = (
                "Managed agent environment is incomplete; missing required packages: "
                + ", ".join(status["missing"])
            )
            self._write_config(status="error", last_error=error_message)
            raise RuntimeError(error_message)

        self._write_config(
            status="ready",
            last_error=None,
            compatibility=self._build_compatibility_stamp(),
        )
        status = self.status()
        if progress_callback:
            progress_callback("ready", 100, "Agent environment is ready")
        return status

    def reinstall_package(
        self,
        package_name: str,
        progress_callback: ProgressCallback | None = None,
    ) -> dict[str, Any]:
        """Reinstall one package in the managed environment."""
        self.create_environment(progress_callback=progress_callback)
        package = self._resolve_package(package_name)
        if progress_callback:
            progress_callback("installing", 40, f"Reinstalling {package.pip_name}")
        self._install_package(package, upgrade=True, force_reinstall=True)
        status = self.status()
        self._write_config(
            status=status["status"],
            last_error=None,
            compatibility=self._build_compatibility_stamp() if status["status"] == "ready" else None,
        )
        if progress_callback:
            progress_callback("ready", 100, f"Reinstalled {package.pip_name}")
        return status

    def reinstall_environment(
        self,
        progress_callback: ProgressCallback | None = None,
    ) -> dict[str, Any]:
        """Rebuild the entire managed runtime environment from scratch."""
        if progress_callback:
            progress_callback("reinstalling", 5, "Removing managed agent environment")
        self.uninstall_environment()
        if progress_callback:
            progress_callback("reinstalling", 15, "Recreating managed agent environment")
        return self.install_required_packages(progress_callback=progress_callback)

    def uninstall_environment(self) -> None:
        """Remove the managed environment and its persisted status."""
        if self._env_path.exists():
            shutil.rmtree(self._env_path)
        if self._config_file.exists():
            self._config_file.unlink()

    def _install_package(
        self,
        package: AgentPackage,
        *,
        upgrade: bool,
        force_reinstall: bool = False,
    ) -> None:
        command = [str(self.python_exe()), "-m", "pip", "install"]
        if upgrade:
            command.append("--upgrade")
        if force_reinstall:
            command.append("--force-reinstall")
        command.append(package.pip_name)
        self._run_subprocess(command, timeout=1200)

    def _resolve_package(self, package_name: str) -> AgentPackage:
        normalized = package_name.strip().lower()
        for package in AGENT_PACKAGES.values():
            if normalized in {
                package.key.lower(),
                package.name.lower(),
                package.import_name.lower(),
                package.pip_name.lower(),
            }:
                return package
        valid = ", ".join(sorted(AGENT_PACKAGES))
        raise ValueError(f"Unknown agent package '{package_name}'. Choose one of: {valid}")

    def _probe_import_available(self, import_name: str) -> bool:
        python_exe = self.python_exe()
        if not python_exe.exists():
            return False
        result = subprocess.run(
            [
                str(python_exe),
                "-c",
                (
                    "import importlib.util, sys; "
                    "sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)"
                ),
                import_name,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return result.returncode == 0

    def _run_subprocess(self, command: list[str], *, timeout: int) -> subprocess.CompletedProcess[str]:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            error = (result.stderr or result.stdout or "unknown error").strip()
            raise RuntimeError(error)
        return result

    def _load_config(self) -> dict[str, Any]:
        if not self._config_file.exists():
            return {}
        try:
            return json.loads(self._config_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _write_config(
        self,
        *,
        status: str,
        last_error: str | None,
        compatibility: dict[str, Any] | None = None,
    ) -> None:
        self._base_dir.mkdir(parents=True, exist_ok=True)
        existing = self._load_config()
        payload = {
            "status": status,
            "env_path": str(self._env_path),
            "python_exe": str(self.python_exe()),
            "last_error": last_error,
        }
        recorded_compatibility = compatibility if compatibility is not None else existing.get("compatibility")
        if isinstance(recorded_compatibility, dict):
            payload["compatibility"] = recorded_compatibility
        self._config_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _build_compatibility_stamp(self) -> dict[str, Any]:
        manifest = [
            {
                "key": package.key,
                "pip_name": package.pip_name,
                "import_name": package.import_name,
                "required": package.required,
            }
            for _, package in sorted(AGENT_PACKAGES.items())
        ]
        digest = hashlib.sha256(
            json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        return {
            "metadata_version": self._COMPATIBILITY_METADATA_VERSION,
            "cli_version": __version__,
            "catalog_hash": digest[:16],
        }

    def _resolve_compatibility(
        self,
        config: dict[str, Any],
        *,
        env_exists: bool,
        missing: list[str],
    ) -> dict[str, Any]:
        expected = self._build_compatibility_stamp()
        recorded = config.get("compatibility") if isinstance(config.get("compatibility"), dict) else None

        if not env_exists:
            return {
                "status": "not_created",
                "reason": "Managed agent environment has not been created yet.",
                "recorded": recorded,
                "expected": expected,
            }
        if missing:
            return {
                "status": "incomplete",
                "reason": "Managed agent environment is missing required packages.",
                "recorded": recorded,
                "expected": expected,
            }
        if recorded is None:
            return {
                "status": "stale",
                "reason": "Managed agent environment has no recorded compatibility stamp.",
                "recorded": None,
                "expected": expected,
            }

        mismatches: list[str] = []
        for key, expected_value in expected.items():
            recorded_value = recorded.get(key)
            if recorded_value != expected_value:
                mismatches.append(f"{key}={recorded_value!r} expected {expected_value!r}")

        if mismatches:
            return {
                "status": "stale",
                "reason": "Compatibility stamp mismatch: " + "; ".join(mismatches),
                "recorded": recorded,
                "expected": expected,
            }

        return {
            "status": "current",
            "reason": "Managed agent environment matches the current CLI compatibility stamp.",
            "recorded": recorded,
            "expected": expected,
        }

    def _resolve_repair_guidance(
        self,
        *,
        status: str,
        compatibility: dict[str, Any],
        missing: list[str],
    ) -> dict[str, Any]:
        compatibility_status = str(compatibility.get("status") or "unknown")
        recorded = compatibility.get("recorded")
        expected = compatibility.get("expected")

        if status == "ready" and compatibility_status == "current":
            return {
                "action": "none",
                "command": None,
                "reason": "Managed agent runtime is current.",
            }

        if status == "not_created":
            return {
                "action": "setup",
                "command": "beep agent setup",
                "reason": "Managed agent environment does not exist yet.",
            }

        if missing:
            return {
                "action": "setup",
                "command": "beep agent setup",
                "reason": "Managed agent environment is missing required packages.",
            }

        if compatibility_status == "stale":
            recorded_version = recorded.get("metadata_version") if isinstance(recorded, dict) else None
            expected_version = expected.get("metadata_version") if isinstance(expected, dict) else None
            if recorded_version is not None and expected_version is not None and recorded_version != expected_version:
                return {
                    "action": "reinstall",
                    "command": "beep agent reinstall runtime",
                    "reason": "Managed runtime compatibility metadata changed; rebuild the managed runtime from scratch.",
                }
            return {
                "action": "setup",
                "command": "beep agent setup",
                "reason": "Managed runtime compatibility drift detected; refresh the managed runtime.",
            }

        return {
            "action": "setup",
            "command": "beep agent setup",
            "reason": "Managed agent runtime needs repair.",
        }

    def _directory_size(self, root: Path) -> int:
        total = 0
        if not root.exists():
            return total
        for path in root.rglob("*"):
            if path.is_file():
                total += path.stat().st_size
        return total