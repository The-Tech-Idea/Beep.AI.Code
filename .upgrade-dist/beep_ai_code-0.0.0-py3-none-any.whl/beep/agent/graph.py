"""LangGraph-backed execution runtime for the autonomous coding agent."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, TypedDict

from rich.console import Console
from rich.panel import Panel

from beep.agent.approval import request_approval, requires_approval
from beep.agent.backends import AgentModelBackend
from beep.agent.message_adapter import (
    agent_messages_to_langchain_messages,
    agent_dict_to_langchain_message,
    langchain_messages_to_agent_dicts,
    langchain_message_to_agent_dict,
    tool_result_to_langchain_message,
)
from beep.agent.tools.base import BaseTool, ToolResult
from beep.agent.tool_adapter import adapt_tools
from beep.chat.stream_renderer import render_response
from beep.rules.loader import LoadedRule
from beep.sessions.history import append_message
from beep.utils.json_logging import log_event

console = Console()

_FILE_TOUCH_TOOLS: frozenset[str] = frozenset({"file_edit", "single_edit", "file_write"})


class AgentGraphState(TypedDict):
    """Serializable state tracked by the LangGraph runtime."""

    messages: list[dict[str, Any]]
    steps_executed: int
    tool_calls_executed: int
    files_touched: list[str]
    run_reason: str | None
    final_message: str | None
    consecutive_failure_steps: int
    tool_call_hashes: dict[str, int]
    per_step_limit_hit: bool
    total_limit_hit: bool
    pending_tool_messages: list[dict[str, Any]]


def _checkpoint_path(workspace_root: Path) -> Path:
    checkpoint_dir = workspace_root / ".beep"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    return checkpoint_dir / "agent_state.sqlite"


def _build_compiled_graph(
    *,
    state_graph_cls: Any,
    start: Any,
    end: Any,
    runner: AgentGraphRunner,
    checkpointer: Any,
) -> Any:
    graph_builder = state_graph_cls(AgentGraphState)
    graph_builder.add_node("agent", runner.agent_node)
    graph_builder.add_node("approval", runner.approval_node)
    graph_builder.add_node("tools", runner.tools_node)
    graph_builder.add_edge(start, "agent")
    graph_builder.add_conditional_edges(
        "agent",
        runner.route_after_agent,
        {"approval": "approval", "__end__": end},
    )
    graph_builder.add_conditional_edges(
        "approval",
        runner.route_after_approval,
        {"tools": "tools", "__end__": end},
    )
    graph_builder.add_conditional_edges(
        "tools",
        runner.route_after_tools,
        {"agent": "agent", "__end__": end},
    )
    return graph_builder.compile(checkpointer=checkpointer)


def _load_langgraph_dependencies() -> tuple[Any, Any, Any, Any, Any]:
    """Import LangGraph lazily so the main CLI env does not require it."""
    try:
        from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
        from langgraph.graph import END, START, StateGraph
        from langgraph.prebuilt import ToolNode
    except ImportError as exc:
        raise RuntimeError(
            'LangGraph runtime packages are not installed. Run "beep agent setup" to provision the managed agent environment.'
        ) from exc
    return START, END, StateGraph, AsyncSqliteSaver, ToolNode


def _format_tool_result(tool_name: str, result: ToolResult, step: int) -> None:
    border = "green" if result.success else "red"
    status = "OK" if result.success else "FAILED"

    content = result.output or ""
    if result.error:
        content += f"\nError: {result.error}"

    console.print(
        Panel(
            content[:500] + ("..." if len(content) > 500 else ""),
            title=f"Step {step}: {tool_name} ({status})",
            border_style=border,
            padding=(1, 2),
        )
    )


class AgentGraphRunner:
    """Owns node behavior for the LangGraph-backed autonomous agent runtime."""

    def __init__(
        self,
        *,
        backend: AgentModelBackend,
        tools: list[BaseTool],
        workspace_root: Path,
        max_steps: int,
        max_tool_calls_per_step: int,
        max_tool_calls_total: int,
        step_timeout: float,
        max_repeated_calls: int,
        max_consecutive_failures: int,
        max_tool_output_chars: int,
        auto_approve: bool,
        system_prompt: str,
        workspace_rules: list[LoadedRule] | None,
        session_id: str,
        tool_node_cls: Any | None,
    ) -> None:
        self._backend = backend
        self._tools = tools
        self._workspace_root = workspace_root
        self._max_steps = max_steps
        self._max_tool_calls_per_step = max(1, max_tool_calls_per_step)
        self._max_tool_calls_total = max(1, max_tool_calls_total)
        self._step_timeout = step_timeout
        self._max_repeated_calls = max(1, max_repeated_calls)
        self._max_consecutive_failures = max(1, max_consecutive_failures)
        self._max_tool_output_chars = max(500, max_tool_output_chars)
        self._auto_approve = auto_approve
        self._system_prompt = system_prompt
        self._workspace_rules = list(workspace_rules) if workspace_rules else []
        self._active_rules_context = ""
        self._session_id = session_id
        self._adapted_tool_map: dict[str, Any] | None = None
        self._langgraph_tool_node: Any | None = None
        self._tool_node_cls = tool_node_cls

    def build_initial_state(self, goal: str) -> AgentGraphState:
        return {
            "messages": [
                {"role": "system", "content": self._system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"Achieve this goal: {goal}\n\n"
                        "You have access to tools. Use them step by step. "
                        "When done, respond with a summary of what was accomplished."
                    ),
                },
            ],
            "steps_executed": 0,
            "tool_calls_executed": 0,
            "files_touched": [],
            "run_reason": None,
            "final_message": None,
            "consecutive_failure_steps": 0,
            "tool_call_hashes": {},
            "per_step_limit_hit": False,
            "total_limit_hit": False,
            "pending_tool_messages": [],
        }

    def emit_summary(self, state: AgentGraphState) -> None:
        summary = (
            f"steps={state['steps_executed']}, "
            f"tool_calls={state['tool_calls_executed']}, "
            f"per_step_limit_hit={state['per_step_limit_hit']}, "
            f"total_limit_hit={state['total_limit_hit']}, "
            f"reason={state['run_reason']}"
        )
        console.print(f"[dim]Run summary: {summary}[/dim]")
        log_event(
            "agent.run.summary",
            steps_executed=state["steps_executed"],
            tool_calls_executed=state["tool_calls_executed"],
            per_step_limit_hit=state["per_step_limit_hit"],
            total_limit_hit=state["total_limit_hit"],
            reason=state["run_reason"],
        )

    def _get_tool_definitions(self) -> list[dict[str, Any]]:
        return [tool.to_openai_tool() for tool in self._tools]

    def _normalize_agent_message(self, message: dict[str, Any]) -> dict[str, Any]:
        return langchain_message_to_agent_dict(agent_dict_to_langchain_message(message))

    def _build_tool_message(self, *, tool_call_id: str, content: str) -> dict[str, Any]:
        return langchain_message_to_agent_dict(
            tool_result_to_langchain_message(tool_call_id=tool_call_id, content=content)
        )

    def _get_adapted_tool_map(self) -> dict[str, Any]:
        if self._adapted_tool_map is None:
            adapted_tools = adapt_tools(
                self._tools,
                max_output_chars=self._max_tool_output_chars,
                require_human_approval=False,
            )
            self._adapted_tool_map = {
                str(getattr(adapted_tool, "name", "")): adapted_tool
                for adapted_tool in adapted_tools
            }
        return self._adapted_tool_map

    def _get_langgraph_tool_node(self) -> Any:
        if self._langgraph_tool_node is None:
            if self._tool_node_cls is None:
                raise RuntimeError("LangGraph ToolNode is not configured for the agent runtime.")
            self._langgraph_tool_node = self._tool_node_cls(
                adapt_tools(
                    self._tools,
                    max_output_chars=self._max_tool_output_chars,
                    require_human_approval=False,
                )
            )
        return self._langgraph_tool_node

    def _update_files_touched(self, state: AgentGraphState, file_path: str) -> None:
        if not file_path or file_path in state["files_touched"]:
            return
        state["files_touched"] = [*state["files_touched"], file_path]
        if not self._workspace_rules:
            return
        from beep.rules.resolver import build_rules_context, resolve_rules_for_paths

        new_context = build_rules_context(
            resolve_rules_for_paths(self._workspace_rules, state["files_touched"])
        )
        if new_context and new_context != self._active_rules_context:
            self._active_rules_context = new_context
            sys_content = state["messages"][0]["content"]
            if new_context not in sys_content:
                state["messages"][0] = {
                    "role": "system",
                    "content": sys_content + "\n\n" + new_context,
                }

    async def _invoke_tool_node(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        tool_node = self._get_langgraph_tool_node()
        langchain_messages = agent_messages_to_langchain_messages(messages)
        result = await tool_node.ainvoke({"messages": langchain_messages})
        tool_messages = result.get("messages") if isinstance(result, dict) else None
        if not isinstance(tool_messages, list):
            raise RuntimeError("LangGraph ToolNode returned an unexpected result shape.")
        return langchain_messages_to_agent_dicts(tool_messages)

    def _tool_result_from_message(self, *, tool_name: str, content: Any) -> ToolResult:
        if content is None:
            return ToolResult(success=True, output="")
        if isinstance(content, str):
            raw_content = content
        elif isinstance(content, (dict, list)):
            raw_content = json.dumps(content)
        else:
            raw_content = str(content)

        try:
            payload = json.loads(raw_content)
        except (TypeError, json.JSONDecodeError):
            return ToolResult(success=True, output=raw_content)

        if (
            isinstance(payload, dict)
            and payload.get("tool_name") == tool_name
            and payload.get("is_error") is True
        ):
            return ToolResult(
                success=False,
                output=str(payload.get("output") or ""),
                error=str(payload.get("error") or f"{tool_name} failed"),
                is_error=True,
            )
        return ToolResult(success=True, output=raw_content)

    async def agent_node(self, state: AgentGraphState) -> AgentGraphState:
        if state["run_reason"]:
            return state
        if state["steps_executed"] >= self._max_steps:
            console.print(f"\n[yellow]Reached max steps ({self._max_steps})[/yellow]")
            log_event("agent.run.max_steps", max_steps=self._max_steps)
            state["run_reason"] = "max_steps"
            return state

        step = state["steps_executed"] + 1
        state["steps_executed"] = step
        console.print(f"\n[dim]Step {step}/{self._max_steps}[/dim]")

        completion = None
        max_api_retries = 3
        for attempt in range(max_api_retries):
            try:
                completion = await asyncio.wait_for(
                    self._backend.complete(
                        messages=state["messages"],
                        tools=self._get_tool_definitions(),
                    ),
                    timeout=self._step_timeout,
                )
                break
            except asyncio.TimeoutError:
                console.print(
                    f"[red]Step {step}: API call timed out after {self._step_timeout}s[/red]"
                )
                log_event("agent.run.timeout", step=step, timeout=self._step_timeout)
                state["run_reason"] = "api_timeout"
                return state
            except Exception as exc:
                if attempt < max_api_retries - 1:
                    backoff = 2 ** attempt
                    console.print(
                        f"[yellow]Step {step}: API error (attempt {attempt + 1}/{max_api_retries}), "
                        f"retrying in {backoff}s: {exc}[/yellow]"
                    )
                    log_event(
                        "agent.run.api_retry",
                        step=step,
                        attempt=attempt + 1,
                        error=str(exc),
                    )
                    await asyncio.sleep(backoff)
                    continue
                console.print(f"[red]API error (all retries exhausted): {exc}[/red]")
                log_event("agent.run.error", step=step, error=str(exc))
                state["run_reason"] = "api_error"
                return state

        if completion is None:
            state["run_reason"] = "api_error"
            return state

        content = completion.content
        tool_calls = completion.tool_calls
        if tool_calls:
            assistant_message: dict[str, Any] = {"role": "assistant", "tool_calls": tool_calls}
            if content:
                assistant_message["content"] = content
                render_response(str(content), title="Agent")
            state["messages"] = [*state["messages"], self._normalize_agent_message(assistant_message)]
            return state

        if content:
            render_response(str(content), title="Agent")
            assistant_message = self._normalize_agent_message({"role": "assistant", "content": content})
            state["messages"] = [*state["messages"], assistant_message]
            append_message(self._session_id, assistant_message)
            state["run_reason"] = "completed"
            state["final_message"] = str(content)
            return state

        log_event("agent.run.empty_response", step=step)
        state["run_reason"] = "empty_response"
        return state

    async def approval_node(self, state: AgentGraphState) -> AgentGraphState:
        if state["run_reason"]:
            return state
        if self._auto_approve or not state["messages"]:
            state["pending_tool_messages"] = []
            return state

        last_message = state["messages"][-1]
        tool_calls = last_message.get("tool_calls") or []
        if not tool_calls:
            state["pending_tool_messages"] = []
            return state

        denied_messages: list[dict[str, Any]] = []
        step = state["steps_executed"]
        for tool_call in tool_calls:
            tool_call_id = str(tool_call.get("id", ""))
            function = tool_call.get("function", {})
            tool_name = str(function.get("name", ""))
            arguments_str = function.get("arguments", "{}")
            try:
                arguments = json.loads(arguments_str)
            except json.JSONDecodeError:
                arguments = {}
            if not isinstance(arguments, dict):
                arguments = {}

            if not requires_approval(tool_name, arguments):
                continue
            if request_approval(tool_name, arguments):
                continue

            log_event(
                "agent.tool.approval_denied",
                step=step,
                tool_name=tool_name,
                tool_call_id=tool_call_id,
            )
            denied_messages.append(
                self._build_tool_message(tool_call_id=tool_call_id, content="User denied approval")
            )

        state["pending_tool_messages"] = denied_messages
        return state

    async def tools_node(self, state: AgentGraphState) -> AgentGraphState:
        if state["run_reason"]:
            return state
        if not state["messages"]:
            return state
        last_message = state["messages"][-1]
        tool_calls = last_message.get("tool_calls") or []
        if not tool_calls:
            return state

        step = state["steps_executed"]
        step_any_success = False
        stop_reason: str | None = None
        messages = list(state["messages"])
        raw_tool_names = {tool.name for tool in self._tools}
        pending_tool_messages = list(state["pending_tool_messages"])
        pending_tool_message_ids = {
            str(message.get("tool_call_id", ""))
            for message in pending_tool_messages
            if isinstance(message, dict)
        }
        state["pending_tool_messages"] = []
        tool_messages_by_id: dict[str, dict[str, Any]] = {
            str(message.get("tool_call_id", "")): message
            for message in pending_tool_messages
            if isinstance(message, dict)
        }
        executable_tool_calls: list[dict[str, Any]] = []
        executable_call_data: dict[str, tuple[str, dict[str, Any]]] = {}

        for tool_index, tool_call in enumerate(tool_calls):
            tool_call_id = str(tool_call.get("id", ""))
            if tool_index >= self._max_tool_calls_per_step:
                state["per_step_limit_hit"] = True
                console.print(
                    f"[yellow]Tool call limit reached ({self._max_tool_calls_per_step}) "
                    "for this step; skipping remaining tool calls.[/yellow]"
                )
                log_event(
                    "agent.tool.limit_reached",
                    step=step,
                    limit=self._max_tool_calls_per_step,
                    total=len(tool_calls),
                )
                for remaining_tool_call in tool_calls[tool_index:]:
                    remaining_id = str(remaining_tool_call.get("id", ""))
                    tool_messages_by_id[remaining_id] = self._build_tool_message(
                        tool_call_id=remaining_id,
                        content=f"Skipped: per-step tool call limit ({self._max_tool_calls_per_step}) reached.",
                    )
                break

            if state["tool_calls_executed"] >= self._max_tool_calls_total:
                state["total_limit_hit"] = True
                console.print(
                    f"[yellow]Total tool call limit reached ({self._max_tool_calls_total}); "
                    "stopping agent run.[/yellow]"
                )
                log_event(
                    "agent.tool.total_limit_reached",
                    step=step,
                    limit=self._max_tool_calls_total,
                    executed=state["tool_calls_executed"],
                )
                for remaining_tool_call in tool_calls[tool_index:]:
                    remaining_id = str(remaining_tool_call.get("id", ""))
                    tool_messages_by_id[remaining_id] = self._build_tool_message(
                        tool_call_id=remaining_id,
                        content=f"Skipped: total tool call limit ({self._max_tool_calls_total}) reached.",
                    )
                stop_reason = "tool_call_total_limit"
                break

            function = tool_call.get("function", {})
            tool_name = function.get("name", "")
            arguments_str = function.get("arguments", "{}")
            call_key = f"{tool_name}:{arguments_str}"
            call_count = state["tool_call_hashes"].get(call_key, 0) + 1
            state["tool_call_hashes"][call_key] = call_count
            if call_count > self._max_repeated_calls:
                console.print(
                    f"[yellow]Loop detected: '{tool_name}' called with identical arguments {call_count} times "
                    f"(limit {self._max_repeated_calls}). Stopping to avoid infinite loop.[/yellow]"
                )
                log_event(
                    "agent.tool.repeated",
                    step=step,
                    tool_name=tool_name,
                    count=call_count,
                )
                for remaining_tool_call in tool_calls[tool_index:]:
                    remaining_id = str(remaining_tool_call.get("id", ""))
                    tool_messages_by_id[remaining_id] = self._build_tool_message(
                        tool_call_id=remaining_id,
                        content=(
                            f"Aborted: '{tool_name}' has been called with identical arguments {call_count} times. "
                            "Try a different approach or tool."
                        ),
                    )
                stop_reason = "repeated_tool_calls"
                break

            if tool_call_id in pending_tool_message_ids:
                continue

            if tool_name not in raw_tool_names:
                result = ToolResult(success=False, output="", error=f"Unknown tool: {tool_name}")
                tool_messages_by_id[tool_call_id] = self._build_tool_message(
                    tool_call_id=tool_call_id,
                    content=result.error or "",
                )
                state["tool_calls_executed"] += 1
                _format_tool_result(tool_name, result, step)
                log_event(
                    "agent.tool.result",
                    step=step,
                    tool_name=tool_name,
                    success=result.success,
                )
                continue

            try:
                arguments = json.loads(arguments_str)
            except json.JSONDecodeError:
                arguments = {}

            if not isinstance(arguments, dict):
                bad_type = type(arguments).__name__
                result = ToolResult(
                    success=False,
                    output="",
                    error=(
                        f"Invalid arguments for {tool_name}: expected a JSON object but received {bad_type}. "
                        "Pass arguments as a JSON object."
                    ),
                )
                tool_messages_by_id[tool_call_id] = self._build_tool_message(
                    tool_call_id=tool_call_id,
                    content=result.error or "",
                )
                state["tool_calls_executed"] += 1
                _format_tool_result(tool_name, result, step)
                log_event(
                    "agent.tool.result",
                    step=step,
                    tool_name=tool_name,
                    success=result.success,
                )
                continue

            executable_tool_calls.append(tool_call)
            executable_call_data[tool_call_id] = (tool_name, arguments)

        if executable_tool_calls:
            for tool_call in executable_tool_calls:
                function = tool_call.get("function", {})
                tool_name = str(function.get("name", ""))
                arguments_str = str(function.get("arguments", "{}"))
                console.print(f"[cyan]Calling: {tool_name}({arguments_str})[/cyan]")

            tool_node_messages = await self._invoke_tool_node(
                [
                    *messages[:-1],
                    {**last_message, "tool_calls": executable_tool_calls},
                ]
            )
            state["tool_calls_executed"] += len(executable_tool_calls)

            for tool_message in tool_node_messages:
                if not isinstance(tool_message, dict):
                    continue
                tool_call_id = str(tool_message.get("tool_call_id", ""))
                tool_messages_by_id[tool_call_id] = tool_message
                tool_name, arguments = executable_call_data.get(tool_call_id, ("", {}))
                result = self._tool_result_from_message(
                    tool_name=tool_name,
                    content=tool_message.get("content", ""),
                )
                if result.success:
                    step_any_success = True
                    if tool_name in _FILE_TOUCH_TOOLS:
                        touched_path = arguments.get("file_path") or arguments.get("path", "")
                        if touched_path:
                            self._update_files_touched(state, str(touched_path))
                _format_tool_result(tool_name, result, step)
                log_event(
                    "agent.tool.result",
                    step=step,
                    tool_name=tool_name,
                    success=result.success,
                )

        ordered_tool_messages = []
        for tool_call in tool_calls:
            tool_call_id = str(tool_call.get("id", ""))
            tool_message = tool_messages_by_id.get(tool_call_id)
            if tool_message is not None:
                ordered_tool_messages.append(tool_message)

        if ordered_tool_messages:
            messages.extend(ordered_tool_messages)

        state["messages"] = messages
        if stop_reason:
            state["run_reason"] = stop_reason
            return state

        if step_any_success:
            state["consecutive_failure_steps"] = 0
            return state

        state["consecutive_failure_steps"] += 1
        if state["consecutive_failure_steps"] >= self._max_consecutive_failures:
            console.print(
                f"[yellow]No progress: {self._max_consecutive_failures} consecutive steps with all tool calls failing. "
                "Stopping agent.[/yellow]"
            )
            log_event(
                "agent.run.no_progress",
                step=step,
                consecutive_failures=state["consecutive_failure_steps"],
            )
            state["run_reason"] = "no_progress"
        return state

    def route_after_agent(self, state: AgentGraphState) -> str:
        if state["run_reason"]:
            return "__end__"
        last_message = state["messages"][-1] if state["messages"] else {}
        if last_message.get("role") == "assistant" and last_message.get("tool_calls"):
            return "approval"
        return "__end__"

    def route_after_approval(self, state: AgentGraphState) -> str:
        if state["run_reason"]:
            return "__end__"
        last_message = state["messages"][-1] if state["messages"] else {}
        if last_message.get("role") == "assistant" and last_message.get("tool_calls"):
            return "tools"
        return "__end__"

    def route_after_tools(self, state: AgentGraphState) -> str:
        if state["run_reason"]:
            return "__end__"
        return "agent"


async def run_graph(
    *,
    goal: str,
    backend: AgentModelBackend,
    tools: list[BaseTool],
    workspace_root: Path,
    system_prompt: str,
    workspace_rules: list[LoadedRule] | None,
    session_id: str,
    max_steps: int,
    max_tool_calls_per_step: int,
    max_tool_calls_total: int,
    step_timeout: float,
    max_repeated_calls: int,
    max_consecutive_failures: int,
    max_tool_output_chars: int,
    auto_approve: bool,
) -> AgentGraphState:
    """Run the canonical LangGraph agent runtime and return the final graph state."""
    console.print(Panel(f"[bold]{goal}[/bold]", title="Agent Goal", border_style="blue"))
    log_event("agent.run.start", goal=goal, max_steps=max_steps, tool_count=len(tools))
    append_message(session_id, {"role": "user", "content": f"Agent goal: {goal}"})

    start, end, state_graph_cls, async_sqlite_saver_cls, tool_node_cls = _load_langgraph_dependencies()
    runner = AgentGraphRunner(
        backend=backend,
        tools=tools,
        workspace_root=workspace_root,
        max_steps=max_steps,
        max_tool_calls_per_step=max_tool_calls_per_step,
        max_tool_calls_total=max_tool_calls_total,
        step_timeout=step_timeout,
        max_repeated_calls=max_repeated_calls,
        max_consecutive_failures=max_consecutive_failures,
        max_tool_output_chars=max_tool_output_chars,
        auto_approve=auto_approve,
        system_prompt=system_prompt,
        workspace_rules=workspace_rules,
        session_id=session_id,
        tool_node_cls=tool_node_cls,
    )

    checkpoint_path = _checkpoint_path(workspace_root)
    initial_state = runner.build_initial_state(goal)

    config = {"configurable": {"thread_id": session_id}}
    async with async_sqlite_saver_cls.from_conn_string(str(checkpoint_path)) as checkpointer:
        graph = _build_compiled_graph(
            state_graph_cls=state_graph_cls,
            start=start,
            end=end,
            runner=runner,
            checkpointer=checkpointer,
        )
        final_state = await graph.ainvoke(initial_state, config=config)

    log_event("agent.run.done", steps=final_state["steps_executed"], reason=final_state["run_reason"])
    runner.emit_summary(final_state)
    append_message(
        session_id,
        {"role": "meta", "reason": final_state["run_reason"], "steps": final_state["steps_executed"]},
    )
    return final_state


async def resume_graph(
    *,
    backend: AgentModelBackend,
    tools: list[BaseTool],
    workspace_root: Path,
    system_prompt: str,
    workspace_rules: list[LoadedRule] | None,
    session_id: str,
    max_steps: int,
    max_tool_calls_per_step: int,
    max_tool_calls_total: int,
    step_timeout: float,
    max_repeated_calls: int,
    max_consecutive_failures: int,
    max_tool_output_chars: int,
    auto_approve: bool,
) -> AgentGraphState:
    """Resume the canonical LangGraph agent runtime from the latest checkpoint for a thread."""
    console.print(Panel(f"[bold]{session_id}[/bold]", title="Resuming Agent Thread", border_style="blue"))
    log_event(
        "agent.run.resume.start",
        session_id=session_id,
        max_steps=max_steps,
        tool_count=len(tools),
    )

    start, end, state_graph_cls, async_sqlite_saver_cls, tool_node_cls = _load_langgraph_dependencies()
    runner = AgentGraphRunner(
        backend=backend,
        tools=tools,
        workspace_root=workspace_root,
        max_steps=max_steps,
        max_tool_calls_per_step=max_tool_calls_per_step,
        max_tool_calls_total=max_tool_calls_total,
        step_timeout=step_timeout,
        max_repeated_calls=max_repeated_calls,
        max_consecutive_failures=max_consecutive_failures,
        max_tool_output_chars=max_tool_output_chars,
        auto_approve=auto_approve,
        system_prompt=system_prompt,
        workspace_rules=workspace_rules,
        session_id=session_id,
        tool_node_cls=tool_node_cls,
    )

    checkpoint_path = _checkpoint_path(workspace_root)
    config = {"configurable": {"thread_id": session_id}}
    async with async_sqlite_saver_cls.from_conn_string(str(checkpoint_path)) as checkpointer:
        checkpoint = await checkpointer.aget_tuple(config)
        if checkpoint is None:
            raise RuntimeError(f'No checkpointed agent thread found for "{session_id}".')
        graph = _build_compiled_graph(
            state_graph_cls=state_graph_cls,
            start=start,
            end=end,
            runner=runner,
            checkpointer=checkpointer,
        )
        final_state = await graph.ainvoke(None, config=config)

    log_event(
        "agent.run.resume.done",
        session_id=session_id,
        steps=final_state["steps_executed"],
        reason=final_state["run_reason"],
    )
    runner.emit_summary(final_state)
    append_message(
        session_id,
        {"role": "meta", "reason": final_state["run_reason"], "steps": final_state["steps_executed"]},
    )
    return final_state