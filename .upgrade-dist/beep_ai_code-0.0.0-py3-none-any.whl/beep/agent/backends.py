"""Provider-neutral model backends for the autonomous agent."""

from __future__ import annotations

import inspect
from typing import Any, Protocol, runtime_checkable

import httpx

from beep.agent.message_adapter import AgentCompletion, extract_agent_completion
from beep.api.client import BeepAPIClient
from beep.api.errors import BeepAPIError
from beep.config import BeepConfig


@runtime_checkable
class AgentModelBackend(Protocol):
    """Protocol implemented by model backends used by the autonomous agent."""

    async def complete(
        self,
        *,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> AgentCompletion:
        """Run one model completion."""

    async def close(self) -> None:
        """Release any transport resources owned by the backend."""


class BeepAgentBackend:
    """Backend that calls the Beep.AI.Server OpenAI-compatible chat surface."""

    def __init__(
        self,
        client: Any,
        *,
        model: str | None = None,
        coding_assistant: dict[str, Any] | None = None,
        owns_client: bool = False,
    ) -> None:
        self._client = client
        self._model = model
        self._coding_assistant = coding_assistant
        self._owns_client = owns_client

    async def complete(
        self,
        *,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> AgentCompletion:
        response = await self._client.chat_completion(
            messages=messages,
            model=self._model,
            tools=tools,
            coding_assistant=self._coding_assistant,
        )
        return extract_agent_completion(response)

    async def close(self) -> None:
        if not self._owns_client:
            return None
        close = getattr(self._client, "close", None)
        if close is None or not callable(close):
            return None
        result = close()
        if inspect.isawaitable(result):
            await result
        return None


class OpenAICompatibleAgentBackend:
    """Backend that calls a generic OpenAI-compatible chat completion endpoint."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str | None,
        model: str | None,
        request_timeout: float = 60.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._model = model
        self._request_timeout = request_timeout
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers: dict[str, str] = {}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                timeout=httpx.Timeout(self._request_timeout, connect=10.0),
            )
        return self._client

    async def complete(
        self,
        *,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> AgentCompletion:
        payload: dict[str, Any] = {"messages": messages}
        if self._model:
            payload["model"] = self._model
        if tools:
            payload["tools"] = tools
        client = await self._get_client()
        response = await client.post("/v1/chat/completions", json=payload)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            try:
                detail = exc.response.text
            except Exception:
                detail = str(exc)
            raise BeepAPIError(exc.response.status_code, "/v1/chat/completions", detail) from exc
        return extract_agent_completion(response.json())

    async def close(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
        self._client = None


def coerce_agent_backend(
    model_client: Any,
    *,
    coding_assistant: dict[str, Any] | None = None,
    model: str | None = None,
) -> AgentModelBackend:
    """Convert a provided backend/client object into the autonomous agent backend contract."""
    if isinstance(model_client, AgentModelBackend):
        return model_client
    if hasattr(model_client, "complete") and callable(model_client.complete):
        return model_client
    if hasattr(model_client, "chat_completion") and callable(model_client.chat_completion):
        return BeepAgentBackend(
            model_client,
            model=model,
            coding_assistant=coding_assistant,
        )
    raise TypeError(
        "Unsupported agent backend object. Expected an AgentModelBackend or an object with chat_completion()."
    )


def build_agent_backend(
    config: BeepConfig,
    *,
    client: Any = None,
    coding_assistant: dict[str, Any] | None = None,
    plugin_registry: Any | None = None,
) -> AgentModelBackend:
    """Create the configured backend for the autonomous agent."""
    from beep.agent.provider_plugins import get_agent_backend_provider

    provider = get_agent_backend_provider(
        config.agent_backend,
        plugin_registry=plugin_registry,
    )
    return provider.build_backend(
        config,
        client=client,
        coding_assistant=coding_assistant,
    )