"""Rich TUI interface using Textual.

Provides a full interactive terminal interface with:
- Chat panel with streaming responses
- File explorer sidebar
- Status bar with token usage
- Command palette
"""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Footer, Header, Input, Label, RichLog, Static, Tree

from beep import __version__
from beep.api.client import BeepAPIClient
from beep.config import BeepConfig


class ChatPanel(Vertical):
    """Main chat display area."""

    def compose(self) -> ComposeResult:
        yield RichLog(id="chat-log", markup=True, wrap=True)
        yield Input(id="chat-input", placeholder="Type a message... (Ctrl+C to quit)")


class FileExplorer(Vertical):
    """File explorer sidebar."""

    def compose(self) -> ComposeResult:
        yield Static("Files", id="file-header", classes="panel-header")
        yield Tree(id="file-tree")


class StatusBar(Horizontal):
    """Status bar at the bottom."""

    def __init__(self) -> None:
        super().__init__()
        self._model = ""
        self._tokens = ""
        self._session = ""

    def compose(self) -> ComposeResult:
        yield Label(id="status-model", classes="status-item")
        yield Label(id="status-tokens", classes="status-item")
        yield Label(id="status-session", classes="status-item")

    def update_model(self, model: str) -> None:
        self._model = model
        widget = self.query_one("#status-model", Label)
        widget.update(f"Model: {model}")

    def update_tokens(self, prompt: int, completion: int) -> None:
        total = prompt + completion
        widget = self.query_one("#status-tokens", Label)
        widget.update(f"Tokens: {total}")

    def update_session(self, session_id: str) -> None:
        self._session = session_id[:8]
        widget = self.query_one("#status-session", Label)
        widget.update(f"Session: {self._session}")


class BeepTUI(App):
    """Main TUI application."""

    CSS = """
    Screen {
        layout: vertical;
    }

    #main-area {
        height: 1fr;
        layout: horizontal;
    }

    #chat-panel {
        width: 1fr;
        border: solid blue;
        padding: 1;
    }

    #file-explorer {
        width: 30;
        border: solid green;
        padding: 1;
    }

    #status-bar {
        height: 1;
        background: $surface;
        dock: bottom;
    }

    .status-item {
        padding: 0 2;
    }

    .panel-header {
        text-style: bold;
        color: $primary;
    }

    #chat-log {
        height: 1fr;
    }

    #chat-input {
        dock: bottom;
    }
    """

    TITLE = f"Beep.AI.Code v{__version__}"
    SUB_TITLE = "CLI Code Assistant"

    def __init__(
        self,
        config: BeepConfig,
        *,
        model: str | None = None,
        mode: str = "assistant",
    ) -> None:
        super().__init__()
        self._config = config
        self._model = model or config.default_model or "default"
        self._mode = mode
        self._client: BeepAPIClient | None = None
        self._messages: list[dict[str, str]] = []

    def on_mount(self) -> None:
        """Initialize on mount."""
        self._client = BeepAPIClient(self._config)
        self.sub_title = f"Model: {self._model}"

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        if event.input.id != "chat-input":
            return

        user_input = event.value.strip()
        if not user_input:
            return

        event.input.value = ""

        chat_log = self.query_one("#chat-log", RichLog)
        chat_log.write(f"[bold green]You:[/bold green] {user_input}")

        self._messages.append({"role": "user", "content": user_input})

        try:
            if self._client is None:
                chat_log.write("[bold red]Error:[/bold red] Client not initialized")
                return
            response_text = ""
            async for chunk in self._client.chat_completion_stream(
                messages=self._messages,
                model=self._model,
            ):
                response_text += chunk

            if response_text.strip():
                chat_log.write(f"[bold blue]Assistant:[/bold blue] {response_text}")
                self._messages.append({"role": "assistant", "content": response_text})
            else:
                chat_log.write(
                    "[bold yellow]Warning:[/bold yellow] "
                    "Model returned an empty response"
                )
        except Exception as e:
            chat_log.write(f"[bold red]Error:[/bold red] {e}")

    def on_key(self, event) -> None:
        """Handle key presses."""
        if event.key == "ctrl+c":
            self.exit()

    def compose(self) -> ComposeResult:
        yield Header()
        yield Container(
            ChatPanel(id="chat-panel"),
            FileExplorer(id="file-explorer"),
            id="main-area",
        )
        yield StatusBar(id="status-bar")
        yield Footer()


def run_tui(
    config: BeepConfig,
    *,
    model: str | None = None,
    mode: str = "assistant",
) -> None:
    """Run the TUI application."""
    app = BeepTUI(config, model=model, mode=mode)
    app.run()
