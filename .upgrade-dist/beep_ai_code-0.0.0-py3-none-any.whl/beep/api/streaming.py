"""Streaming response parsing for Beep.AI.Server APIs."""

from __future__ import annotations

import json
from collections.abc import AsyncIterable, AsyncIterator

# Sentinel prefix used to signal a tool-call event through the text stream.
# Format: \x00TC:<tool_name>\x00
TOOL_CALL_PREFIX = "\x00TC:"
TOOL_CALL_SUFFIX = "\x00"


async def iter_chat_sse_content(
    lines: AsyncIterable[str],
) -> AsyncIterator[tuple[str, dict[str, int] | None]]:
    """Yield content chunks and optional usage from OpenAI-style SSE lines.

    When a streaming delta contains ``tool_calls``, a sentinel marker of the
    form ``\x00TC:<name>\x00`` is emitted so renderers can display tool-call
    activity without receiving real text content.
    """
    async for line in lines:
        if not line or not line.startswith("data: "):
            continue
        data = line[6:]
        if data == "[DONE]":
            break
        try:
            chunk = json.loads(data)
        except json.JSONDecodeError:
            continue

        usage = chunk.get("usage")
        normalized_usage = None
        if isinstance(usage, dict):
            normalized_usage = {
                "prompt_tokens": int(usage.get("prompt_tokens", 0)),
                "completion_tokens": int(usage.get("completion_tokens", 0)),
                "total_tokens": int(usage.get("total_tokens", 0)),
            }

        choices = chunk.get("choices", [])
        if not choices:
            if normalized_usage:
                yield "", normalized_usage
            continue

        delta = choices[0].get("delta", {})
        content = delta.get("content", "")

        # Emit a marker for any named tool-call in this delta
        for tc in delta.get("tool_calls", []):
            name = tc.get("function", {}).get("name", "")
            if name:
                yield f"{TOOL_CALL_PREFIX}{name}{TOOL_CALL_SUFFIX}", None

        if content or normalized_usage:
            yield content, normalized_usage
