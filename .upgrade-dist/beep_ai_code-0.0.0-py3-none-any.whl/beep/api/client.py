"""Async API client for Beep.AI.Server.

Beep.AI.Code connects to Beep.AI.Server the same way Claude Code connects to
Anthropic's API or Codex CLI connects to OpenAI's API — via token-authenticated
endpoints.

External API surface (token-auth):
- /v1/chat/completions  — OpenAI-compatible (llm:write)
- /v1/models            — List/get models (llm:read)
- /v1/messages          — Anthropic-compatible (llm:write)
- /v1/responses         — OpenAI Responses API (llm:write)
- /v1/embeddings        — Embedding generation (llm:read)
- /ai-middleware/api/coding-assistant/* — Workspace/project/session bootstrap

Internal API surface (website session auth, NOT for CLI):
- /coding-assistant/*   — Web UI only
- /dashboard/*          — Web UI only
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from typing import Any

import httpx

from beep.api.errors import BeepAPIError
from beep.api.payloads import build_chat_completion_payload
from beep.api.streaming import iter_chat_sse_content
from beep.config import BeepConfig


class BeepAPIClient:
    """Async HTTP client for Beep.AI.Server external APIs."""

    def __init__(self, config: BeepConfig) -> None:
        self._config = config
        self._base_url = config.server_url.rstrip("/")
        self._client: httpx.AsyncClient | None = None
        self._last_stream_usage: dict[str, int] | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers = {}
            if self._config.api_token:
                headers["Authorization"] = f"Bearer {self._config.api_token}"
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                timeout=httpx.Timeout(self._config.request_timeout, connect=10.0),
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Generic HTTP request with typed error wrapping and retry on 429/503."""
        client = await self._get_client()
        max_attempts = (self._config.max_retries + 1) if self._config.retry_on_429 else 1

        for attempt in range(max_attempts):
            try:
                response = await client.request(
                    method, path, json=json, params=params, headers=extra_headers
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as exc:
                status = exc.response.status_code
                # Retry on 429 Too Many Requests and 503 Service Unavailable
                if (
                    self._config.retry_on_429
                    and status in (429, 503)
                    and attempt < max_attempts - 1
                ):
                    backoff = 2 ** attempt  # 1 s, 2 s, 4 s …
                    await asyncio.sleep(backoff)
                    continue
                try:
                    server_message = exc.response.text
                except Exception:
                    server_message = str(exc)
                raise BeepAPIError(status, path, server_message) from exc

        # Unreachable — loop always returns or raises.
        raise BeepAPIError(0, path, "Unexpected request failure")

    # ========================================================================
    # Health
    # ========================================================================

    async def health_check(self) -> dict[str, Any]:
        """Check server health (public endpoint)."""
        return await self._request("GET", "/api/health")

    async def v1_health(self) -> dict[str, Any]:
        """Check detailed server health via the token-auth /v1/health endpoint.

        Returns standard health fields plus ``coding_model_tiers`` which lists
        the model tiers available for the coding assistant (e.g. fast, balanced,
        powerful).  Use this instead of ``health_check()`` when you need to
        discover which coding tier aliases are available before choosing a model.

        Scope: llm:read (Bearer token required).
        """
        return await self._request("GET", "/v1/health")

    # ========================================================================
    # OpenAI-Compatible API (Primary — like Claude Code → Anthropic)
    # ========================================================================

    async def list_models(self) -> list[dict[str, Any]]:
        """List available models. Scope: llm:read"""
        data = await self._request("GET", "/v1/models")
        return data.get("data", [])

    async def get_model(self, model_id: str) -> dict[str, Any]:
        """Get details for a specific model. Scope: llm:read"""
        return await self._request("GET", f"/v1/models/{model_id}")

    async def chat_completion(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        stream: bool = False,
        tools: list[dict[str, Any]] | None = None,
        coding_assistant: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a chat completion request. Scope: llm:write

        If coding_assistant metadata is provided, the server automatically
        handles project/session resolution, tool calling, and code changes.

        Example coding_assistant metadata:
            {"project_id": 1, "interaction_mode": "agent"}
            {"workspace_root": "/path/to/project", "interaction_mode": "inline"}
        """
        payload = build_chat_completion_payload(
            self._config,
            messages=messages,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            tools=tools,
            coding_assistant=coding_assistant,
        )

        return await self._request("POST", "/v1/chat/completions", json=payload)

    async def chat_completion_stream(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        tools: list[dict[str, Any]] | None = None,
        coding_assistant: dict[str, Any] | None = None,
    ) -> AsyncGenerator[str, None]:
        """Stream a chat completion response. Scope: llm:write"""
        client = await self._get_client()
        self._last_stream_usage = None

        payload = build_chat_completion_payload(
            self._config,
            messages=messages,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            stream=True,
            tools=tools,
            coding_assistant=coding_assistant,
        )

        async with client.stream("POST", "/v1/chat/completions", json=payload) as response:
            response.raise_for_status()
            async for content, usage in iter_chat_sse_content(response.aiter_lines()):
                if usage:
                    self._last_stream_usage = usage
                if content:
                    yield content

    def get_last_stream_usage(self) -> dict[str, int] | None:
        """Return usage metadata from the most recent streamed response."""
        return self._last_stream_usage

    async def compact_conversation(
        self,
        *,
        session_id: str,
        messages: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Request server-side conversation compaction when endpoint is available."""
        payload: dict[str, Any] = {
            "session_id": session_id,
            "messages": messages,
        }
        return await self._request(
            "POST",
            "/ai-middleware/api/coding-assistant/sessions/compact",
            json=payload,
        )

    # ========================================================================
    # Anthropic-Compatible API
    # ========================================================================

    async def anthropic_messages(
        self,
        messages: list[dict[str, Any]],
        model: str | None = None,
        max_tokens: int = 4096,
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        thinking: dict[str, Any] | None = None,
        beta_features: list[str] | None = None,
    ) -> dict[str, Any]:
        """Send a request to the Anthropic Messages API endpoint.  Scope: llm:write

        Args:
            messages:      Anthropic-format message list.
            model:         Model ID or Beep tier alias (falls back to config default).
            max_tokens:    Maximum tokens to generate.
            system:        Optional system prompt string.
            tools:         Optional list of Anthropic-format tool definitions.
            thinking:      Optional extended-thinking config, e.g.
                           ``{"type": "enabled", "budget_tokens": 8000}``.
            beta_features: Optional list of Anthropic beta feature strings sent
                           as the ``anthropic-beta`` request header (comma-joined),
                           e.g. ``["interleaved-thinking-2025-05-14"]``.
        """
        payload: dict[str, Any] = {
            "messages": messages,
            "max_tokens": max_tokens,
        }
        if model or self._config.default_model:
            payload["model"] = model or self._config.default_model
        if system:
            payload["system"] = system
        if tools:
            payload["tools"] = tools
        if thinking:
            payload["thinking"] = thinking

        extra_headers: dict[str, str] | None = None
        if beta_features:
            extra_headers = {"anthropic-beta": ",".join(beta_features)}

        return await self._request(
            "POST", "/v1/messages", json=payload, extra_headers=extra_headers
        )

    # ========================================================================
    # Extended OpenAI API
    # ========================================================================

    async def responses_completion(
        self,
        input_text: str,
        model: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Use OpenAI Responses API. Scope: llm:write

        Deprecated: use :meth:`openai_responses` instead.
        """
        return await self.openai_responses(input_text, model=model, tools=tools)

    async def openai_responses(
        self,
        input: str | list[dict[str, Any]],
        model: str | None = None,
        previous_response_id: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        reasoning: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a request to the OpenAI Responses API endpoint.  Scope: llm:write

        Args:
            input:               String prompt or a list of OpenAI Responses
                                 input item dicts.
            model:               Model ID or Beep tier alias (falls back to
                                 config default).
            previous_response_id: ID of a prior response to continue from
                                 (for multi-turn Responses API conversations).
            tools:               Optional tool definitions, including
                                 ``computer_use_preview`` items.
            reasoning:           Optional reasoning control dict, e.g.
                                 ``{"effort": "high"}``.
        """
        payload: dict[str, Any] = {"input": input}
        if model or self._config.default_model:
            payload["model"] = model or self._config.default_model
        if previous_response_id:
            payload["previous_response_id"] = previous_response_id
        if tools:
            payload["tools"] = tools
        if reasoning:
            payload["reasoning"] = reasoning
        return await self._request("POST", "/v1/responses", json=payload)

    async def create_embeddings(
        self,
        input_texts: list[str],
        model: str | None = None,
    ) -> dict[str, Any]:
        """Create embeddings. Scope: llm:read"""
        payload: dict[str, Any] = {"input": input_texts}
        if model:
            payload["model"] = model
        return await self._request("POST", "/v1/embeddings", json=payload)

    # ========================================================================
    # AI Middleware — Token-Auth Coding Assistant (for external CLI clients)
    # ========================================================================

    async def bootstrap_workspace(
        self,
        workspace_root: str,
        *,
        create_project_if_missing: bool = True,
        create_session_if_missing: bool = True,
        interaction_mode: str = "inline",
        model_id: str | None = None,
    ) -> dict[str, Any]:
        """Auto-find or auto-create a project from workspace root.

        Returns a transport manifest with project_id, session_id, model,
        and tool definitions — the entry point for external CLI clients.

        Scope: llm:write, agent:execute
        """
        payload: dict[str, Any] = {
            "workspace_root": workspace_root,
            "create_project_if_missing": create_project_if_missing,
            "create_session_if_missing": create_session_if_missing,
            "interaction_mode": interaction_mode,
        }
        if model_id:
            payload["model_id"] = model_id
        return await self._request(
            "POST",
            "/ai-middleware/api/coding-assistant/workspaces/bootstrap",
            json=payload,
        )

    async def bootstrap_project(
        self,
        project_id: int,
        *,
        session_id: str | None = None,
        interaction_mode: str = "inline",
        model_id: str | None = None,
        include_coding_tools: bool = True,
    ) -> dict[str, Any]:
        """Resolve project runtime state and create/attach a session.

        Scope: llm:write, agent:execute
        """
        payload: dict[str, Any] = {
            "interaction_mode": interaction_mode,
            "include_coding_tools": include_coding_tools,
        }
        if session_id:
            payload["session_id"] = session_id
        if model_id:
            payload["model_id"] = model_id
        return await self._request(
            "POST",
            f"/ai-middleware/api/coding-assistant/projects/{project_id}/bootstrap",
            json=payload,
        )

    async def create_session(
        self,
        project_id: int,
        title: str | None = None,
        model_id: str | None = None,
        interaction_mode: str = "inline",
    ) -> dict[str, Any]:
        """Create a coding assistant session. Scope: llm:write, agent:execute"""
        payload: dict[str, Any] = {"interaction_mode": interaction_mode}
        if title:
            payload["title"] = title
        if model_id:
            payload["model_id"] = model_id
        return await self._request(
            "POST",
            f"/ai-middleware/api/coding-assistant/projects/{project_id}/sessions",
            json=payload,
        )

    async def list_sessions(self, project_id: int) -> list[dict[str, Any]]:
        """List sessions for a project. Scope: llm:read, agent:read"""
        result = await self._request(
            "GET",
            f"/ai-middleware/api/coding-assistant/projects/{project_id}/sessions",
        )
        return result.get("sessions", [])

    # ========================================================================
    # RAG API (token-auth)
    # ========================================================================

    async def rag_query(
        self,
        query: str,
        *,
        collection: str | None = None,
        top_k: int = 5,
    ) -> dict[str, Any]:
        """Query RAG knowledge base. Scope: rag:read"""
        payload: dict[str, Any] = {"query": query, "top_k": top_k}
        if collection:
            payload["collection"] = collection
        return await self._request("POST", "/v1/rag/query", json=payload)

    async def rag_list_collections(self) -> list[dict[str, Any]]:
        """List RAG collections. Scope: rag:read"""
        result = await self._request("GET", "/v1/rag/collections")
        return result.get("collections", [])

    # ========================================================================
    # Token Validation
    # ========================================================================

    async def check_token(self) -> dict[str, Any]:
        """Validate the current API token. Public endpoint."""
        return await self._request("GET", "/ai-middleware/api/tokens/check")
