"""Workspace prompt context shared by chat, ask, and agent flows."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from beep.chat.prompts import build_tool_list_section, get_system_prompt
from beep.memory.loader import load_project_memory
from beep.rules.resolver import build_rules_context


def build_workspace_system_prompt(
    mode: str,
    workspace_root: Path | str,
    *,
    tools: list | None = None,
    extra_sections: Iterable[str] | None = None,
    skill_query: str | None = None,
) -> str:
    """Build a system prompt enriched with project memory, active rules, and tool list."""
    workspace_path = Path(workspace_root)
    sections = [get_system_prompt(mode)]

    memory_prompt = load_project_memory(workspace_path).to_prompt_section().strip()
    if memory_prompt:
        sections.append(memory_prompt)

    try:
        from beep.rules.loader import load_rules

        rules, _errors = load_rules(workspace_path)
    except Exception:
        rules = []

    rules_context = build_rules_context(rules)
    if rules_context:
        sections.append(rules_context)

    if skill_query:
        try:
            from beep.skills.loader import load_skills
            from beep.skills.resolver import SkillResolver

            skills, _serrors, _sroots = load_skills(workspace_path)
            if skills:
                resolver = SkillResolver(skills)
                matches = resolver.resolve(skill_query, max_skills=3, budget_chars=3000)
                if matches:
                    skill_lines = ["## Active Skills"]
                    for match in matches:
                        skill_lines.append(f"\n### {match.skill.name}\n{match.skill.body}")
                    sections.append("\n".join(skill_lines).strip())
        except Exception:
            pass

    if tools:
        tool_section = build_tool_list_section(tools)
        if tool_section:
            sections.append(tool_section)

    if extra_sections:
        sections.extend(section.strip() for section in extra_sections if section.strip())

    return "\n\n".join(sections)

