"""Coding Assistant integration helpers."""
