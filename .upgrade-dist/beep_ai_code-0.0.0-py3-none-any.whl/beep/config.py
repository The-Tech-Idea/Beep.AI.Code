"""Configuration management for Beep.AI.Code."""

from __future__ import annotations

import json
import os
from pathlib import Path

from pydantic import BaseModel, Field


class MCPToolConfig(BaseModel):
    """Tool declaration for an MCP server entry in config."""

    name: str
    description: str = ""
    parameters: dict = Field(default_factory=dict)


class MCPServerConfig(BaseModel):
    """MCP server declaration for optional local tool bridging."""

    name: str
    command: str
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    tools: list[MCPToolConfig] = Field(default_factory=list)


class BeepConfig(BaseModel):
    """Configuration for Beep.AI.Code CLI."""

    server_url: str = Field(default="http://localhost:5000", description="Beep.AI.Server URL")
    api_token: str | None = Field(default=None, description="API authentication token")
    default_model: str | None = Field(default=None, description="Default model ID")
    agent_backend: str = Field(
        default="beep",
        description="Backend used by the autonomous coding agent",
    )
    agent_base_url: str | None = Field(
        default=None,
        description="Optional base URL override used by the autonomous coding agent",
    )
    agent_api_key: str | None = Field(
        default=None,
        description="Optional API key override used by the autonomous coding agent",
    )
    agent_model: str | None = Field(
        default=None,
        description="Optional model override used by the autonomous coding agent",
    )
    max_tokens: int = Field(default=4096, ge=1, le=128000, description="Max tokens per request")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="Sampling temperature")
    project_id: int | None = Field(default=None, description="Coding Assistant project ID")
    mcp_enabled: bool = Field(default=False, description="Enable optional MCP bridge")
    mcp_servers: list[MCPServerConfig] = Field(
        default_factory=list,
        description="Configured MCP servers for optional bridge",
    )
    request_timeout: float = Field(
        default=60.0, ge=1.0, description="HTTP request timeout in seconds"
    )
    retry_on_429: bool = Field(
        default=True, description="Retry requests on HTTP 429 / 503 responses"
    )
    max_retries: int = Field(
        default=3, ge=0, le=10, description="Maximum retry attempts for transient errors"
    )

    @property
    def is_configured(self) -> bool:
        return self.api_token is not None and bool(self.api_token.strip())

    @property
    def effective_agent_base_url(self) -> str:
        """Return the resolved base URL for the autonomous agent backend."""
        return (self.agent_base_url or self.server_url).rstrip("/")

    @property
    def effective_agent_api_key(self) -> str | None:
        """Return the resolved API key for the autonomous agent backend."""
        token = self.agent_api_key if self.agent_api_key is not None else self.api_token
        if token is None:
            return None
        return token.strip() or None

    @property
    def effective_agent_model(self) -> str | None:
        """Return the resolved model for the autonomous agent backend."""
        model = self.agent_model if self.agent_model is not None else self.default_model
        if model is None:
            return None
        return model.strip() or None

    @property
    def is_agent_configured(self) -> bool:
        """Return True when the autonomous agent backend has enough configuration."""
        if not self.effective_agent_base_url:
            return False
        if self.agent_backend in {"beep", "openai-compatible"}:
            return self.effective_agent_api_key is not None
        return False


CONFIG_DIR = Path.home() / ".beepai"
CONFIG_FILE = CONFIG_DIR / "code.json"


def load_config() -> BeepConfig:
    """Load configuration from file and environment variables."""
    data: dict = {}

    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    env_url = os.environ.get("BEEP_SERVER_URL")
    if env_url:
        data["server_url"] = env_url

    env_token = os.environ.get("BEEP_API_TOKEN")
    if env_token:
        data["api_token"] = env_token

    env_model = os.environ.get("BEEP_DEFAULT_MODEL")
    if env_model:
        data["default_model"] = env_model

    env_agent_backend = os.environ.get("BEEP_AGENT_BACKEND")
    if env_agent_backend:
        data["agent_backend"] = env_agent_backend

    env_agent_base_url = os.environ.get("BEEP_AGENT_BASE_URL")
    if env_agent_base_url:
        data["agent_base_url"] = env_agent_base_url

    env_agent_api_key = os.environ.get("BEEP_AGENT_API_KEY")
    if env_agent_api_key:
        data["agent_api_key"] = env_agent_api_key

    env_agent_model = os.environ.get("BEEP_AGENT_MODEL")
    if env_agent_model:
        data["agent_model"] = env_agent_model

    env_project_id = os.environ.get("BEEP_PROJECT_ID")
    if env_project_id:
        data["project_id"] = int(env_project_id)

    env_mcp = os.environ.get("BEEP_MCP")
    if env_mcp:
        data["mcp_enabled"] = env_mcp.strip().lower() in {"1", "true", "yes", "on"}

    return BeepConfig(**data)


def save_config(config: BeepConfig) -> None:
    """Save configuration to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    data = config.model_dump(exclude_none=True)

    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    os.chmod(CONFIG_FILE, 0o600)


def get_config_path() -> Path:
    """Return the config file path."""
    return CONFIG_FILE
