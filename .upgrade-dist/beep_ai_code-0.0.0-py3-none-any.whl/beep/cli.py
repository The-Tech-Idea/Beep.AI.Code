"""CLI application for Beep.AI.Code.

Usage:
    beep                    → Interactive chat REPL (like Claude Code)
    beep "question"         → One-shot answer
    beep setup              → Configuration wizard
    beep test               → Run tests
    beep lint --fix         → Lint and fix
    beep --help             → Show all commands
"""

from __future__ import annotations

import asyncio
import sys

import typer
from rich.console import Console
from rich.table import Table

from beep import __version__
from beep.api.client import BeepAPIClient
from beep.cli_defaults import parse_default_invocation
from beep.commands.agent import (
    agent_cmd,
    agent_providers_cmd,
    agent_reinstall_cmd,
    agent_resume_cmd,
    agent_setup_cmd,
    agent_status_cmd,
    agent_uninstall_cmd,
)
from beep.commands.rag import rag_collections_cmd, rag_query_cmd
from beep.commands.sessions import sessions_delete_cmd, sessions_export_cmd, sessions_list_cmd
from beep.commands.template import template_cmd, template_list_cmd
from beep.config import CONFIG_FILE, BeepConfig, load_config, save_config
from beep.setup_wizard import ensure_configured, run_agent_provider_setup_wizard, run_setup_wizard

app = typer.Typer(
    name="beep",
    help="CLI code assistant powered by Beep.AI.Server",
    add_completion=True,
)
console = Console()

_SUBCOMMANDS = {
    "setup",
    "status",
    "version",
    "config",
    "config-set",
    "chat",
    "ask",
    "agent",
    "tui",
    "tree",
    "cat",
    "grep",
    "edit",
    "review",
    "test",
    "lint",
    "analyze",
    "diagnostics",
    "template",
    "sessions",
    "rag",
    "watch",
    "--help",
    "-h",
    "--version",
}


def _require_config() -> BeepConfig:
    return ensure_configured()


def _is_subcommand() -> bool:
    """Check if argv contains a known subcommand or flag."""
    args = sys.argv[1:]
    if not args:
        return False
    first = args[0]
    if first.startswith("-"):
        return True
    if first in ("--help", "-h", "--version"):
        return True
    return first in _SUBCOMMANDS


@app.command()
def setup() -> None:
    """Run interactive setup wizard."""
    try:
        run_setup_wizard()
    except KeyboardInterrupt:
        console.print("\n[yellow]Setup cancelled[/yellow]")
    except Exception as exc:
        console.print(f"[red]Setup failed: {exc}[/red]")
        raise typer.Exit(1)


@app.command()
def status() -> None:
    """Check server health and connection status."""
    config = _require_config()

    with console.status("Connecting to server..."):
        client = BeepAPIClient(config)
        try:
            health = asyncio.run(client.health_check())
        except Exception as e:
            console.print(f"[red]Connection failed: {e}[/red]")
            raise typer.Exit(1)
        finally:
            try:
                asyncio.run(client.close())
            except Exception:
                pass

    table = Table(title="Beep.AI.Server Status")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Server URL", config.server_url)
    table.add_row("Configured", "Yes")
    table.add_row("Config File", str(CONFIG_FILE))

    if isinstance(health, dict):
        for key, value in health.items():
            if isinstance(value, (str, int, float, bool)):
                table.add_row(str(key), str(value))

    console.print(table)


@app.command()
def version() -> None:
    """Show version information."""
    console.print(f"Beep.AI.Code v{__version__}")


@app.command("config")
def config_show() -> None:
    """Show current configuration."""
    config = load_config()

    table = Table(title="Current Configuration")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Server URL", config.server_url)
    table.add_row("API Token", "***" + config.api_token[-4:] if config.api_token else "Not set")
    table.add_row("Default Model", config.default_model or "(server default)")
    table.add_row("Agent Backend", config.agent_backend)
    table.add_row("Agent Base URL", config.agent_base_url or "(uses server_url)")
    table.add_row(
        "Agent API Key",
        "***" + config.agent_api_key[-4:] if config.agent_api_key else "(uses api_token)",
    )
    table.add_row("Agent Model", config.agent_model or "(uses default_model)")
    table.add_row("Max Tokens", str(config.max_tokens))
    table.add_row("Temperature", str(config.temperature))
    table.add_row("Config File", str(CONFIG_FILE))

    console.print(table)


@app.command("config-set")
def config_set(key: str, value: str) -> None:
    """Set a configuration value."""
    config = load_config()

    valid_keys = {
        "server_url",
        "api_token",
        "default_model",
        "agent_backend",
        "agent_base_url",
        "agent_api_key",
        "agent_model",
        "max_tokens",
        "temperature",
    }
    if key not in valid_keys:
        console.print(f"[red]Invalid key. Valid keys: {', '.join(sorted(valid_keys))}[/red]")
        raise typer.Exit(1)

    if key == "max_tokens":
        try:
            parsed_max_tokens = int(value)
        except ValueError:
            console.print("[red]max_tokens must be an integer[/red]")
            raise typer.Exit(1)
        if parsed_max_tokens <= 0:
            console.print("[red]max_tokens must be greater than 0[/red]")
            raise typer.Exit(1)
        setattr(config, key, parsed_max_tokens)
    elif key == "temperature":
        try:
            parsed_temperature = float(value)
        except ValueError:
            console.print("[red]temperature must be a number[/red]")
            raise typer.Exit(1)
        if parsed_temperature < 0 or parsed_temperature > 2:
            console.print("[red]temperature must be between 0 and 2[/red]")
            raise typer.Exit(1)
        setattr(config, key, parsed_temperature)
    elif key == "agent_backend":
        normalized_value = value.strip()
        if not normalized_value:
            console.print("[red]agent_backend must be a non-empty provider key[/red]")
            raise typer.Exit(1)
        setattr(config, key, normalized_value)
    else:
        setattr(config, key, value if value else None)

    try:
        save_config(config)
    except Exception as exc:
        console.print(f"[red]Failed to save config: {exc}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Set {key} = {value}[/green]")


@app.command()
def chat(
    model: str | None = typer.Option(None, "--model", "-m"),
    mode: str = typer.Option("assistant", "--mode"),
    resume: str | None = typer.Option(None, "--resume", "-r"),
    tokens: bool = typer.Option(False, "--tokens"),
    no_plugins: bool = typer.Option(False, "--no-plugins"),
) -> None:
    """Start interactive chat (same as running `beep` with no args)."""
    from beep.commands.chat import chat_cmd

    chat_cmd(model=model, mode=mode, show_tokens=tokens, resume=resume, no_plugins=no_plugins)


@app.command()
def ask(
    question: str = typer.Argument(...),
    model: str | None = typer.Option(None, "--model", "-m"),
    mode: str = typer.Option("assistant", "--mode"),
) -> None:
    """Ask a one-shot question (same as `beep "question"`)."""
    from beep.commands.ask import ask_cmd

    ask_cmd(question, model=model, mode=mode)


@app.command(context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def agent(
    ctx: typer.Context,
    max_steps: int = typer.Option(20, "--max-steps", "-n"),
    yes: bool = typer.Option(False, "--yes", "-y"),
    model: str | None = typer.Option(None, "--model", "-m"),
    no_plugins: bool = typer.Option(False, "--no-plugins"),
) -> None:
    """Run autonomous agent or manage the managed agent runtime.

    Special forms:
    - beep agent setup
    - beep agent status
    - beep agent providers
    - beep agent configure [provider_key]
    - beep agent resume <thread_id>
    - beep agent reinstall <package|runtime>
    - beep agent uninstall [--yes]
    """
    if not ctx.args:
        console.print("[yellow]Usage: beep agent <goal> | beep agent setup | beep agent status[/yellow]")
        raise typer.Exit(2)

    action = ctx.args[0].strip().lower()
    extra = ctx.args[1:]
    if action == "setup" and not extra:
        agent_setup_cmd()
        return
    if action == "status" and not extra:
        agent_status_cmd()
        return
    if action == "providers" and not extra:
        agent_providers_cmd()
        return
    if action == "configure":
        if len(extra) > 1:
            console.print("[yellow]Usage: beep agent configure [provider_key][/yellow]")
            raise typer.Exit(2)
        run_agent_provider_setup_wizard(extra[0] if extra else None)
        return
    if action == "resume":
        if len(extra) != 1:
            console.print("[yellow]Usage: beep agent resume <thread_id>[/yellow]")
            raise typer.Exit(2)
        agent_resume_cmd(extra[0], max_steps=max_steps, auto_approve=yes, model=model, no_plugins=no_plugins)
        return
    if action == "reinstall":
        if len(extra) != 1:
            console.print("[yellow]Usage: beep agent reinstall <package|runtime>[/yellow]")
            raise typer.Exit(2)
        agent_reinstall_cmd(extra[0])
        return
    if action == "uninstall" and not extra:
        agent_uninstall_cmd(yes=yes)
        return

    goal = " ".join(ctx.args).strip()
    agent_cmd(goal, max_steps=max_steps, auto_approve=yes, model=model, no_plugins=no_plugins)


@app.command()
def tui(
    model: str | None = typer.Option(None, "--model", "-m"),
    mode: str = typer.Option("assistant", "--mode"),
) -> None:
    """Launch full TUI interface."""
    from beep.commands.tui import tui_cmd

    tui_cmd(model=model, mode=mode)


@app.command()
def tree(
    path: str = typer.Argument("."),
    depth: int = typer.Option(3, "--depth", "-d"),
    all_files: bool = typer.Option(False, "--all", "-a"),
) -> None:
    """Display workspace file tree."""
    from beep.commands.workspace import tree_cmd

    tree_cmd(path, depth, all_files)


@app.command()
def cat(
    path: str = typer.Argument(...),
    start: int = typer.Option(None, "--start", "-s"),
    end: int = typer.Option(None, "--end", "-e"),
    no_numbers: bool = typer.Option(False, "--no-numbers"),
    no_highlight: bool = typer.Option(False, "--raw"),
) -> None:
    """Display file content with syntax highlighting."""
    from beep.commands.workspace import cat_cmd

    cat_cmd(path, start, end, no_numbers, no_highlight)


@app.command()
def grep(
    pattern: str = typer.Argument(...),
    path: str = typer.Argument("."),
    case_sensitive: bool = typer.Option(False, "-C", "--case-sensitive"),
    file_pattern: str = typer.Option(None, "-n", "--name"),
) -> None:
    """Search files for a pattern."""
    from beep.commands.workspace import grep_cmd

    grep_cmd(pattern, path, case_sensitive, file_pattern)


@app.command()
def edit(
    path: str = typer.Argument(...),
    content: str = typer.Option(None, "--content", "-c"),
    no_confirm: bool = typer.Option(False, "--yes", "-y"),
) -> None:
    """Edit a file with diff preview."""
    from beep.commands.edit import edit_cmd

    edit_cmd(path, content, no_confirm)


@app.command()
def review(
    staged: bool = typer.Option(True, "--staged", "-s"),
    file: str | None = typer.Option(None, "--file", "-f"),
    model: str | None = typer.Option(None, "--model", "-m"),
) -> None:
    """Review code changes using AI."""
    from beep.commands.review import review_cmd

    review_cmd(staged, file, model)


@app.command()
def test(
    file: str | None = typer.Option(None, "--file", "-f"),
    watch: bool = typer.Option(False, "--watch", "-w"),
    framework: str | None = typer.Option(None, "--framework"),
    timeout: int = typer.Option(120, "--timeout", "-t"),
) -> None:
    """Run tests."""
    from beep.commands.test import test_cmd

    test_cmd(file, watch, framework, timeout)


@app.command()
def lint(
    file: str | None = typer.Option(None, "--file", "-f"),
    fix: bool = typer.Option(False, "--fix"),
    linter: str | None = typer.Option(None, "--linter"),
) -> None:
    """Run linter and optionally fix issues."""
    from beep.commands.lint import lint_cmd

    lint_cmd(file, fix, linter)


@app.command()
def analyze(
    path: str = typer.Argument("."),
) -> None:
    """Analyze codebase statistics."""
    from beep.commands.analyze import analyze_cmd

    analyze_cmd(path)


@app.command()
def diagnostics() -> None:
    """Show diagnostics and system info."""
    from beep.commands.diagnostics import diagnostics_cmd

    diagnostics_cmd()


template_app = typer.Typer(help="Code generation templates")
template_app.command(name="generate")(template_cmd)
template_app.command(name="list")(template_list_cmd)
app.add_typer(template_app, name="template")

sessions_app = typer.Typer(help="Session management")
sessions_app.command(name="list")(sessions_list_cmd)
sessions_app.command(name="export")(sessions_export_cmd)
sessions_app.command(name="delete")(sessions_delete_cmd)
app.add_typer(sessions_app, name="sessions")

rag_app = typer.Typer(help="RAG and semantic search")
rag_app.command(name="query")(rag_query_cmd)
rag_app.command(name="collections")(rag_collections_cmd)
app.add_typer(rag_app, name="rag")


@app.command()
def watch(
    pattern: str = typer.Option("*.py", "--pattern", "-p"),
    command: str = typer.Option(..., "--command", "-c"),
    debounce: float = typer.Option(1.0, "--debounce", "-d"),
    path: str = typer.Option(".", "--path"),
) -> None:
    """Watch files and run a command on changes."""
    from beep.commands.watch import watch_cmd

    watch_cmd(pattern=pattern, command=command, debounce=debounce, path=path)


def _run_default() -> None:
    """Handle default behavior: beep or beep "question"."""
    args = sys.argv[1:]
    invocation = parse_default_invocation(args, _SUBCOMMANDS)
    if invocation.kind == "ask" and invocation.question:
        from beep.commands.ask import ask_cmd

        ask_cmd(invocation.question, model=invocation.model, mode=invocation.mode)
        return

    from beep.commands.chat import chat_cmd

    chat_cmd(
        model=invocation.model,
        mode=invocation.mode,
        show_tokens=invocation.tokens,
        resume=invocation.resume,
        no_plugins=invocation.no_plugins,
    )


def main() -> None:
    """Entry point."""
    if _is_subcommand():
        app()
    else:
        _run_default()


if __name__ == "__main__":
    main()
