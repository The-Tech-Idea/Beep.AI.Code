"""Context management package."""
