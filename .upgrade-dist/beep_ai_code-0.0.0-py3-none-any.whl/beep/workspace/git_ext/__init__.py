"""Git integration package."""
